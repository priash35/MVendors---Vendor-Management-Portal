package com.abaow;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.SystemClock;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;

import com.abaow.Adapters.CurriculumAdapter;
import com.abaow.Pojo.Curriculum;
import com.abaow.utils.BackgroundAudioService;
import com.abaow.utils.Drawer;
import com.abaow.utils.PlayAudioBinder;
import com.abaow.utils.RestInterfac;
import com.abaow.utils.StaticDataMember;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;


import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;



public class ViewCourseActivity extends AppCompatActivity implements View.OnClickListener,AudioManager.OnAudioFocusChangeListener {
    private SeekBar seekbar;
    public MediaPlayer mMediaPlayer;
    private boolean isPlayingAudio = false;
    private ImageView mPlay;
    private ImageView mPause;
    private RelativeLayout  rlAudio;
    private Timer updateTimer;
    private ListView listView;
    ProgressDialog mProgressDialog;
    SharedPreferences sharedpreferences;
    public static final String MyPREFERENCES = "mypref";
    public String audiofile;
    private CardView llcardview;
    private ArrayList<Curriculum> listArray = new ArrayList<>();
    private RecyclerView.Adapter customadapter;
    public RecyclerView mRecyclerView;

    private int courseID,userID;

    private DrawerLayout mDrawerLayout;
    private ImageView imgDrawer;
    private Drawer dr;
    private String name,coursename;
    private TextView tvNotificationCount,tvCourseHeader;
    int AudioDuration;
    private int stopPosition = 0;
    private int max = 0;

    private PowerManager mgr;
    AudioManager mAudioManager;
    boolean audiocall = false;
    private PowerManager.WakeLock wakelock;
    private PlayAudioBinder playAudioBinder = null;
    private Handler audioProgressUpdateHandler = null;
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            // Cast and assign background service's onBind method returned iBander object.
            playAudioBinder = (PlayAudioBinder) iBinder;
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {

        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            stopPosition = savedInstanceState.getInt("position");
        }
        setContentView(R.layout.activity_view_course);
        mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        mAudioManager.requestAudioFocus(this, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        LinearLayoutManager layoutManager= new LinearLayoutManager(ViewCourseActivity.this, LinearLayoutManager.VERTICAL, false);
        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_curr);
        mRecyclerView.setLayoutManager(layoutManager);
        courseID = getIntent().getExtras().getInt("courseid");
        coursename = getIntent().getExtras().getString("coursename");
        max = getIntent().getExtras().getInt("max");
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        userID = sharedpreferences.getInt("loggedin_user_id", 0);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        name= sharedpreferences.getString("login_name", "");
        editor.putString("courseid", String.valueOf(courseID));
        editor.putString("coursename", String.valueOf(coursename));
        editor.apply();
        setHeader();
        bindAudioService();
        initializeMediaContents();
        createcourselist(courseID);
        int countNotification = sharedpreferences.getInt("notificationCount", 0);
        ImageView ivNotification = (ImageView) findViewById(R.id.imgNotification);
        tvNotificationCount = (TextView) findViewById(R.id.tvNotificationCount);

        tvNotificationCount.setText(String.valueOf(countNotification));

        ivNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvNotificationCount.setText("0");
                Intent notificationIntent = new Intent(ViewCourseActivity.this, MerchantNotification.class);
                startActivity(notificationIntent);
                //ViewCourseActivity.this.finish();
            }
        });

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        dr = new Drawer(this);
        dr.initializeDrawers(mDrawerLayout,name);
        imgDrawer = (ImageView) findViewById(R.id.imgDrawer);
        imgDrawer.setOnClickListener(this);
        tvCourseHeader = (TextView) findViewById(R.id.course_name);
        tvCourseHeader.setText(coursename);
        mgr = (PowerManager)this.getSystemService(Context.POWER_SERVICE);
        wakelock = mgr.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MyWakeLock");
        wakelock.acquire();


    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgDrawer:

                mDrawerLayout.openDrawer(dr.mDrawerList);

                break;
        }
    }

    public void initializeMediaContents() {
        rlAudio = (RelativeLayout) findViewById(R.id.rlAudio);


        seekbar = (SeekBar) findViewById(R.id.seekBar);
        seekbar.setMax(100);
        seekbar.getProgressDrawable().setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_IN);
        seekbar.getThumb().setColorFilter(Color.RED, PorterDuff.Mode.SRC_IN);
        /*seekbar.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(!mMediaPlayer.isPlaying() || AudioDuration == 0){
                    return false;
                }
                return true;
            }
        });*/

        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {


            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (playAudioBinder != null) {
                    if (!playAudioBinder.isPlayingAudio() || AudioDuration == 0) {
                        seekbar.setProgress(0);

                    } else {

                    }
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                System.out.println("In Start");
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {

                try {
                    if (fromUser) {
                        //mMediaPlayer.pause();
                        // this is when actually seekbar has been seeked to a new position
                        // mAudioView.seekTo(progress);
                        if  (playAudioBinder != null) {
                            if (isPlayingAudio) {
                                int secondaryPosition = seekbar.getSecondaryProgress();
                                if (progress < secondaryPosition) {
                                    seekbar.setProgress(progress);
                                    playAudioBinder.seekto(getProgressSeek(seekBar.getProgress()));
                                }
                            }
                        }
                        //mMediaPlayer.seekTo(420);
                   /* if (!isPlayingAudio) {
                        mMediaPlayer.start();
                        //updateMediaProgress();
                    }*/


                    }
                }catch(Exception e){

                }
            }

        });


        //mMediaPlayer = new MediaPlayer();

        //mMediaPlayer.start();
        rlAudio.setVisibility(View.VISIBLE);
        mPlay = (ImageView) findViewById(R.id.play);
        mPause = (ImageView) findViewById(R.id.pause);

        mPlay.setImageResource(R.drawable.play);
        mPlay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                if (!isPlayingAudio) {
                    mPlay.setImageResource(R.drawable.play);
                    if (playAudioBinder != null) {
                        playAudioBinder.pauseAudio();
                        rlAudio.setKeepScreenOn(false);
                        isPlayingAudio = true;
                    }else{
                        showDialog(ViewCourseActivity.this,"Select Module", "Please select module to be played");
                    }

                } else {
                    mPlay.setImageResource(R.drawable.pause);
                    //int mCurrentPosition = mMediaPlayer.getCurrentPosition();
                    //seekbar.setProgress(mCurrentPosition);
                    if (playAudioBinder != null) {
                        seekbar.postDelayed(onEverySecond, 1000000000);
                        rlAudio.setKeepScreenOn(true);
                        playAudioBinder.startAudio();
                        isPlayingAudio = false;
                    }
                }
            }
        });

    }

    public void PlayMusic(String source,final Curriculum curriculum) {

        playAudioBinder.setContext(this);
        seekbar.setProgress(0);
        createAudioProgressbarUpdater();

        playAudioBinder.setAudioProgressUpdateHandler(audioProgressUpdateHandler);
        playAudioBinder.setUserID(userID);
        playAudioBinder.PlayMusic(source,curriculum);

        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Playing Audio");
        mProgressDialog.show();
        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);

        //mMediaPlayer.start();
//        updateTimer.cancel();

        mPlay.setImageResource(R.drawable.pause);
        audiofile = source;


    }
    private void updateMediaProgress() {
        updateTimer = new Timer("progress Updater");
        updateTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (playAudioBinder != null) {
                            int position = playAudioBinder.getCurrentAudioPosition();
                            //seekbar.setProgress(position / 1000);
                            if (AudioDuration > 0) {
                                seekbar.setProgress((position * 100) / AudioDuration);
                            }
                        }
                    }
                });
            }
        }, 0, 1000);
    }


    private Runnable onEverySecond = new Runnable() {

        @Override
        public void run() {

            if (seekbar != null) {
                seekbar.setProgress(playAudioBinder.getCurrentAudioPosition());
            }

            if (playAudioBinder.isPlayingAudio()) {
                seekbar.postDelayed(onEverySecond, 1000000000);
            }else{
                seekbar.setProgress(0);
            }


        }
    };
    /**
     * Method converts seek bar progress value into
     * mediaplayer duration
     *
     * @param mProgress
     * @return
     */
    private int getProgressSeek(int mProgress) {
        int progress = 0;
        progress = ((mProgress * AudioDuration) / 100);
        return progress;
    }
    private void createcourselist(int courseid) {
       // listView = (ListView) findViewById(R.id.course_detail);

        // Defined Array values to show in ListView

        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);
        //Creating a RestAdapter
        RestAdapter adapter1 = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter1.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.getCourse(
                courseID,
                userID,
                //Passing the values by getting it from editTexts


                //Creating an anonymous callback
                new retrofit.Callback<Response>() {


                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;
                        JSONArray usercourse = null;
                        String[] curriculum;

                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {


                                success = json.getInt("success");
                                usercourse = json.getJSONArray("usercourse");


                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                        // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}

                        if (success == 1) {
                            try {
                                for(int i=0;i<usercourse.length();i++) {
                                    JSONObject jsoner = usercourse.getJSONObject(i);
                                    String name = jsoner.getString("module_name");
                                    Log.v("curr: ", "name");
                                    String desc = jsoner.getString("module_desc");
                                    String duration = jsoner.getString("duration");
                                    String audio = jsoner.getString("module_audio");
                                    int quiz = jsoner.getInt("module_quiz");
                                    int id = jsoner.getInt("course_id");
                                    int mod_id = jsoner.getInt("id");
                                    String status = jsoner.getString("status");
                                    //max = jsoner.getInt("max");
                                    listArray.add(new  Curriculum(id, mod_id,name, audio, quiz, desc, duration, "",status));

                                }

                                customadapter = new CurriculumAdapter(listArray,max, ViewCourseActivity.this);
                                mRecyclerView.setAdapter(customadapter);
                                mRecyclerView.scrollToPosition(listArray.size()-1);
                                customadapter.notifyDataSetChanged();
                            }
                            catch(Exception e){
                                Log.e("json error: ",e.toString());
                            }

                        } else {
                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(ViewCourseActivity.this, "Invalid Credentials", "Please enter valid email or Password");

                        }
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();

                         /*else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Invalid Credentials", "please enter valid Email_Id and Password");
                        }*/

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //If any error occured displaying the error as toast
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(ViewCourseActivity.this, error.toString(), "");
                    }
                }
        );
    }

    public void showDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx, R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        builder.show();
    }
    @Override
    public void onBackPressed() {
        if (mProgressDialog.isShowing())
            mProgressDialog.dismiss();
        Intent homeintent = new Intent(ViewCourseActivity.this, MainActivity.class);
        startActivity(homeintent);
        ViewCourseActivity.this.finish();
    }
    protected void setHeader() {
        TextView header = (TextView) findViewById(R.id.header_text);
        header.setText("View Course");
        ImageView imgLogo = (ImageView) findViewById(R.id.imglogo);
        imgLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeintent = new Intent(ViewCourseActivity.this, MainActivity.class);
                startActivity(homeintent);
                ViewCourseActivity.this.finish();
            }
        });
    }
    @Override
    protected void onStop() {
           /* if (mMediaPlayer != null) {
                mMediaPlayer.pause();
            }*/
        if (mProgressDialog.isShowing())
            mProgressDialog.dismiss();
            super.onStop();
        }

    @Override
    public void onResume() {
        super.onResume();

        if (playAudioBinder != null) {
            if(audiocall) {
                audiocall = false;
                playAudioBinder.seekto(stopPosition);
                if (!isPlayingAudio) {
                    playAudioBinder.startAudio();
                    updateMediaProgress();
                }
            }
        }
    }
    @Override
    public void onDestroy() {
        playAudioBinder.stopAudio();
        if (wakelock.isHeld()) {
            wakelock.release();
        }

        if (mProgressDialog.isShowing())
            mProgressDialog.dismiss();
        unBoundAudioService();
        super.onDestroy();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (playAudioBinder != null) {
            stopPosition = playAudioBinder.getCurrentAudioPosition();
            if (audiocall){
                playAudioBinder.pauseAudio();
                if (wakelock.isHeld())
                    wakelock.release();
            }
            outState.putInt("position", stopPosition);
        }
    }
    public void StopAudio(){
        if (playAudioBinder != null) {
            if (playAudioBinder.isPlayingAudio()) {
                playAudioBinder.stopAudio();
                if (wakelock.isHeld())
                    wakelock.release();

            }
        }
    }

    private void bindAudioService()
    {
        if(playAudioBinder == null) {
            Intent intent = new Intent(ViewCourseActivity.this, BackgroundAudioService.class);

            // Below code will invoke serviceConnection's onServiceConnected method.
            bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
        }
    }

    // Unbound background audio service with caller activity.
    private void unBoundAudioService()
    {
        if(playAudioBinder != null) {
            unbindService(serviceConnection);
        }
    }
    private void createAudioProgressbarUpdater()
    {
        /* Initialize audio progress handler. */
        if(audioProgressUpdateHandler==null) {
            audioProgressUpdateHandler = new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    // The update process message is sent from AudioServiceBinder class's thread object.
                    switch (msg.what){
                        case 1:
                            if (mProgressDialog.isShowing())
                                mProgressDialog.dismiss();
                            AudioDuration = playAudioBinder.getAudioDuration();
                            isPlayingAudio = true;
                            updateMediaProgress();
                            break;
                        case 2:
                            if (updateTimer != null)
                                updateTimer.cancel();
                            seekbar.setProgress(0);
                            mPlay.setImageResource(R.drawable.play);
                            isPlayingAudio = false;
                            if (wakelock.isHeld())
                                wakelock.release();
                            if (playAudioBinder.isLastmodule()){
                               coursefinish();
                            }else{
                                startActivity(getIntent());
                                ViewCourseActivity.this.finish();
                            }
                            break;
                        case 3:
                            seekbar.setSecondaryProgress(playAudioBinder.getSecProgess());
                            break;
                        default:
                            break;

                    }
                }
            };
        }
    }
    @Override
    public void onAudioFocusChange(int focusChange) {
        if(focusChange<=0) {
           audiocall = true;
        } else {
           audiocall = false;
        }
    }

    public void coursefinish() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ViewCourseActivity.this,R.style.MyDialogTheme);
        String title = "Congratulations!";
        if (title != null) builder.setTitle(title);

        builder.setMessage("You have successfully completed the course. This course is now available to you in the Completed Courses menu");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                Intent intent = new Intent(ViewCourseActivity.this, MainActivity.class);
                //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                ViewCourseActivity.this.finish();

            }
        });

        builder.show();
    }

}
