package com.abaow.utils;

import android.os.Environment;
import android.util.Log;

import java.io.File;

/**
 * Created by vikaspc2 on 10/28/2017.
 */

public class UtilityFile {
    private static final String TAG = "Utility";

    public static File getMediaPath() {
        String path = UtilityFile.getRootDir() + File.separator + Constants.HOME;
        File mediaStorageDir = new File(path, Constants.IMAGE_CAPTURE_DIR);
        return mediaStorageDir;
    }


    public static File getRootDir() {
        return Environment.getExternalStorageDirectory();
    }

    public static File createMediaDir() {
        String path = UtilityFile.getRootDir() + File.separator + Constants.HOME;
        File catlogDir = new File(path, Constants.IMAGE_CAPTURE_DIR);

        // Create the storage directory if it does not exist
        if (!UtilityFile.makeDirectory(catlogDir)) {
            return null;
        }

        return catlogDir;
    }


    public static boolean makeDirectory(File mediaStorageDir) {
        if (! mediaStorageDir.exists()) {
            if (! mediaStorageDir.mkdirs()){
                Log.d(TAG, "failed to create directory");
                return false;
            }
        }
        return true;
    }



}
