package com.abaow.LocalDB;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.abaow.Pojo.NotificationData;
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.RuntimeExceptionDao;
import com.j256.ormlite.stmt.DeleteBuilder;
import com.j256.ormlite.stmt.QueryBuilder;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * Created by vaibhav on 14/11/16.
 */
public class DatabaseHelper extends OrmLiteSqliteOpenHelper {

    private Context _context;
    private static final String DATABASE_NAME = "abaow.db";
    private static final int DATABASE_VERSION = 1;
    private Dao<NotificationData, String> simpleDao = null;
    private RuntimeExceptionDao<NotificationData, String> simpleRuntimeDao = null;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        _context = context;
    }

    public Dao<NotificationData, String> getDao() throws SQLException {
        if (simpleDao == null) {
            simpleDao = getDao(NotificationData.class);
        }
        return simpleDao;
    }

    public RuntimeExceptionDao<NotificationData, String> getSimpleDataDao() {
        if (simpleRuntimeDao == null) {
            simpleRuntimeDao = getRuntimeExceptionDao(NotificationData.class);
        }
        return simpleRuntimeDao;
    }

    //method for list of Reference
    public List<NotificationData> GetData(String mLoginId) {
        DatabaseHelper helper = new DatabaseHelper(_context);
        RuntimeExceptionDao<NotificationData, String> simpleDao = helper.getSimpleDataDao();
        List<NotificationData> list= null;
        //List<NotificationData> list = simpleDao.queryForEq("mLoginId", mLoginId);
        try {
            QueryBuilder<NotificationData,String> qb = simpleDao.queryBuilder();
            qb.where().eq("mLoginId", mLoginId);
            qb.orderBy("mDate",false);
             list = qb.query();

        }
        catch(Exception e){

        }
        List<NotificationData> listf = null;
        if (list != null) {
            listf = new ArrayList<NotificationData>(new LinkedHashSet<NotificationData>(list));
        }
        return listf;
    }

    //method for insert data
    public int addData(NotificationData clr) {
        RuntimeExceptionDao<NotificationData, String> dao = getSimpleDataDao();
        int i = 0;
        try {
            i = dao.create(clr);
            return i;
        } catch (Exception e) {

            //deleteData(clr);
            //i = dao.create(clr);

        }
        return i;
    }

    //method to delete single data
    public void deleteData(NotificationData clr) {
        RuntimeExceptionDao<NotificationData, String> dao = getSimpleDataDao();
        DeleteBuilder<NotificationData, String> deleteBuider = dao.deleteBuilder();
        try {
            deleteBuider.where().eq("id", clr.getId());
            deleteBuider.delete();
        } catch (SQLException e) {

            e.printStackTrace();
        }


    }

    //method for delete all rows
    public void deleteAll() {
        RuntimeExceptionDao<NotificationData, String> dao = getSimpleDataDao();
        List<NotificationData> list = dao.queryForAll();
        DeleteBuilder<NotificationData, String> deleteBuider = dao.deleteBuilder();
        for (int i = 0; i < list.size(); i++) {
            try {
                //deleteBuider.where().eq("hashcode", list.get(i).getHashcode());
                deleteBuider.delete();
            } catch (SQLException e) {

                e.printStackTrace();
            }
        }
    }

    @Override
    public void close() {
        super.close();
        simpleRuntimeDao = null;
    }

    @Override
    public void onCreate(SQLiteDatabase db, ConnectionSource connectionSource) {
        try {
            Log.i(DatabaseHelper.class.getName(), "onCreate");
            TableUtils.createTable(connectionSource, NotificationData.class);
        } catch (SQLException e) {
            Log.e(DatabaseHelper.class.getName(), "Can't create database", e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, ConnectionSource connectionSource, int oldVersion, int newVersion) {
        try {
            Log.i(DatabaseHelper.class.getName(), "onUpgrade");
            TableUtils.dropTable(connectionSource, NotificationData.class, true);
            onCreate(db, connectionSource);
        } catch (SQLException e) {
            Log.e(DatabaseHelper.class.getName(), "Can't drop databases", e);
            throw new RuntimeException(e);
        }
    }
}