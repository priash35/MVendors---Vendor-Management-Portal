package com.abaow.notification;

import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.content.WakefulBroadcastReceiver;
import android.util.Log;



/**
 * Created by mahendra on 8/17/2017.
 */

public class NotificationReceiver extends WakefulBroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        playNotificationSound(context);
    }

    public void playNotificationSound(Context context) {
        try {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
//            Uri notification =(Uri.parse("android.resource://in.cartowdriver.cartow.cartowdriver/" + R.raw.noti_sound));
            Ringtone r= RingtoneManager.getRingtone(context, notification);//lovingyou)));
            Log.v("for Sound ::","Sound played");
            r.play();
        } catch (Exception e) {
            e.printStackTrace();
        }
}
}
