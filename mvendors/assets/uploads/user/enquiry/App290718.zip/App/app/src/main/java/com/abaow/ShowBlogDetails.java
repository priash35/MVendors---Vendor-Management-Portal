package com.abaow;

import android.os.Build;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.abaow.model.Blogs;
import com.squareup.picasso.Picasso;

public class ShowBlogDetails extends AppCompatActivity {
    TextView title,description;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_blog_details);
        title=(TextView) findViewById(R.id.title);
        description=(TextView) findViewById(R.id.description);
        Blogs blogs=(Blogs) getIntent().getSerializableExtra("blogValue");
        if((blogs.getBlog_img()!=null)&&(!blogs.getBlog_img().equals("")))
        Picasso.with(ShowBlogDetails.this).load(blogs.getBlog_img()).into((ImageView)findViewById(R.id.imageValue));

        title.setText(blogs.getBlog_title());
        description.setText(Html.fromHtml(blogs.getBlog_content()));
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    if (getParentActivityIntent() == null) {
                        // Log.i(TAG, "You have forgotten to specify the parentActivityName in the AndroidManifest!");
                        onBackPressed();
                    } else {
                        NavUtils.navigateUpFromSameTask(this);
                    }
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}
