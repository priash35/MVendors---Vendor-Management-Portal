package com.abaow.model;

import java.io.Serializable;

/**
 * Created by vikaspc2 on 3/21/2018.
 */

public class Blogs implements Serializable {
    String id,blog_title,blog_lang,blog_img,blog_content;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBlog_title() {
        return blog_title;
    }

    public void setBlog_title(String blog_title) {
        this.blog_title = blog_title;
    }

    public String getBlog_lang() {
        return blog_lang;
    }

    public void setBlog_lang(String blog_lang) {
        this.blog_lang = blog_lang;
    }

    public String getBlog_img() {
        return blog_img;
    }

    public void setBlog_img(String blog_img) {
        this.blog_img = blog_img;
    }

    public String getBlog_content() {
        return blog_content;
    }

    public void setBlog_content(String blog_content) {
        this.blog_content = blog_content;
    }
}
