package com.abaow;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.abaow.utils.RestInterfac;
import com.abaow.utils.StaticDataMember;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.abaow.utils.AvenuesParams;
import com.abaow.utils.Constants;
import com.abaow.utils.LoadingDialog;
import com.abaow.utils.RSAUtility;
import com.abaow.utils.ServiceUtility;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;

public class WebViewActivity extends AppCompatActivity {
    Intent mainIntent;
    String encVal;
    String vResponse,coursename;
    int userid,courseid;
    String name,email,phone,city,country;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_webview);
        mainIntent = getIntent();
        userid = mainIntent.getIntExtra("userid",0);
        courseid = mainIntent.getIntExtra("courseid",0);
        coursename = mainIntent.getStringExtra("coursename");
        GetCurrentCustomerDetails();

//get rsa key method
        //get_RSA_key(mainIntent.getStringExtra(AvenuesParams.ACCESS_CODE), mainIntent.getStringExtra(AvenuesParams.ORDER_ID));
    }



    private class RenderView extends AsyncTask<Void, Void, Integer> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            LoadingDialog.showLoadingDialog(WebViewActivity.this, "Loading...");

        }

        @Override
        protected Integer doInBackground(Void... arg0) {
            if (!ServiceUtility.chkNull(vResponse).equals("")
                    && ServiceUtility.chkNull(vResponse).toString().indexOf("ERROR") == -1) {
                StringBuffer vEncVal = new StringBuffer("");
                vEncVal.append(ServiceUtility.addToPostParams(AvenuesParams.AMOUNT, mainIntent.getStringExtra(AvenuesParams.AMOUNT)));
                vEncVal.append(ServiceUtility.addToPostParams(AvenuesParams.CURRENCY, mainIntent.getStringExtra(AvenuesParams.CURRENCY)));
                encVal = RSAUtility.encrypt(vEncVal.substring(0, vEncVal.length() - 1), vResponse);  //encrypt amount and currency
            }

            return null;
        }

        @Override
        protected void onPostExecute(Integer result) {
            super.onPostExecute(result);
            System.out.println("onPostExecute");
            // Dismiss the progress dialog
            LoadingDialog.cancelLoading();

            @SuppressWarnings("unused")
            class MyJavaScriptInterface {
                @JavascriptInterface
                public void processHTML(String html) {
                    // process the html source code to get final status of transaction

                    String status = null;
                    if (html.indexOf("Failure") != -1) {
                        status = "Transaction Declined!";
                    } else if (html.indexOf("Success") != -1) {
                        status = "Transaction Successful!";
                    } else if (html.indexOf("Aborted") != -1) {
                        status = "Transaction Cancelled!";
                    } else {
                        status = "Status Not Known!";
                    }

                    Intent intent = new Intent(getApplicationContext(), StatusActivity.class);
                    intent.putExtra("userid",userid);
                    intent.putExtra("courseid",courseid);
                    intent.putExtra("transStatus", status);
                    intent.putExtra("coursename", coursename);
                    intent.putExtra("orderid", mainIntent.getStringExtra(AvenuesParams.ORDER_ID));
                    startActivity(intent);
                    WebViewActivity.this.finish();
                }
            }

            final WebView webview = (WebView) findViewById(R.id.webview);

            webview.getSettings().setJavaScriptEnabled(true);
            webview.addJavascriptInterface(new MyJavaScriptInterface(), "HTMLOUT");
            webview.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(webview, url);
                    LoadingDialog.cancelLoading();
                    if (url.indexOf("/ccavResponseHandler.php") != -1) {
                        webview.setVisibility(View.GONE);
                        webview.loadUrl("javascript:window.HTMLOUT.processHTML('<head>'+document.getElementsByTagName('html')[0].innerHTML+'</head>');");
                    }
                }

                @Override
                public void onPageStarted(WebView view, String url, Bitmap favicon) {
                    super.onPageStarted(view, url, favicon);
                    LoadingDialog.showLoadingDialog(WebViewActivity.this, "Loading...");
                }
            });


            try {
                String postData = AvenuesParams.ACCESS_CODE + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.ACCESS_CODE), "UTF-8") + "&" + AvenuesParams.MERCHANT_ID + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.MERCHANT_ID), "UTF-8") + "&" + AvenuesParams.ORDER_ID + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.ORDER_ID), "UTF-8") + "&" + AvenuesParams.REDIRECT_URL + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.REDIRECT_URL), "UTF-8") + "&" + AvenuesParams.CANCEL_URL + "=" + URLEncoder.encode(mainIntent.getStringExtra(AvenuesParams.CANCEL_URL), "UTF-8") + "&" + AvenuesParams.ENC_VAL + "=" + URLEncoder.encode(encVal, "UTF-8")+
                        "&billing_name="+name+"&billing_city="+city+"&billing_country="+country+"&billing_tel="+phone+"&billing_email="+email;
                webview.postUrl(Constants.TRANS_URL, postData.getBytes());
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }


        }
    }

    public void get_RSA_key(final String ac, final String od) {
        LoadingDialog.showLoadingDialog(WebViewActivity.this, "Loading...");

        StringRequest stringRequest = new StringRequest(Request.Method.POST, mainIntent.getStringExtra(AvenuesParams.RSA_KEY_URL),
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Toast.makeText(WebViewActivity.this,response,Toast.LENGTH_LONG).show();
                        LoadingDialog.cancelLoading();

                        if (response != null && !response.equals("")) {
                            vResponse = response;     ///save retrived rsa key
                            if (vResponse.contains("!ERROR!")) {
                                show_alert(vResponse);
                            } else {
                                new RenderView().execute();   // Calling async task to get display content
                            }


                        }
                        else
                        {
                            show_alert("No response");
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        LoadingDialog.cancelLoading();
                        //Toast.makeText(WebViewActivity.this,error.toString(),Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put(AvenuesParams.ACCESS_CODE, ac);
                params.put(AvenuesParams.ORDER_ID, od);
                return params;
            }

        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void show_alert(String msg) {
        AlertDialog alertDialog = new AlertDialog.Builder(
                WebViewActivity.this, R.style.MyDialogTheme).create();

        alertDialog.setTitle("Error!!!");
        if (msg.contains("\n"))
            msg = msg.replaceAll("\\\n", "");

        alertDialog.setMessage(msg);



        alertDialog.setButton(Dialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });


        alertDialog.show();
    }
    private void GetCurrentCustomerDetails() {
        /*mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();*/

        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.getUserInfoAll(

                //Passing the values by getting it from editTexts
                userid,


                //Creating an anonymous callback
                new Callback<retrofit.client.Response>() {

                    @Override
                    public void success(retrofit.client.Response result, retrofit.client.Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String mCity="",mCountry="";

                        //An string to store output from the server
                        String output = "";
                        JSONArray jsonObj;
                        JSONObject json = null;
                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            //{"customer_details":[{"id":"21","firstname":"vnts","lastname":"vnts","mobile":"7588676808","email":"vnts@gmail.com","dob":"1966-05-24","City":"hgff","city":"pune","pincode":"411029","gender":"Male","image":"http:\/\/referplus.ele45.com\/referplus\/app\/webroot\/img\/uploads\/users\/vnts_16-05-24_10-45-05.png"}],"success":1,"message":"Customer details"}
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            jsonObj = json.getJSONArray("userinfo");
                            if (json != null) {
                                for (int i = 0; i < jsonObj.length(); i++) {
                                    JSONObject obj = jsonObj.getJSONObject(i);
                                    System.out.println("JSON Object: " + json);
                                    name = obj.getString("name");
                                    //etLname.setText(obj.getString("lastname"));
                                    email =obj.getString("email");
                                    city = obj.getString("city_name");
                                    country = obj.getString("country_name");
                                    phone = obj.getString("mobile");
                                }
                                get_RSA_key(mainIntent.getStringExtra(AvenuesParams.ACCESS_CODE), mainIntent.getStringExtra(AvenuesParams.ORDER_ID));

                            }
                            // Toast.makeText(this, json.getString("meassage"),Toast.LENGTH_LONG).show();
                            //  showDialog(this,"success", json.getString("meassage"));
                        } catch (IOException e) {
                            showDialog(WebViewActivity.this, "Network Error", "Please try again later.");
                        } catch (JSONException e) {
                            showDialog(WebViewActivity.this, "Network Error", "Please try again later.");
                        }



                    }


                    @Override
                    public void failure(RetrofitError error) {
                        /*if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();*/
                        //If any error occured displaying the error as toast
                        //Toast.makeText(this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(WebViewActivity.this, "Network Error", "Please try again later.");
                    }
                }
        );
    }
    public void showDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(WebViewActivity.this, R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                Intent intent = new Intent(WebViewActivity.this, CourseOverview.class);
                intent.putExtra("course",courseid);
                startActivity(intent);
                WebViewActivity.this.finish();
            }
        });

        builder.show();
    }
}