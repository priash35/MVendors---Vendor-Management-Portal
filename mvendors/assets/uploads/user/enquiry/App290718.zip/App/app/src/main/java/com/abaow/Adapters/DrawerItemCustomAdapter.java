package com.abaow.Adapters;


import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.abaow.utils.ObjectDrawerItem;
import com.abaow.R;
//import com.ele45.referrer.utils.PicassoTrustAll;

//import de.hdodenhof.circleimageview.CircleImageView;

public class DrawerItemCustomAdapter extends ArrayAdapter<ObjectDrawerItem> {
    Context mContext;
    int layoutResourceId;
    ObjectDrawerItem data[] = null;
    Typeface notoFace, notoFaceBold;
    String outletImagePath;
    public static final String MyPREFERENCES = "mypref";
    /*
     * @mContext - app context
     *
     * @layoutResourceId - the listview_item_row.xml
     *
     * @data - the ListItem data
     */
    public DrawerItemCustomAdapter(Context mContext, int layoutResourceId,
                                   ObjectDrawerItem[] data) {
        super(mContext, layoutResourceId, data);
        this.layoutResourceId = layoutResourceId;
        this.mContext = mContext;
        this.data = data;
    }

    /*
     * @We'll overried the getView method which is called for every ListItem we
     * have.
     *
     * @There are lots of different caching techniques for Android ListView to
     * achieve better performace especially if you are going to have a very long
     * ListView.
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItem = convertView;
        // inflate the listview_item_row.xml parent
        LayoutInflater inflater = ((Activity) mContext).getLayoutInflater();
        notoFace = Typeface.createFromAsset(parent.getContext().getAssets(), "NotoSans-Regular.ttf");
        notoFaceBold = Typeface.createFromAsset(parent.getContext().getAssets(), "NotoSans-Regular.ttf");

        listItem = inflater.inflate(layoutResourceId, parent, false);
        // get the elements in the layout
        LinearLayout lvListHeader = (LinearLayout) listItem.findViewById(R.id.lvListHeader);
        LinearLayout lvlistdata = (LinearLayout) listItem.findViewById(R.id.lvlistdata);
        LinearLayout llLogout = (LinearLayout) listItem.findViewById(R.id.llLogout);
        //  LinearLayout llBrowseADs = (LinearLayout) listItem.findViewById(R.id.llBrowseAdv);
        View view = listItem.findViewById(R.id.view);
        if (position < 4) {
            view.setVisibility(View.GONE);
        }
        ImageView imageViewIcon = (ImageView) listItem
                .findViewById(R.id.imageViewIcon);
        /*ImageView imageView1 = (ImageView) listItem
                .findViewById(R.id.imageView1);*/


        TextView textViewName = (TextView) listItem
                .findViewById(R.id.textViewName);
        textViewName.setTypeface(notoFace);

        TextView textViewHeader = (TextView) listItem
                .findViewById(R.id.tvUserName);
        textViewHeader.setTypeface(notoFaceBold);

        TextView tvlogout = (TextView) listItem.findViewById(R.id.tvlogout);
        tvlogout.setTypeface(notoFaceBold);
        ObjectDrawerItem folder = data[position];
        imageViewIcon.setImageResource(folder.icon);

        if (position == 0) {

            lvlistdata.setVisibility(View.GONE);
            llLogout.setVisibility(View.GONE);
            textViewHeader.setTextSize(19);
            textViewHeader.setTextColor(getContext().getResources().getColor(R.color.white));

            textViewHeader.setText(folder.name);


        } else {
            lvListHeader.setVisibility(View.GONE);
            llLogout.setVisibility(View.GONE);
            textViewName.setTextSize(16);
            textViewName.setTextColor(getContext().getResources().getColor(R.color.bel_lightgrey_text));
            //  textViewName.setBackground(getContext().getResources().getDrawable(R.color.Headerbackground));
            //   rl.setBackground(getContext().getResources().getDrawable(R.color.Headerbackground));
            //  rl.removeViewAt(2);
            textViewName.setText(folder.name);

        }

        return listItem;
    }


}