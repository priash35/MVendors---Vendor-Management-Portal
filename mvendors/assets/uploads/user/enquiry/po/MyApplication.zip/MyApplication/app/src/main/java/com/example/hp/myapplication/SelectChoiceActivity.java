package com.example.hp.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SelectChoiceActivity extends AppCompatActivity {
    Button btnAddRecords;
    Button btnSearchRecords;
    Button btnAllRecord;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_choice);

        btnAddRecords = findViewById(R.id.btnAddRecords);
        btnSearchRecords = findViewById(R.id.btnSearchRecords);
        btnAllRecord=findViewById(R.id.btnAllRecords);

        btnAddRecords.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(SelectChoiceActivity.this, AddRecordActivity.class);
                startActivity(intent);
            }
        });

        btnSearchRecords.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(SelectChoiceActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });
        btnAllRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SelectChoiceActivity.this, DetailsActivity.class);
                startActivity(intent);
            }
        });


    }
}
