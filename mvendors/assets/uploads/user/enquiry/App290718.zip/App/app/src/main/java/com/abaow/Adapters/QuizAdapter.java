package com.abaow.Adapters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;

import com.abaow.R;

import java.util.ArrayList;

/**
 * Created by chetan on 21/11/17.
 */
public class QuizAdapter extends ArrayAdapter {
    Context mContext;
    int resourceID;
    ArrayList<String> names;
    public QuizAdapter(Context context, int resource, ArrayList<String> objects) {
        super(context, resource, objects);
        this.mContext = context;
        this.resourceID=resource;
        this.names= objects;
    }

    @Override
    public String getItem(int position) {
        return names.get(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        LayoutInflater inflater = LayoutInflater.from(mContext);
        row = inflater.inflate(resourceID, parent, false);

        TextView text = (TextView) row.findViewById(R.id.qtext);
        EditText answer = (EditText) row.findViewById(R.id.edtext);

        if (names.get(position).contains(",")){
            String split[] = names.get(position).split(",");
            text.setText(position+1+". "+split[0]);
            answer.setText(split[1]);
        }else {
            text.setText(position + 1 + ". " + names.get(position));
            answer.setText("");
        }
        return row;
    }

}