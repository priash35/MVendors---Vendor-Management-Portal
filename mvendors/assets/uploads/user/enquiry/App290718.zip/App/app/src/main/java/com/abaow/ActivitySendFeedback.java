package com.abaow;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

//import com.ele45.referrer.referrer.adapter.DrawerItemCustomAdapter;
import com.abaow.utils.Drawer;
import com.abaow.utils.RestInterfac;
import com.abaow.utils.StaticDataMember;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class ActivitySendFeedback extends AppCompatActivity implements View.OnClickListener {

    private TextView tvNotificationCount, tvMsg, tvTitle;
    private String loginId, loginName, catIdString,  mMerchantId, mShopName;
    private SharedPreferences sharedpreferences;
    private EditText etFeedback;
    private Button btnSend;
    private DrawerLayout mDrawerLayout;
    private ImageView imgDrawer,imgLogo;
    private Drawer dr;
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity_send_feedback);

        Typeface notoFace = Typeface.createFromAsset(getResources().getAssets(), "NotoSans-Regular.ttf");
        Typeface notoFaceBold = Typeface.createFromAsset(getResources().getAssets(), "NotoSans-Bold.ttf");
        sharedpreferences = getSharedPreferences("mypref", Context.MODE_PRIVATE);
        loginId = Integer.toString(sharedpreferences.getInt("loggedin_user_id", 0));
        name= sharedpreferences.getString("login_name", "");
        ImageView ivNotification = (ImageView) findViewById(R.id.imgNotification);
        tvTitle = (TextView) findViewById(R.id.tvTitle);
        tvMsg = (TextView) findViewById(R.id.tvMsg);
        btnSend = (Button) findViewById(R.id.btnSubmit);
        String shopName = "Send your message to \r\n <b><font color=\"#065174\"> Rich n Happy Expert</font></b>";
        tvTitle.setText(Html.fromHtml(shopName));
        etFeedback = (EditText) findViewById(R.id.etFeedback);

        tvMsg.setTypeface(notoFace);
        tvTitle.setTypeface(notoFace);
        etFeedback.setTypeface(notoFace);
        btnSend.setTypeface(notoFaceBold);

        btnSend.setOnClickListener(this);

        int countNotification = sharedpreferences.getInt("notificationCount", 0);

        tvNotificationCount = (TextView) findViewById(R.id.tvNotificationCount);

        tvNotificationCount.setText(String.valueOf(countNotification));

        ivNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvNotificationCount.setText("0");
                Intent notificationIntent = new Intent(ActivitySendFeedback.this, MerchantNotification.class);
                startActivity(notificationIntent);

            }
        });
        setHeader();


        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        dr = new Drawer(this);
        dr.initializeDrawers(mDrawerLayout,name);
        imgDrawer = (ImageView) findViewById(R.id.imgDrawer);
        imgDrawer.setOnClickListener(this);

        //initializeDrawers();
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgDrawer:
                mDrawerLayout.openDrawer(dr.mDrawerList);
                break;
            case R.id.btnSubmit:
                attaimptSendFeedback();
                break;
        }
    }

    private void attaimptSendFeedback() {

        if (!validateForm()) {
            try {
                ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
                if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                        connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
                    String strFeedback = etFeedback.getText().toString().trim();
                    //sendFeedback(mMerchantId, loginId, strFeedback);
                    setFeedData( loginId, strFeedback);
                } else //No Internet connection
                {
//noDataConnectionAlert();
                    Toast.makeText(ActivitySendFeedback.this, "No internet connection", Toast.LENGTH_SHORT).show();
                }

            } catch (Exception e) {
                Log.e("Log", "connectivity manager " + e.getMessage());
            }
        }
    }

    private boolean validateForm() {
        boolean cancel = false;

        etFeedback.setError(null);

        String strFeedback = etFeedback.getText().toString().trim();

        if (TextUtils.isEmpty(strFeedback)) {
            cancel = true;
            etFeedback.setError("This field required");
        }
        return cancel;
    }

    //build left and right drawer layout
    /*private void initializeDrawers() {

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        mDrawerList = (ListView) findViewById(R.id.color_list_right_drawer);

        ObjectDrawerItem[] rdrawerItem = new ObjectDrawerItem[9];
        rdrawerItem[0] = new ObjectDrawerItem(0, name);
        // rdrawerItem[1] = new ObjectDrawerItem(R.drawable.icon_folder_128,"My Account");
        rdrawerItem[1] = new ObjectDrawerItem(R.drawable.ic_nav_myprofile, "My Profile");
        rdrawerItem[2] = new ObjectDrawerItem(R.drawable.ic_nav_changepassword, "Change Password");
        //  rdrawerItem[4] = new ObjectDrawerItem(R.drawable.group,"Create Group");
        //  rdrawerItem[5] = new ObjectDrawerItem(R.drawable.gear_128,"Settings");
        // rdrawerItem[3] = new ObjectDrawerItem(R.mipmap.ic_advertisement_nav, "All Advertisements");
        rdrawerItem[3] = new ObjectDrawerItem(R.drawable.ic_nav_bankinfo, "Update Bank Info");
        rdrawerItem[4] = new ObjectDrawerItem(R.drawable.ic_nav_myintrest, "My Interests");
        rdrawerItem[5] = new ObjectDrawerItem(R.drawable.ic_nav_browse_adv, "Browse All Merchants");
        rdrawerItem[6] = new ObjectDrawerItem(R.drawable.ic_nav_share, "Share With Friends");
        rdrawerItem[7] = new ObjectDrawerItem(R.drawable.ic_nav_help, "Help And Support");
        rdrawerItem[8] = new ObjectDrawerItem(R.mipmap.ic_logout_nav, "Logout");

        DrawerItemCustomAdapter radapter = new DrawerItemCustomAdapter(this, R.layout.listview_item_row, rdrawerItem);
        mDrawerList.setAdapter(radapter);
        mDrawerList.setOnItemClickListener(new lDrawerItemClickListener());
    }

    private class lDrawerItemClickListener implements AdapterView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position,
                                long id) {

            lDrawerSelectItem(position);
        }
    }

    private void lDrawerSelectItem(int position) {

        // update the main content by replacing fragments

        switch (position) {
            case 0:
                mDrawerLayout.closeDrawers();


                break;
            case 1:
                //  Toast.makeText(getApplicationContext(), "Update clicked", Toast.LENGTH_SHORT).show();
                mDrawerLayout.closeDrawers();
                Intent intentUpdate = new Intent(ActivitySendFeedback.this, ActivityMyProfile.class);
                intentUpdate.putExtra("loginId", loginId);
                intentUpdate.putExtra("from", "update");
                startActivity(intentUpdate);
                finish();

                break;
            case 2:
                mDrawerLayout.closeDrawers();

                // Toast.makeText(getApplicationContext(), "Change password clicked", Toast.LENGTH_SHORT).show();
                // ChangePasswordDialog();
                Intent intentChangPass = new Intent(ActivitySendFeedback.this, ChangePasswordActivity.class);
                intentChangPass.putExtra("loginId", loginId);
                intentChangPass.putExtra("from", "update");
                startActivity(intentChangPass);
                finish();

                break;
            case 3:
                mDrawerLayout.closeDrawers();
                Intent intent = new Intent(ActivitySendFeedback.this, EncashActivity.class);
                intent.putExtra("loginId", loginId);
                intent.putExtra("loginName", loginName);
                startActivity(intent);
                finish();

                break;
            case 4:
                mDrawerLayout.closeDrawers();
                Intent intentInterest = new Intent(ActivitySendFeedback.this, ActivityAreaOfInterest.class);
                startActivity(intentInterest);
                finish();

                break;
            case 5:
                mDrawerLayout.closeDrawers();
                Intent intentMerchant = new Intent(ActivitySendFeedback.this, ActivityNewMerchantListBrowse.class);
                intentMerchant.putExtra("loginId", loginId);
                startActivity(intentMerchant);
                finish();

                break;
            case 6:
                mDrawerLayout.closeDrawers();
                Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(Intent.EXTRA_TEXT, "Hey, I'm using ReferPlus app & I've found it amazing. It gives me reward points for recommending Merchants & helps me save money on shopping. That's not all, it also gives me credit points for interacting with advertisements.\n" +
                        "You too should start using it. Download today <link>");
                startActivity(Intent.createChooser(sharingIntent, "Share using"));
                break;
            case 7:
                mDrawerLayout.closeDrawers();
                Intent HelpSupport = new Intent(ActivitySendFeedback.this, HelpActivity.class);
                HelpSupport.putExtra("loginId", loginId);
                startActivity(HelpSupport);
                finish();

                break;
            case 8:
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putString("username", null);
                editor.putString("password", null);
                editor.putString("logout", "LOGOUT");
                editor.clear();
                editor.apply();
                mDrawerLayout.closeDrawers();
                stopService(new Intent(this, MerchantNotificationService.class));
                Intent intentLogout = new Intent(ActivitySendFeedback.this, LoginActivity.class);
                startActivity(intentLogout);
                finish();

                break;

            default:
                break;

        }

    }

    private void updateProfilePicture(String iMerchant_id, String ShopName, final String image, final Bitmap bmProfile) {
//Here we will handle the http request to insert user to mysql db
//Creating a RestAdapter

        *//*final RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter*//*
        final RestAdapter adapter = httpsAdapter.createAdapter(this);

//Creating object for our interface
        RestInterfac api = adapter.create(RestInterfac.class);
        Log.v("Before updating image", "123");

//Defining the method insertuser of our interface
        api.updateProfilePicture(
//Passing the values by getting it from editTexts
                iMerchant_id,
                ShopName,
                image,


//Creating an anonymous callback
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
//On success we will read the server's output using bufferedreader
//Creating a bufferedreader object
                        BufferedReader reader = null;

//An string to store output from the server
                        String output = "";
                        JSONObject json = null;
                        int getProfileSuccess = 0;
                        String imagePath = "";

                        try {
//Initializing buffered reader
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));

//Reading the output in the string
                            output = reader.readLine();
                            Log.e("", "Output: " + output);
                            Log.v("After updating image", "abc");
                            JSONTokener tokener = new JSONTokener(output);
                            try {
                                json = new JSONObject(tokener);
                                if (json != null) {
                                    System.out.println("JSON Object: " + json);
                                    getProfileSuccess = json.getInt("success");
                                    imagePath = json.getString("imagepath");
                                    CircleImageView imgProfile = (CircleImageView) findViewById(R.id.imageView1);
                                    imgProfile.setImageBitmap(bmProfile);

                                    SharedPreferences.Editor editor = getSharedPreferences(MyPREFERENCES, MODE_PRIVATE).edit();
                                    editor.putString(StaticDataMember.TAG_OUTLET_IMAGE, imagePath);
                                    editor.commit();

                                } else {
                                    Log.e("", "JSONobject is null");
                                }

                            } catch (JSONException e) {
                                Log.e("", "JSONExeption: " + e.getMessage());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }


                    }

                    @Override
                    public void failure(RetrofitError error) {
                        if (MyApplication.isActivityVisible()) {
//If any error occured displaying the error as toast
                            Toast.makeText(ActivitySendFeedback.this, error.toString(), Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
    }*/


    public static String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);

        switch (requestCode) {
            case StaticDataMember.SELECT_PROFILE_PHOTO:
                if (resultCode == RESULT_OK) {
                    //  mDrawerLayout.closeDrawer(ExpandList);
                    try {
                        String imgDecodableString;
                        Uri selectedImage = imageReturnedIntent.getData();

                        ImageCompression imgCmp = new ImageCompression(ActivitySendFeedback.this);

                        //for google uploaded photo
                        if (imgCmp.isNewGooglePhotosUri(selectedImage)) {
                            selectedImage = Uri.parse(imgCmp.getImageUrlWithAuthority(ActivitySendFeedback.this, selectedImage));
                        }


                        String[] filePathColumn = {MediaStore.Images.Media.DATA};

                        // Get the cursor
                        Cursor cursor = getContentResolver().query(selectedImage,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor.moveToFirst();

                        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                        imgDecodableString = cursor.getString(columnIndex);
                        cursor.close();


                        File aFile = new File(imgDecodableString);

                        //final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                        Bitmap bmProfile = null;

                        bmProfile = imgCmp.compressImage(aFile.getAbsolutePath());

                        //ivProfile.setImageBitmap(bmProfile);
                        String strImage1 = getStringImage(bmProfile);
                        try {
                            ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
                            if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                    connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
                                updateProfilePicture(loginId, name, strImage1, bmProfile);
                            } else //No Internet connection
                            {
//noDataConnectionAlert();
                                Toast.makeText(ActivitySendFeedback.this, "No internet connection", Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            Log.e("Log", "connectivity manager " + e.getMessage());
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
                break;
        }
    }*/

    public void showDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx, R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                Intent nxt = new Intent(ActivitySendFeedback.this, MainActivity.class);
                startActivity(nxt);
                ActivitySendFeedback.this.finish();
            }
        });

        builder.show();
    }

    private void setFeedData(final String userId,final String message)
    {
        class SendingData extends AsyncTask<String,Void,String>
        {
            ProgressDialog pDialog;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pDialog = new ProgressDialog(ActivitySendFeedback.this);
                pDialog.setMessage("Loading...");
                pDialog.show();

            }

            @Override
            protected String doInBackground(String... strings) {
                String SetServerString = "";
             /*try{
                   // URLEncode user defined data
                    String   userId_1    = URLEncoder.encode(userId.toString(), "UTF-8");
                    String  message_1  = URLEncoder.encode(message.toString(), "UTF-8");

                    // Create http cliient object to send request to server

                    HttpClient Client = new DefaultHttpClient();

                    // Create URL string

                    String URL = "http://app.gravitybusinessservices.com/Users/addFeedbackapp?userid="+userId_1+"&&message="+message_1;

                    //Log.i("httpget", URL);
                 System.out.println("Receiving Response "+URL);

                 try
                    {

                        // Create Request to server and get response

                        HttpGet httpget = new HttpGet(URL);
                        ResponseHandler<String> responseHandler = new BasicResponseHandler();
                        SetServerString = Client.execute(httpget, responseHandler);

                        System.out.println("Receiving Response "+SetServerString);

                        // Show response on activity


                    }
                    catch(Exception ex)
                    {
                        ex.printStackTrace();
                    }
                }
                catch(UnsupportedEncodingException ex)
                {

                }*/
                HashMap<String,String> stringStringHashMap=new HashMap<>();
                stringStringHashMap.put("userid",userId);
                stringStringHashMap.put("message",message);

                String   userId_1="",message_1="";
                try {
                    userId_1    = URLEncoder.encode(userId.toString(), "UTF-8");
                    message_1  = URLEncoder.encode(message.toString(), "UTF-8");

                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

                //http://app.gravitybusinessservices.com/Users/addFeedbackapp?userid=42&&message=testing_msg

                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost(StaticDataMember.feedbackurl+
                        userId_1+"&message="+message_1);

                try {
                    // Add your data
                    httppost.setEntity(new UrlEncodedFormEntity(getHashMapToNameValuePair(stringStringHashMap)));
                    // Execute HTTP Post Request
                    HttpResponse response = httpclient.execute(httppost);
                    InputStream inputStream = response.getEntity().getContent();
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    StringBuilder stringBuilder = new StringBuilder();
                    String bufferedStrChunk = "";
                    while((bufferedStrChunk = bufferedReader.readLine()) != null){
                        stringBuilder.append(bufferedStrChunk);
                    }
                    System.out.println(" Getting Response "+stringBuilder.toString());
                    return stringBuilder.toString();
                } catch (ClientProtocolException e) {
                    e.printStackTrace();
                    // TODO Auto-generated catch block
                } catch (IOException e) {
                    e.printStackTrace();

                    // TODO Auto-generated catch block
                }
                return  SetServerString;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pDialog.dismiss();
                parseLoginResponse(s);

            }
        }

        new SendingData().execute();

    }
    public ArrayList<NameValuePair> getHashMapToNameValuePair(HashMap<String, String> hashMap)
    {
        ArrayList<NameValuePair> dataValues = new ArrayList<NameValuePair>();
        for(Map.Entry<String, String> entry : hashMap.entrySet()){
            dataValues.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
            //        System.out.println("Values sending in server :: key "+entry.getKey()+"value: "+entry.getValue());
        }

        return dataValues;
    }
    private void sendData(String userId,String message) {

        final ProgressDialog pDialog = new ProgressDialog(ActivitySendFeedback.this);
        pDialog.setMessage("Loading...");
        pDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                "http://app.gravitybusinessservices.com/Users/addFeedbackapp?userid="+userId+"&&message="+message,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        System.out.println("Response " + response);
                        if (response != null && !response.equals(""))
                            parseLoginResponse(response);
                        pDialog.dismiss();
                    }
                },

                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        pDialog.dismiss();
                        if (MyApplication.isActivityVisible()) {
//If any error occured displaying the error as toast
                            //Log.e("", "Retrofit error: " + error);
                            if (MyApplication.isActivityVisible()) {
                                //showDialog(HomeActivity.this, "Please check Internet Connection", "");
                                if (pDialog.isShowing()) {
                                    pDialog.dismiss();
                                }
                                showDialog(ActivitySendFeedback.this, "Feedback Not Recieved", "Your feedback could not be recorded. Please try again later.");
                            }
                        }
                        // Toast.makeText(getActivity(),"Check internet connection " , Toast.LENGTH_SHORT).show();





                    }
                }) {
            @Override
            protected void finalize() throws Throwable {
                super.finalize();
            }

            @Override
            protected VolleyError parseNetworkError(VolleyError volleyError) {
                return super.parseNetworkError(volleyError);
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type", "application/x-www-form-urlencoded");

                return headers;
            }

        };


        RequestQueue requestQueue = Volley.newRequestQueue(ActivitySendFeedback.this);

        requestQueue.add(stringRequest);
    }

    private void parseLoginResponse(String response) {
        try {

            //{"result":{"sucess":0,"error_msg":"No record found"}}

            JSONObject result = new JSONObject(response);
          //  JSONObject result = jsonObject.getJSONObject("result");
            int mSuccess = result.getInt("success");
                if (mSuccess == 1) {
                    if (MyApplication.isActivityVisible()) {
                        //showDialog(HomeActivity.this, "Please check Internet Connection", "");
                        etFeedback.setText("");
                        showDialog(ActivitySendFeedback.this, "Message Recieved", "Thank you "+name+" for your message. We at Rich n Happy Academy truly appreciate it & our expert will respond to you shortly.\n");

                        //Toast.makeText(ActivitySendFeedback.this, "Your feedback recorded successfully, Thank you!", Toast.LENGTH_LONG).show();
                    }else
                    {
                        showDialog(ActivitySendFeedback.this, "Feedback Not Recieved", "Your feedback could not be recorded. Please try again later.");

                    }
                /*    if (MyApplication.isActivityVisible()) {
                        //showDialog(HomeActivity.this, "Please check Internet Connection", "");
                        showDialog(ActivitySendFeedback.this, "Feedback Not Recieved", "Your feedback could not be recorded. Please try again later.");
                    }*/

            } else {
           }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    private void sendFeedback(String iMerchant_id, String userId, String message) {
//Here we will handle the http request to insert user to mysql db
//Creating a RestAdapter

        final ProgressDialog mProgressDialog = new ProgressDialog(ActivitySendFeedback.this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Sending...");
        mProgressDialog.show();


        //http://app.gravitybusinessservices.com/Users/addFeedbackapp?userid=42&&message=testing_msg


        final RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint("http://app.gravitybusinessservices.com/Users/addFeedbackapp?userid="+userId+"&&message="+message) //Setting the Root URL
             //   .setEndpoint(StaticDataMember.test_url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

//Creating object for our interface
        RestInterfac api = adapter.create(RestInterfac.class);


//Defining the method insertuser of our interface
        api.sendFeedback(
//Passing the values by getting it from editTexts
                userId,
                message,
//Creating an anonymous callback
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
//On success we will read the server's output using bufferedreader
//Creating a bufferedreader object
                        BufferedReader reader = null;

//An string to store output from the server
                        String output = "";
                        JSONObject json = null;
                        int mSuccess = 0;

                        try {
//Initializing buffered reader
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));

//Reading the output in the string
                            output = reader.readLine();
                            Log.e("", "Output: " + output);
                            Log.v("After updating image", "abc");
                            JSONTokener tokener = new JSONTokener(output);
                            try {
                                json = new JSONObject(tokener);
                                if (json != null) {
                                    System.out.println("JSON Object: " + json);
                                    mSuccess = json.getInt("success");

                                } else {
                                    Log.e("", "JSONobject is null");
                                }

                            } catch (JSONException e) {
                                Log.e("", "JSONExeption: " + e.getMessage());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        if (mSuccess == 1) {
                            if (MyApplication.isActivityVisible()) {
                                //showDialog(HomeActivity.this, "Please check Internet Connection", "");

                                if (mProgressDialog.isShowing()) {
                                    mProgressDialog.dismiss();
                                }
                                etFeedback.setText("");
                                showDialog(ActivitySendFeedback.this, "Message Recieved", "Thank you "+name+" for your message. We at Rich n Happy Academy truly appreciate it & our expert will respond to you shortly.\n");

                                //Toast.makeText(ActivitySendFeedback.this, "Your feedback recorded successfully, Thank you!", Toast.LENGTH_LONG).show();
                            }
                        }

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        if (MyApplication.isActivityVisible()) {
//If any error occured displaying the error as toast
                            //Log.e("", "Retrofit error: " + error);
                            if (MyApplication.isActivityVisible()) {
                                //showDialog(HomeActivity.this, "Please check Internet Connection", "");
                                if (mProgressDialog.isShowing()) {
                                    mProgressDialog.dismiss();
                                }
                                showDialog(ActivitySendFeedback.this, "Feedback Not Recieved", "Your feedback could not be recorded. Please try again later.");
                            }
                        }
                    }
                }
        );
    }

    @Override
    public void onResume() {
        super.onResume();
        MyApplication.activityResumed();
    }

    @Override
    public void onPause() {
        super.onPause();
        MyApplication.activityPaused();
    }

    @Override
    protected void onStop() {
        super.onStop();
        MyApplication.activityPaused();
    }


    protected void setHeader() {
        TextView header = (TextView) findViewById(R.id.header_text);
        header.setText("Talk To Experts");
        imgLogo = (ImageView) findViewById(R.id.imglogo);
        imgLogo.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent homeintent = new Intent(ActivitySendFeedback.this, MainActivity.class);
                startActivity(homeintent);
                ActivitySendFeedback.this.finish();
            }
        });
    }
    @Override
    public void onBackPressed() {
        //super.onBackPressed();

        Intent homeintent = new Intent(ActivitySendFeedback.this, MainActivity.class);
        startActivity(homeintent);
        ActivitySendFeedback.this.finish();
    }
}
