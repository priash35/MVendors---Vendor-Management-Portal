package com.example.hp.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "vehicle.db";
    public static final String TABLE_NAME = "vehicle_table";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "vehicle_no";
    public static final String COL_3 = "driver_name";
    public static final String COL_4 = "address";
    public static final String COL_5 = "contact";
    public static final String COL_6 = "fine";
    public static final String COL_7="radioButton";
    public static final String COL_8="bill";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME +" (ID INTEGER PRIMARY KEY AUTOINCREMENT,vehicle_no TEXT,driver_name TEXT,address TEXT,contact TEXT,fine TEXT,radioButton TEXT,bill TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

    public boolean insertData(String vehicle_no,String driver_name,String address,String contact,String fine,String radioButton) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,vehicle_no);
        contentValues.put(COL_3,driver_name);
        contentValues.put(COL_4,address);
        contentValues.put(COL_5,contact);
        contentValues.put(COL_6,fine);
        contentValues.put(COL_7,radioButton);
        contentValues.put(COL_8,"");
        long result = db.insert(TABLE_NAME,null ,contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }

/*    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME,null);
        return res;
    }*/


    public List<DatabaseModel> getDataFromDB(){
        List<DatabaseModel> modelList = new ArrayList<DatabaseModel>();
        String query = "select * from "+TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query,null);

        if (cursor.moveToFirst()){
            do {
                DatabaseModel model = new DatabaseModel();
                model.setID(cursor.getString(0));
                model.setVehicle_no(cursor.getString(1));
                model.setDriver_name(cursor.getString(2));
                model.setAddress(cursor.getString(3));
                model.setContact(cursor.getString(4));
                model.setFine(cursor.getString(5));
                model.setRadioButton(cursor.getString(6));
                model.setBill(cursor.getString(7));

                modelList.add(model);
            }while (cursor.moveToNext());
        }


        Log.d("student data", modelList.toString());


        return modelList;
    }


    public boolean updateData(String id,String vehicle_no,String driver_name,String address,String contact,String fine,String radioButton,String bill) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_1,id);
        contentValues.put(COL_2,vehicle_no);
        contentValues.put(COL_3,driver_name);
        contentValues.put(COL_4,address);
        contentValues.put(COL_5,contact);
        contentValues.put(COL_6,fine);
        contentValues.put(COL_7,radioButton);
        contentValues.put(COL_8,bill);
        db.update(TABLE_NAME, contentValues, "ID = ?",new String[] { id });
        return true;
    }

    public Integer deleteData (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "ID = ?",new String[] {id});
    }
}
