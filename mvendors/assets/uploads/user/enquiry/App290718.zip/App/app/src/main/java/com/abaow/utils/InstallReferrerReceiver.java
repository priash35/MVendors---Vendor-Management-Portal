package com.abaow.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/**
 * Created by chetan on 10/12/17.
 */
public class InstallReferrerReceiver extends BroadcastReceiver {
    SharedPreferences sharedpreferences;
    @Override
    public void onReceive(Context context, Intent intent) {
        String referrer = intent.getStringExtra("referrer");
        sharedpreferences = context.getSharedPreferences("mypref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString("Franchise", referrer);
        editor.apply();
        this.abortBroadcast();

        //Use the referrer
    }
}