package com.example.hp.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

public class UpdatePaymentDetails extends AppCompatActivity {

    String mode="cash";
    String id="";
    String name="";
    String no="";
    String address="";
    String contact="";
    String fine="";
    String pn="";
    String total="";
    String billdetails="";
    Button buttonupdate;
    DatabaseHelper helpher;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payment_details);
        buttonupdate=findViewById(R.id.buttonupdate);
        helpher = new DatabaseHelper(this);
        RadioGroup rg = (RadioGroup) findViewById(R.id.payment_mode);


        Intent intent = getIntent();
        id = intent.getStringExtra("ids");
        name = intent.getStringExtra("names");
        no=intent.getStringExtra("nos");
        address=intent.getStringExtra("adds");
        contact=intent.getStringExtra("conts");
        fine=intent.getStringExtra("fines");
        pn=intent.getStringExtra("pns");
        billdetails=intent.getStringExtra("bills");

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch(checkedId){
                    case R.id.cash:
                        mode="cash";
                        // do operations specific to this selection
                        break;
                    case R.id.card:
                        mode="card";
                        // do operations specific to this selection
                        break;
                    case R.id.online:
                        mode="Online";
                        // do operations specific to this selection
                        break;
                    case R.id.not_paid:
                        mode="Not Paid";
                        // do operations specific to this selection
                        break;

                }
            }
        });

        buttonupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isUpdate = helpher.updateData(id,no,name,address,contact,fine,mode,billdetails);

                if(isUpdate == true) {
                    Toast.makeText(UpdatePaymentDetails.this, "Data Update", Toast.LENGTH_LONG).show();
                    Intent intent1 = new Intent(UpdatePaymentDetails.this, SelectChoiceActivity.class);
                    startActivity(intent1);
                    finish();
                }
                else
                    Toast.makeText(UpdatePaymentDetails.this,"Data not Updated",Toast.LENGTH_LONG).show();
            }
        });
    }
}
