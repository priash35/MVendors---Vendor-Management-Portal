package com.abaow.utils;

public interface OnSmsCatchListener<T> {
    void onSmsCatch(String message);
}