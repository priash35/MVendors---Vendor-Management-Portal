package com.abaow;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.abaow.Adapters.ShowBlogsRecord;
import com.abaow.model.Blogs;
import com.abaow.utils.Drawer;
import com.abaow.utils.RestInterfac;
import com.abaow.utils.StaticDataMember;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class GetBlogs extends AppCompatActivity implements View.OnClickListener{
    SharedPreferences sharedpreferences;
    public static final String MyPREFERENCES = "mypref";
    RecyclerView listValues;
    private DrawerLayout mDrawerLayout;
    private ImageView imgDrawer,imgLogo;
    private Drawer dr;
    private String name;
    private TextView tvNotificationCount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_blogs);
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        listValues=(RecyclerView) findViewById(R.id.listValues);
        getUser();
        name= sharedpreferences.getString("login_name", "");
        ImageView ivNotification = (ImageView) findViewById(R.id.imgNotification);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        dr = new Drawer(this);
        dr.initializeDrawers(mDrawerLayout,name);
        imgDrawer = (ImageView) findViewById(R.id.imgDrawer);
        imgDrawer.setOnClickListener(this);

        setHeader();

        int countNotification = sharedpreferences.getInt("notificationCount", 0);

        tvNotificationCount = (TextView) findViewById(R.id.tvNotificationCount);

        tvNotificationCount.setText(String.valueOf(countNotification));

        ivNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvNotificationCount.setText("0");
                Intent notificationIntent = new Intent(GetBlogs.this, MerchantNotification.class);
                startActivity(notificationIntent);

            }
        });
    }


    public void getUser() {
        final ProgressDialog mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);
        //Creating a RestAdapter
        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter.create(RestInterfac.class);
        int userID = sharedpreferences.getInt("loggedin_user_id", 0);

        System.out.print(userID);



        //Defining the method insertuser of our interface
        api.getBlogs(
                //String.valueOf(userID),
                String.valueOf(userID),
                //Passing the values by getting it from editTexts

                //Creating an anonymous callback
                new retrofit.Callback<Response>() {

                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                         //An string to store output from the server
                        String output = "";
                        JSONObject userinfo = null;
                        JSONArray usercourse = null;
                        JSONObject json = null;
                        Intent nxt;
                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);

                            System.out.println("Output Value "+output);
                            json = new JSONObject(tokener);
                            if (json != null) {

                                GsonBuilder gsonBuilder = new GsonBuilder();
                                gsonBuilder.setDateFormat("M/d/yy hh:mm a"); //Format of our JSON dates
                                Gson gson = gsonBuilder.create();
                                List<Blogs> posts = new ArrayList<>();
                                posts =  Arrays.asList(gson.fromJson(json.getJSONArray("blogs").toString(), Blogs[].class));

                                ShowBlogsRecord showBlogsRecord=new ShowBlogsRecord(GetBlogs.this,posts);
                                LinearLayoutManager mLayoutManager = new LinearLayoutManager(GetBlogs.this);
                                listValues.setLayoutManager(mLayoutManager);
                                listValues.setAdapter(showBlogsRecord);
                                System.out.println("List Values "+posts.size());

                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();

                         /*else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Invalid Credentials", "please enter valid Email_Id and Password");
                        }*/

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //If any error occured displaying the error as toast
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                  //      showDialog(GetBlogs.this, "Please check Internet Connection", "");
                    }
                }
        );

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgDrawer:
                mDrawerLayout.openDrawer(dr.mDrawerList);
                break;

        }
    }

    @Override
    public void onResume() {
        super.onResume();
        MyApplication.activityResumed();
    }

    @Override
    public void onPause() {
        super.onPause();
        MyApplication.activityPaused();
    }

    @Override
    protected void onStop() {
        super.onStop();
        MyApplication.activityPaused();
    }


    protected void setHeader() {
        TextView header = (TextView) findViewById(R.id.header_text);
        header.setText("Blogs");
        imgLogo = (ImageView) findViewById(R.id.imglogo);
        imgLogo.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent homeintent = new Intent(GetBlogs.this, MainActivity.class);
                startActivity(homeintent);
                GetBlogs.this.finish();
            }
        });
    }
    @Override
    public void onBackPressed() {
        //super.onBackPressed();

        Intent homeintent = new Intent(GetBlogs.this, MainActivity.class);
        startActivity(homeintent);
        GetBlogs.this.finish();
    }
}
