package com.abaow.utils;

/**
 * Created by admin on 10/21/2016.
 */
public class StaticDataMember {

  //  public static final String url = "http://app.gravitybusinessservices.com/";

    //public static final String url = "http://app.gravitybusinessservices.com/";

    //production url

    public static final String youtubeurl = "http://www.richandhappy.co.in/Users/get_video_url";

    public static final String feedbackurl = "http://www.richandhappy.co.in/Users/addFeedbackapp?userid=";

    public static final String url = "http://www.richandhappy.co.in/";

    public final static String TAG_NOTIFICATION_DATA = "notifications";

}
