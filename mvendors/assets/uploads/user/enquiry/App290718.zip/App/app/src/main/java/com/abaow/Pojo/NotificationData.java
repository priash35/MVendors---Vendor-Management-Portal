package com.abaow.Pojo;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 * Created by vaibhav on 15/11/16.
 */
@DatabaseTable
public class NotificationData {

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTextNotification() {
        return textNotification;
    }

    public void setTextNotification(String textNotification) {
        this.textNotification = textNotification;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getmDate() {
        return mDate;
    }

    public void setmDate(String mDate) {
        this.mDate = mDate;
    }

    @DatabaseField(unique = true)
    private int id;
    @DatabaseField
    private String textNotification;
    @DatabaseField
    private String status;
    @DatabaseField
    private String mDate;

    public String getmLoginId() {
        return mLoginId;
    }

    public void setmLoginId(String mLoginId) {
        this.mLoginId = mLoginId;
    }

    @DatabaseField
    private String mLoginId;
}
