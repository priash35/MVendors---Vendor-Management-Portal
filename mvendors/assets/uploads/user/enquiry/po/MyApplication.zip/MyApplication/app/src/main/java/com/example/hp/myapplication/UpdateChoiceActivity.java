package com.example.hp.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class UpdateChoiceActivity extends AppCompatActivity {

    Button btnPaymentDetails;
    Button btnFineDetails;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_choice);

        btnPaymentDetails = findViewById(R.id.btnPaymentDetails);
        btnFineDetails = findViewById(R.id.btnFineDetails);

        btnPaymentDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(UpdateChoiceActivity.this, PaymentDetailsActivity.class);
                startActivity(intent);
            }
        });

        btnFineDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(UpdateChoiceActivity.this, FineDetailsActivity.class);
                startActivity(intent);
            }
        });
    }
}
