package com.abaow.Pojo;

/**
 * Created by vaibhav on 26/10/16.
 */
public class City {
    public int getmCityId() {
        return mCityId;
    }

    public void setmCityId(int mCityId) {
        this.mCityId = mCityId;
    }

    public String getmCityName() {
        return mCityName;
    }

    public void setmCityName(String mCityName) {
        this.mCityName = mCityName;
    }

    private int mCityId;
    private String mCityName;
}
