package com.abaow.notification;


import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;


/**
 * Created by Belal on 5/27/2016.
 */


//Class extending FirebaseInstanceIdService
public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {


    private static final String TAG = "MyFirebaseIIDService";

    /**
     * Called if InstanceID token is updated. This may occur if the security of
     * the previous token had been compromised. Note that this is called when the InstanceID token
     * is initially generated so this is where you would retrieve the token.
     */
    // [START refresh_token]
    @Override
    public void onTokenRefresh() {
        // Get updated InstanceID token.
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.d(TAG, "Refreshed token: " + refreshedToken);

        // If you want to send messages to this application instance or
        // manage this apps subscriptions on the server side, send the
        // Instance ID token to your app server.
        sendRegistrationToServer(refreshedToken);
    }
    // [END refresh_token]

    /**
     * Persist token to third-party servers.
     *
     * Modify this method to associate the user's FCM InstanceID token with any server-side account
     * maintained by your application.
     *
     * @param token The new token.
     */
    private void sendRegistrationToServer(String token) {
        // TODO: Implement this method to send token to your app server.
    }




   /* private static final String TAG = "MyFirebaseIIDService";
    public static SharedPreferences pref;
    ProgressDialog progressDialog;

    @Override
    public void onTokenRefresh() {
        //Getting registration token

        try {
            String refreshedToken = FirebaseInstanceId.getInstance().getToken();
            pref = getSharedPreferences("mypref", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = pref.edit();
            editor.putString("deviceId", refreshedToken);
            editor.apply();
       *//* try {
            writeException(refreshedToken);
        } catch (IOException e) {
            e.printStackTrace();
        }*//*
            //Displaying token on logcat
            Log.d(TAG, "Refreshed token: " + refreshedToken);
            //Method to Send Token to the server
            sendRegistrationToServer(refreshedToken);
        }catch (Exception e)
        {
            try {
                writeException_1(e.toString());
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }
    public static void writeException_1(String msg) throws IOException {
        String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());

        String file_name = UtilityFile.getRootDir() + File.separator + "error_file" + ".txt";
        try {
            PrintWriter writer = new PrintWriter(file_name, "UTF-8");
            writer.println(msg);


            writer.close();
        } catch (IOException e) {
            // do something
        }

    }
    private void sendRegistrationToServer(String token) {
        //You can implement this method to store the token on your server 
        //Not required for current project

        //Call to asynctask for sending token id of device
     //   new PassTokenIdClass().execute(token);
    }

   *//* *       Asynctask to send user id & device token id to the server
    * *//*
 *//*   private class PassTokenIdClass extends AsyncTask<String,Void,String> {

        @Override
        protected String doInBackground(String... params) {
//API: http://cardealer89.com.bh-in-10.webhostbox.net/gurumantra/webservice/webservice.php?
// action=update_device_token&student_id=1&device_token_id=2255
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
            nameValuePairs.add(new BasicNameValuePair("device_token_id",params[0]));
            nameValuePairs.add(new BasicNameValuePair("student_id", SharedPreferenceUtil.getStudentId(getApplicationContext())));
            nameValuePairs.add(new BasicNameValuePair(ServerClass.ACTION, "update_device_token"));
            ServerClass ruc = new ServerClass();
            String data = ruc.postData(APPURL.URL, nameValuePairs);
            System.out.println("value in sending in Firebasee GM::  " + nameValuePairs);
            System.out.println("value in response in firebasee GM::  " + data);
            return data;
        }

        *//**//**   Pre method
        **//**//*
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        *//**//**   Post method
        **//**//*
        @Override
        protected void onPostExecute(String response) {
            super.onPostExecute(response);
            Toast.makeText(MyFirebaseInstanceIDService.this, response, Toast.LENGTH_SHORT).show();
            responseDeviceToken(response);
        }
    }
 *//*   *//*
    *   Parse response from server
    * *//*
    private void responseDeviceToken(String s) {
        try{
//            {"result":{"sucess":1}}
            JSONObject response = new JSONObject(s);
            JSONObject result = response.getJSONObject("result");
            String success = result.getString("sucess");
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public static void writeException(String msg) throws IOException {
        String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());

        String file_name = UtilityFile.getMediaPath() + mydate + "token_key" + ".txt";
        try {
            PrintWriter writer = new PrintWriter(file_name, "UTF-8");
            writer.println(msg);

            writer.close();
        } catch (IOException e) {
            // do something
        }

    }
*/
}