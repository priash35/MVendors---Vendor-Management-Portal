package com.abaow.LocalDB;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;
import android.text.Html;
import android.util.Log;

import com.abaow.MainActivity;
import com.abaow.MerchantNotification;
import com.abaow.Pojo.NotificationData;
import com.abaow.R;
import com.abaow.utils.StaticDataMember;
import com.abaow.utils.RestInterfac;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by vaibhav on 19/9/16.
 */
public class MerchantNotificationService extends Service {
    public static final int MERCHANT_NOTIFICATION_ID = 0;
    private static final String TAG = MerchantNotificationService.class.getSimpleName();
    public static final String BROADCAST_ACTION = "com.abaow";
    private static final String TAG_SUCCESS = "success";
    final Handler handler = new Handler();
    Timer timer = new Timer();
    private static final String TAG_LOGIN_ID = "loggedin_user_id";
    private String userLoginId;
    private SharedPreferences prefs;
    Intent intent;


    public MerchantNotificationService() {

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public void onCreate() {
        //prefs = PreferenceManager.getDefaultSharedPreferences(this);
        prefs = getSharedPreferences("mypref", MODE_PRIVATE);
        userLoginId = Integer.toString(prefs.getInt(TAG_LOGIN_ID, 0));
        intent = new Intent(BROADCAST_ACTION);
        if (userLoginId == null || userLoginId.isEmpty() || userLoginId.equals("null")){
            stopSelf();

        }
        Log.v("From Service:","Service Started");
    }

    @Override
    public void onStart(Intent intent, int startId) {
        // Perform your long running operations here.
        TimerTask doAsynchronousTask = new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    public void run() {
                        if (userLoginId == null || userLoginId.isEmpty() || userLoginId.equals("null")) {
                            stopSelf();
                        }

                        try {
                            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                            if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                    connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
                                getNotificationDetail(userLoginId, getCurrentTimeStamp(), "From");
                            } else {

                            }

                        } catch (Exception e) {
                            Log.e(this.getClass().getName(), "connectivity manager " + e.getMessage());
                        }

                    }
                });
            }
        };
        timer.schedule(doAsynchronousTask, 0, 50000); //execute in every 50000 ms //10000 corr


    }

    // Send a notification
    private void sendNotification(String msg) {
        Log.i(TAG, "sendNotification: " + msg);

        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        stackBuilder.addParentStack(MainActivity.class);

        PendingIntent notificationPendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, MerchantNotification.class), 0);
        // Creating and sending Notification
        NotificationManager notificatioMng =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificatioMng.notify(
                MERCHANT_NOTIFICATION_ID,
                createNotification(msg, notificationPendingIntent));
    }

    // Create a notification
    private Notification createNotification(String msg, PendingIntent notificationPendingIntent) {
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this);
        //Bitmap largeIcon = BitmapFactory.decodeResource(getResources(), R.drawable.absmalllogo);
        notificationBuilder
                .setSmallIcon(R.drawable.abaow_logo_transparent)
                //.setLargeIcon(largeIcon)
                .setColor(getResources().getColor(R.color.blue))
                .setContentTitle("Rich n Happy Notification")
                .setContentText(Html.fromHtml(msg))
                .setContentIntent(notificationPendingIntent)
                .setDefaults(Notification.DEFAULT_LIGHTS | Notification.DEFAULT_VIBRATE)
                .setAutoCancel(true);
        return notificationBuilder.build();
    }


    private void getNotificationDetail(String userid, String dateTime, String from) {
        //While the app fetched data we are displaying a progress dialog
        //Creating a rest adapter
        final RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url)
                .build();
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating an object of our api interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method
        api.getNotification(
                //Passing the values by getting it from editTexts
                userid,
                dateTime,

                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        //Dismissing the loading progressbar
                        //Calling a method to show the list
                        BufferedReader reader = null;


                        //An string to store output from the server
                        String output = "";
                        int success = 0;
                        SharedPreferences sharedpreferences = getSharedPreferences("mypref", MODE_PRIVATE);
                        int notificationCount = sharedpreferences.getInt("notificationCount", 0);
                        JSONObject json = null;
                        List<String> notifiactionData = new ArrayList<String>();
                        ;
                        try {
                            //Initializing buffered reader
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));

                            //Reading the output in the string


                            output = reader.readLine();
                            System.out.println("OUTPUT: " + output);

                            JSONTokener tokener = new JSONTokener(output);
                            try {
                                json = new JSONObject(tokener);
                                if (json != null) {
                                    System.out.println("JSON Object Service: " + json);
                                    success = json.getInt(TAG_SUCCESS);
                                    JSONArray productObj = json.getJSONArray(StaticDataMember.TAG_NOTIFICATION_DATA); // JSON Array
                                    DatabaseHelper helper = new DatabaseHelper(getApplicationContext());
                                    for (int i = 0; i < productObj.length(); i++) {
                                        JSONObject data = productObj.getJSONObject(i); //ith element

                                        NotificationData obj = new NotificationData();
                                        obj.setmDate(getCurrentTimeStamp());
                                        obj.setTextNotification(data.getString("notification"));
                                        obj.setId(Integer.parseInt(data.getString("notification_id")));
                                        obj.setmDate(data.getString("creation_date"));
                                        obj.setmLoginId(userLoginId);
                                        int returnSuccess = helper.addData(obj);
                                        if (returnSuccess != 0) {
                                            notificationCount++;
                                            notifiactionData.add(data.getString("notification"));
                                        }

                                    }
                                } else {
                                    Log.e(TAG, "JSONobject is null");
                                }

                            } catch (JSONException e) {
                                Log.e(TAG, "JSONExeption: " + e.getMessage());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        if (success == 1) {
                            if (!notifiactionData.isEmpty()) {
                                SharedPreferences.Editor editor = prefs.edit();
                                editor.putInt("notificationCount", notificationCount);
                                editor.apply();
                                sendNotification(notifiactionData.get(notifiactionData.size() - 1));
                                intent.putExtra("counter", String.valueOf(notificationCount));
                                sendBroadcast(intent);
                            }

                        } else {


                        }
                    }

                    @Override
                    public void failure(RetrofitError error) {

                    }
                });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        onStart(intent, startId);
        return START_NOT_STICKY;
    }

    /**
     * @return yyyy-MM-dd HH:mm:ss formate date as string
     */
    public static String getCurrentTimeStamp() {
        try {

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String currentDateTime = dateFormat.format(new Date()); // Find todays date

            return currentDateTime;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}
