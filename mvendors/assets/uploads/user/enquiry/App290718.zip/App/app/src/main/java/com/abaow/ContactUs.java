package com.abaow;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.util.Linkify;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.util.Locale;

public class ContactUs extends AppCompatActivity {

    TextView website , email , phone1 , phone2 , address ;

    TextView tvwebsite , tvemail , tvphone , tvaddress;

    Toolbar toolbar;

    Context context;

    Typeface notoFace, notoFaceBold;

    double lat = 18.504758;
    double lng = 73.841984;

    public static final String addressuri = "Flat 101, Suvarnagad Apartment,14, Raejendra nagar, Navi Peth, Sadashiv Peth, Pune, Maharashtra 411030";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);

        notoFace = Typeface.createFromAsset(getApplicationContext().getAssets(), "NotoSans-Regular.ttf");
        notoFaceBold = Typeface.createFromAsset(getApplicationContext().getAssets(), "NotoSans-Regular.ttf");


        website = (TextView) findViewById(R.id.website);
        email = (TextView) findViewById(R.id.email);
        phone1 = (TextView) findViewById(R.id.phoneone);
        phone2 = (TextView) findViewById(R.id.phonetwo);
        address = (TextView) findViewById(R.id.address);

        website.setTypeface(notoFaceBold);
        email.setTypeface(notoFaceBold);
        phone1.setTypeface(notoFaceBold);
        phone2.setTypeface(notoFaceBold);
        address.setTypeface(notoFaceBold);


        tvwebsite = (TextView) findViewById(R.id.tvwebsite);
        tvemail = (TextView) findViewById(R.id.tvemail);
        tvphone = (TextView) findViewById(R.id.tvphone);
        tvaddress = (TextView) findViewById(R.id.tvaddress);

        tvwebsite.setTypeface(notoFace);
        tvemail.setTypeface(notoFace);
        tvphone.setTypeface(notoFace);
        tvaddress.setTypeface(notoFace);


        toolbar = (Toolbar) findViewById(R.id.toolbarcontactus);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Contact Us");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

       /* website.setText("http://www.abaow.com");
        Linkify.addLinks(website, Linkify.WEB_URLS);*/

        address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
        String strUri = "http://maps.google.com/maps?q=loc:" + lat + "," + lng + " (" + "Ashish Bhave's Academy Of Wealth" + ")";
        Intent intent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse(strUri));

        intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");

        startActivity(intent);

            }
        });
            /*address.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String uri = "http://maps.google.co.in/maps?q=" + addressuri;
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                    context.startActivity(intent);

                }
            });*/
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    if (getParentActivityIntent() == null) {
                        // Log.i(TAG, "You have forgotten to specify the parentActivityName in the AndroidManifest!");
                        onBackPressed();
                    } else {
                        NavUtils.navigateUpFromSameTask(this);
                    }
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
