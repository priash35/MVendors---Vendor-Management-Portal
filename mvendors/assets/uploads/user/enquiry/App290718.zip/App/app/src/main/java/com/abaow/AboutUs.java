package com.abaow;

import android.graphics.Typeface;
import android.os.Build;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

public class AboutUs extends AppCompatActivity {
    Toolbar toolbar;
    TextView vision , visionstmt , mission , missionstmt;
    TextView para1 , paras2 , para3;
    Typeface notoFace, notoFaceBold;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        toolbar = (Toolbar) findViewById(R.id.toolbaraboutus);
        setSupportActionBar(toolbar);
        toolbar.setTitle("About Us");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        notoFace = Typeface.createFromAsset(getApplicationContext().getAssets(), "NotoSans-Regular.ttf");
        notoFaceBold = Typeface.createFromAsset(getApplicationContext().getAssets(), "NotoSans-Regular.ttf");

        vision = (TextView) findViewById(R.id.vision);
        vision.setTypeface(notoFaceBold);

        visionstmt = (TextView) findViewById(R.id.visionstmt);
        visionstmt.setTypeface(notoFace);

       /* mission = (TextView) findViewById(R.id.mission);
        mission.setTypeface(notoFaceBold);

        missionstmt = (TextView) findViewById(R.id.missionstmt);
        missionstmt.setTypeface(notoFace);*/

        para1 = (TextView) findViewById(R.id.tvfirstpara);
        paras2 = (TextView) findViewById(R.id.tvsecondpara);
        para3 = (TextView) findViewById(R.id.tvthirdpara);

        para1.setTypeface(notoFace);
        paras2.setTypeface(notoFace);
        para3.setTypeface(notoFace);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    if (getParentActivityIntent() == null) {
                        // Log.i(TAG, "You have forgotten to specify the parentActivityName in the AndroidManifest!");
                        onBackPressed();
                    } else {
                        NavUtils.navigateUpFromSameTask(this);
                    }
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}

