package com.abaow.Adapters;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.abaow.CourseOverview;
import com.abaow.Pojo.Course;
import com.abaow.R;
import com.squareup.picasso.Picasso;


import java.util.ArrayList;

/**
 * Created by admin on 8/24/2016.
 */
public class OtherCourseAdapter extends RecyclerView
        .Adapter<OtherCourseAdapter
        .DataObjectHolder> {

    //private static final String TAG = CustomAdapter.class.getSimpleName();
    private String coupon_id, customer_id, return_to_id;

    private ArrayList<Course> listArray = new ArrayList<>();
    Typeface notoFace, notoFaceBold;

    SharedPreferences sharedpreferences;
    ViewGroup par;
    private int screenWidth;
    private ProgressDialog mProgressDialog;
    private String currency = "Rs.";


    Context context;
    FragmentManager fragmentManager;


    public OtherCourseAdapter(Context context) {
        this.context = context;
    }

    public OtherCourseAdapter(ArrayList<Course> list, Context context) {

        listArray.addAll(list);
        this.context = context;


    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.course_list_other, parent, false);
        par = parent;
        sharedpreferences = parent.getContext().getSharedPreferences("mypref", Context.MODE_PRIVATE);
        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        notoFace = Typeface.createFromAsset(parent.getContext().getAssets(), "NotoSans-Regular.ttf");
        notoFaceBold = Typeface.createFromAsset(parent.getContext().getAssets(), "NotoSans-Bold.ttf");

        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(OtherCourseAdapter.DataObjectHolder holder, int position) {

        //   holder.cpvalue.setText("Rs." + listArray.get(position).getCpValue() + " OFF");
        holder.tvCoursename.setText(listArray.get(position).getCoursename());
        holder.tvinstructor.setText("Course Mentor: "+UppercaseFirstLetters(listArray.get(position).getInstructor()));
        holder.tvFee.setText(currency.toString()+listArray.get(position).getFee());
        holder.tvcurrentstatus.setText(listArray.get(position).getMax());
        //holder.tvIntro.setText(listArray.get(position).getAudio());
//        holder.txtdistance.setText(listArray.get(position).getDistancemeters());


        holder.tvCoursename.setTypeface(notoFaceBold);
        holder.tvinstructor.setTypeface(notoFace);
        holder.tvcurrentstatus.setTypeface(notoFaceBold);
        /*switch (listArray.get(position).getLanguage()){
            case "2":
                holder.llcardview.setBackgroundColor(ContextCompat.getColor(context, R.color.fire_red));
                break;
            default:
                break;
        }*/
        //holder.tvstartdate.setTypeface(notoFace);


        /*PicassoTrustAll.getInstance(par.getContext())
                .load(listArray.get(position).getMerchant_logo())
                .into(holder.shopimg);*/
        if (!listArray.get(position).getImage().isEmpty()) {
            Picasso.with(par.getContext())
                    .load(listArray.get(position).getImage())
                    .into(holder.imCourse);
        }

    }

    @Override
    public int getItemCount() {
        return listArray.size();
    }

    public class DataObjectHolder extends RecyclerView.ViewHolder
            implements View
            .OnClickListener {

        TextView tvCoursename,tvinstructor,tvcurrentstatus,tvstartdate,tvCourseDesc,tvIntro,tvFee;
        ImageView imCourse;
        CardView llcardview;

        public DataObjectHolder(View itemView) {
            super(itemView);
            // cpvalue = (TextView) itemView.findViewById(R.id.tvcpValue);
            tvCoursename = (TextView) itemView.findViewById(R.id.tvcoursename);
            tvinstructor = (TextView) itemView.findViewById(R.id.tvinstructor);
            tvcurrentstatus = (TextView) itemView.findViewById(R.id.tvcurrentstatus);
           // tvstartdate = (TextView) itemView.findViewById(R.id.tvstartdate);
            llcardview = (CardView) itemView.findViewById(R.id.card_view_other);
            tvFee = (TextView) itemView.findViewById(R.id.tvFeeAmount);
            imCourse = (ImageView) itemView.findViewById(R.id.imgCourse);

            //onclick listener
            llcardview.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {
            Course course = listArray.get(getAdapterPosition());
            switch (v.getId()) {

                case R.id.card_view_other:
                    // Toast.makeText(context, "btnRatingsClicked..", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(context, CourseOverview.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("course", course.getCourseid());
                    context.startActivity(intent);
                    ((Activity)context).finish();

                    break;

            }

        }
    }



    public static String UppercaseFirstLetters(String str) {
        boolean prevWasWhiteSp = true;
        char[] chars = str.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if (Character.isLetter(chars[i])) {
                if (prevWasWhiteSp) {
                    chars[i] = Character.toUpperCase(chars[i]);
                }
                prevWasWhiteSp = false;
            } else {
                prevWasWhiteSp = Character.isWhitespace(chars[i]);
            }
        }
        return new String(chars);
    }


}