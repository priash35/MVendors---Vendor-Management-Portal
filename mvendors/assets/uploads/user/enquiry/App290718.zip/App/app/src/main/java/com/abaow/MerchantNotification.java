package com.abaow;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.abaow.LocalDB.DatabaseHelper;
import com.abaow.Pojo.NotificationData;
//import com.ele45.referrer.referrer.adapter.DrawerItemCustomAdapter;
import com.abaow.utils.Drawer;

import java.util.ArrayList;
import java.util.List;

//import de.hdodenhof.circleimageview.CircleImageView;


public class MerchantNotification extends AppCompatActivity implements View.OnClickListener {

    private final static String TAG = MerchantNotification.class.getSimpleName();
    private List<NotificationData> notificationList;
    private DatabaseHelper helper;

    private SharedPreferences sharedpreferences;
    private int loginId, loginName;

    private ListView lsNotification;
    private ImageView ivDrawer;

    private ArrayAdapter<String> adapter1;

    private TextView tvNoNotifications;

    private DrawerLayout mDrawerLayout;
    private ImageView imgDrawer;
    private Drawer dr;
    private String name,activityname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merchantnotification);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        dr = new Drawer(this);
        initialiseView();
        setHeader();

        imgDrawer = (ImageView) findViewById(R.id.imgDrawer);
        imgDrawer.setOnClickListener(this);

        //initializeDrawers();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgDrawer:

                mDrawerLayout.openDrawer(dr.mDrawerList);

                break;
        }
    }

    private void initialiseView() {
        sharedpreferences = getSharedPreferences("mypref", Context.MODE_PRIVATE);
        loginId = sharedpreferences.getInt("loggedin_user_id", 0);
        //loginName = sharedpreferences.getString("login_name", null);
        name = sharedpreferences.getString("login_name", "");
        dr.initializeDrawers(mDrawerLayout, name);
        Log.v("name to be printed", "" + name);

        if (loginId == 0) {
            this.finish();
            return;
            //loginId = getIntent().getExtras().getString("loggedin_user_id");

        }

        notificationList = new ArrayList<NotificationData>();
        helper = new DatabaseHelper(getApplicationContext());
        notificationList = helper.GetData(Integer.toString(loginId));
        tvNoNotifications = (TextView) findViewById(R.id.tvNoNotification);
        lsNotification = (ListView) findViewById(R.id.lsNotification);

        List<String> values = new ArrayList<String>();
        if (notificationList != null) {
            for (NotificationData data : notificationList) {
                values.add(data.getTextNotification());// + "<br><small>Date: " + data.getmDate()+"</small></br>");
            }
        }
        adapter1 = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, values) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View row;

                if (null == convertView) {
                    LayoutInflater inflater = (LayoutInflater) MerchantNotification.this
                            .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    row = inflater.inflate(android.R.layout.simple_list_item_1, null);
                } else {
                    row = convertView;
                }

                TextView tv = (TextView) row.findViewById(android.R.id.text1);
                tv.setText(getItem(position));
                tv.setTextColor(getResources().getColor(R.color.text_gray));
                tv.setBackground(getResources().getDrawable(R.drawable.bg_gray_border));

                //LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayoutCompat.LayoutParams.MATCH_PARENT, LinearLayoutCompat.LayoutParams.WRAP_CONTENT);
                //params.setMargins(15,10,15,10);
                //tv.setLayoutParams(params);


                return row;
            }

        };

        lsNotification
                .setAdapter(adapter1);

        if (adapter1.isEmpty()) {
            lsNotification.setVisibility(View.GONE);
            tvNoNotifications.setVisibility(View.VISIBLE);
        }
        lsNotification.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                DeleteDialoge(i);
            }
        });

        ImageView ivNotification = (ImageView) findViewById(R.id.imgNotification);
        TextView tvNotificationCount = (TextView) findViewById(R.id.tvNotificationCount);
        ivNotification.setImageResource(R.color.Bluebuttonbackgroundcolor);
        tvNotificationCount.setVisibility(View.GONE);
        //tvNotificationCount.setText("");


        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putInt("notificationCount", 0);
        editor.apply();

        /*ImageView imgLogo = (ImageView) findViewById(R.id.imgLogo);
        imgLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("loggedin_user_id", sharedpreferences.getString("loggedin_user_id", null));
                intent.putExtra("login_name", sharedpreferences.getString("login_name", null));
                startActivity(intent);
                finish();
            }
        });*/

        Typeface notoFaceBold = Typeface.createFromAsset(getResources().getAssets(), "NotoSans-Bold.ttf");
       /* String mCityname = sharedpreferences.getString("CITY_NAME", null);
        String mCityId = sharedpreferences.getString("CITY_ID", null);
        TextView tvLocation = (TextView) findViewById(R.id.tvLocation);
        tvLocation.setTypeface(notoFaceBold);
        tvLocation.setText(ActivityCoupon.UppercaseFirstLetters(mCityname));*/
    }

    /**
     *
     *
     */
    private void DeleteDialoge(final int position) {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(MerchantNotification.this, R.style.MyDialogTheme);
        builder1.setTitle("Remove Notification");
        String Message1 = "Do you want to remove notification from list?";
        builder1.setMessage(Html.fromHtml(Message1));
        builder1.setIcon(android.R.drawable.ic_dialog_alert);
        builder1.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                helper.deleteData(notificationList.get(position));
                adapter1.remove(adapter1.getItem(position));
                adapter1.notifyDataSetChanged();
                dialog.dismiss();
            }
        });
        builder1.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder1.show();
    }
    @Override
    public void onBackPressed() {
       /* Class newclass = null;
        try {
            newclass = Class.forName(activityname);
        } catch (ClassNotFoundException c) {
            c.printStackTrace();
        }
        Intent homeintent = new Intent(MerchantNotification.this, newclass);
        startActivity(homeintent);*/

        MerchantNotification.this.finish();
    }
    protected void setHeader() {
        TextView header = (TextView) findViewById(R.id.header_text);
        header.setText("Notifications");
        ImageView imgLogo = (ImageView) findViewById(R.id.imglogo);
        imgLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeintent = new Intent(MerchantNotification.this, MainActivity.class);
                startActivity(homeintent);
                MerchantNotification.this.finish();
            }
        });
    }
}

