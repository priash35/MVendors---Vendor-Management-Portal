package com.abaow.Pojo;

import android.util.Log;

import com.abaow.utils.RestInterfac;
import com.abaow.utils.StaticDataMember;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by admin on 4/20/2016.
 */
public class Curriculum {


    public int getCourseid() {
        return courseid;
    }

    public void setCourseid(int courseid) {
        this.courseid = courseid;
    }

    public String getModulename() {
        return modulename;
    }

    public void setModulename(String modulename) {
        this.modulename = modulename;
    }

    public String getAudio() {
        return audio;
    }

    public void setAudio(String audio) {
        this.audio = audio;
    }

    public int getQuiz() {
        return quiz;
    }

    public void setQuiz(int quiz) {
        this.quiz = quiz;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public int getModuleid() {
        return moduleid;
    }

    public void setModuleid(int moduleid) {
        this.moduleid = moduleid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    private int courseid;


    private int moduleid;
    private String modulename;
    private String audio;
    private int quiz;
    private String description;
    private String duration;
    private String order;
    private String status;






    public Curriculum(int mcourseid, int mmoduleid,String mmodulename, String maudio, int mquiz, String mdescription, String mduration, String morder, String mstatus) {
        this.courseid = mcourseid;
        this.modulename = mmodulename;
        this.audio = maudio;
        this.quiz = mquiz;
        this.description = mdescription;
        this.duration = mduration;
        this.order = morder;
        this.moduleid = mmoduleid;
        this.status = mstatus;


    }


    }







