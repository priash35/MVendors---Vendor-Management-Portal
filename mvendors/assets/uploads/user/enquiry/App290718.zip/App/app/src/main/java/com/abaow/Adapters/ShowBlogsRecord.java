package com.abaow.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.abaow.GetBlogs;
import com.abaow.R;
import com.abaow.ShowBlogDetails;
import com.abaow.model.Blogs;
import com.j256.ormlite.stmt.query.In;
import com.squareup.picasso.Picasso;

import java.io.Serializable;
import java.util.List;

/**
 * Created by vikaspc2 on 3/21/2018.
 */

public class ShowBlogsRecord extends RecyclerView.Adapter<ShowBlogsRecord.ViewHolder> {
    Context c;
    List<Blogs> data;
    public ShowBlogsRecord(Context c, List<Blogs> data) {
        this.c=c;
        this.data=data;
    }

    @Override
    public ShowBlogsRecord.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(c).inflate(R.layout.blog_record, parent, false);
        ShowBlogsRecord.ViewHolder vh = new ShowBlogsRecord.ViewHolder(v);
        System.out.println("Value in Recycler constructor:: ");

        // Return the ViewHolder
        return vh;
    }

    @Override
    public void onBindViewHolder(ShowBlogsRecord.ViewHolder holder, final int position) {
        holder.title.setText(data.get(position).getBlog_title());
        holder.description.setText(data.get(position).getBlog_content());
        if((data.get(position).getBlog_img()!=null)&&(!data.get(position).getBlog_img().equals("")))
        {
            Picasso.with(c).load(data.get(position).getBlog_img()).into(holder.imgPic);
        }
        holder.baseRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(c, ShowBlogDetails.class);
                i.putExtra("blogValue",data.get(position));
                c.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView title,description;
        LinearLayout baseRow;
        ImageView imgPic;
        public ViewHolder(View item) {
            super(item);
            title=(TextView) item.findViewById(R.id.title);
            description=(TextView) item.findViewById(R.id.description);
            imgPic=(ImageView) item.findViewById(R.id.imgPic);
            baseRow=(LinearLayout) item.findViewById(R.id.baseRow);
        }
            @Override
        public void onClick(View v) {

        }
    }
}


