package com.abaow.media;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

/**
 * Created by vikaspc2 on 3/17/2017.
 */
public class StoringValues {

    public static SharedPreferences pref;
    public static SharedPreferences.Editor editor;



    public static String getUserId(Context activity) {
        pref =activity.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        String id = pref.getString("user_id", null);
        Log.v("SharedPreferenece:: ","get userId::"+id);
        return id;
    }
    public static String getAppointmentId(Activity activity) {
        pref =activity.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        String id = pref.getString("City_Name", null);
        Log.v("SharedPreferenece:: ","get userId::"+id);
        return id;
    }
    public static String getUserName(Activity activity) {
        pref =activity.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        String id = pref.getString("user_name", null);
        Log.v("SharedPreferenece:: ","get user_name::"+id);
        return id;
    }
    public static String getUserEmail(Activity activity) {
        pref =activity.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        String id = pref.getString("user_email", null);
        Log.v("SharedPreferenece:: ","get user_name::"+id);
        return id;
    }
    public static String getUserGender(Activity activity) {
        pref =activity.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        String id = pref.getString("user_gender", null);
        Log.v("SharedPreferenece:: ","get user gender::"+id);
        return id;
    }
    public static String getUserAge(Activity activity) {
        pref =activity.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        String id = pref.getString("user_age", null);
        Log.v("SharedPreferenece:: ","get user age::"+id);
        return id;
    }

    public static void setUserId(Context activity, String userId) {
        pref =activity.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("user_id", userId);
        editor.commit();

        Log.v("SharedPref course_id:: ","Saved ::"+userId);
    }
public static void setAppointmentId(Activity activity, String userId) {
        pref =activity.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("City_Name", userId);
        editor.commit();

        Log.v("SharedPref course_id:: ","Saved ::"+userId);
    }
   public static void setUserName(Activity activity, String userId) {
        pref =activity.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("user_name", userId);
        editor.commit();

        Log.v("SharedPref user name:: ","Saved ::"+userId);
    }
    public static void setUserEmail(Activity activity, String userId) {
        pref =activity.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("user_email", userId);
        editor.commit();

        Log.v("SharedPref email :: ","Saved :: "+userId);
    }

    public static void setUserGender(Activity activity, String userId) {
        pref =activity.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("user_gender", userId);
        editor.commit();

        Log.v("Shared user gender:: ","Saved :: "+userId);
    }
    public static void setUserAge(Activity activity, String userId) {
        pref =activity.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("user_age", userId);
        editor.commit();

        Log.v("Shared user user age:: ","Saved :: "+userId);
    }



    public static void LogOut(Activity activity){

        pref =activity.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.remove("user_id");
        editor.remove("user_email");
        editor.remove("user_name");
        editor.remove("City_Name");
        editor.clear();
        editor.commit();
        Log.v("SharedPreferenece:: ", "Logout ::");
    }


}

