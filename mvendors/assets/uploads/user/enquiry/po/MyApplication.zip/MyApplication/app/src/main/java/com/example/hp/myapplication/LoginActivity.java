package com.example.hp.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private EditText et_uname, et_password;
    private TextView register;
    private String uname;
    private String password;
    Button btnUserLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        et_uname= findViewById(R.id.editUname);
        et_password= findViewById(R.id.editUpass);
        btnUserLogin = findViewById(R.id.btnUserLogin);
        btnUserLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                uname=et_uname.getText().toString().trim();
                password=et_password.getText().toString().trim();
                if(uname.equals("admin") && password.equals("admin"))
                {
                    Intent i=new Intent(LoginActivity.this,SelectChoiceActivity.class);
                    startActivity(i);
                    Toast.makeText(LoginActivity.this,"Login Successful..." ,Toast.LENGTH_SHORT ).show();
                }
                else
                {
                    Toast.makeText(LoginActivity.this,"Invalid Email or Password..." ,Toast.LENGTH_SHORT ).show();
                }
            }
        });
    }

}
