package com.abaow.utils;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import com.abaow.R;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayer.Provider;
import com.google.android.youtube.player.YouTubePlayerView;

import java.util.HashMap;

public class PLayVideos extends YouTubeBaseActivity implements
        YouTubePlayer.OnInitializedListener {

    private YouTubePlayer YPlayer;
    private static  String YoutubeDeveloperKey = "";
    private static final int RECOVERY_DIALOG_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_videos);
        YoutubeDeveloperKey=getResources().getString(R.string.youtube_api_key);
        YouTubePlayerView youTubeView = (YouTubePlayerView) findViewById(R.id.youtube_view);
        youTubeView.initialize(YoutubeDeveloperKey, this);
  //      new ViewVideo().execute();
    }
/*
    class ViewVideo extends AsyncTask<String,Void,String>
    {
        @Override
        protected String doInBackground(String... params) {
            ServerClass s = new ServerClass();
            */
/*
            http://udyotexamples.com/TTA/webservice/webservice.php?action=get_chapter_list&sessionid=1*//*

            */
/* passing parameters for getting homescreen data*//*

*/
/*http://cardealer89.com.bh-in-10.webhostbox.net/TTA/webservice/webservice.php?action=view_video
&user_id=1&video_id=1*//*

            HashMap<String, String> get_data = new HashMap<>();
            get_data.put(getResources().getString(R.string.action), getResources().getString(R.string.view_video));
            get_data.put(getResources().getString(R.string.user_id), StoringValues.getUserId(PLayVideos.this));
            if(getIntent().getStringExtra(getResources().getString(R.string.video_id))!=null)
            {
                get_data.put(getResources().getString(R.string.video_id),getIntent().getStringExtra(getResources().getString(R.string.video_id)));
            }
            String  result = s.sendPostRequest(getResources().getString(R.string.webservice), get_data);
            return result;
        }
    }
*/

    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider,
                                        YouTubeInitializationResult errorReason) {
        if (errorReason.isUserRecoverableError()) {
            errorReason.getErrorDialog(this, RECOVERY_DIALOG_REQUEST).show();
        } else {
            String errorMessage = String.format(
                    "There was an error initializing the YouTubePlayer",
                    errorReason.toString());
            Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == RECOVERY_DIALOG_REQUEST) {
            // Retry initialization if user performed a recovery action
            getYouTubePlayerProvider().initialize(YoutubeDeveloperKey, this);
        }
    }

    protected YouTubePlayer.Provider getYouTubePlayerProvider() {
        return (YouTubePlayerView) findViewById(R.id.youtube_view);
    }

    @Override
    public void onInitializationSuccess(Provider provider,
                                        YouTubePlayer player, boolean wasRestored) {
        YPlayer = player;
 /*
 * Now that this variable YPlayer is global you can access it
 * throughout the activity, and perform all the player actions like
 * play, pause and seeking to a position by code.
 */
        System.out.println("Executing Video ");
        if (!wasRestored) {
//https://youtu.be/kFgSxivTWQQ
            SharedPreferences prefs = this.getSharedPreferences("mypref", this.MODE_PRIVATE);
            //userLoginId = prefs.getString(TAG_LOGIN_ID, null);

            String acceptedurl = prefs.getString("videourl", null);

            YPlayer.loadVideo(acceptedurl);
            YPlayer.setPlayerStyle(YouTubePlayer.PlayerStyle.DEFAULT);
        }
    }

}