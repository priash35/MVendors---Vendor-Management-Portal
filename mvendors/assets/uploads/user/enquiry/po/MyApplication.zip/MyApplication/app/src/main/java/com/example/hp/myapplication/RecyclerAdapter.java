package com.example.hp.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {

    static List<DatabaseModel> dbList;
    static Context context;

    RecyclerAdapter(Context context, List<DatabaseModel> dbList ){
        this.dbList = new ArrayList<DatabaseModel>();
        this.context = context;
        this.dbList = dbList;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemLayoutView = LayoutInflater.from(viewGroup.getContext()).inflate(
                R.layout.layout_displaydata, null);

        // create ViewHolder

        ViewHolder viewHolder = new ViewHolder(itemLayoutView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {

        viewHolder.name.setText(dbList.get(i).getDriver_name());
        viewHolder.vehical_no.setText(dbList.get(i).getVehicle_no());
        viewHolder.contact.setText(dbList.get(i).getContact());
        viewHolder.address.setText(dbList.get(i).getAddress());
        viewHolder.fine.setText(dbList.get(i).getFine());
        viewHolder.paidornot.setText(dbList.get(i).getRadioButton());
       /* viewHolder.lineardata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context,DetailsFine.class);
                Bundle extras = new Bundle();
                extras.putInt("position",i);
                intent.putExtras(extras);

            *//*
            int i=getAdapterPosition();
            intent.putExtra("position", getAdapterPosition());*//*
                context.startActivity(intent);

            }
        });*/
    }

    @Override
    public int getItemCount() {
        return dbList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, vehical_no, address, contact, fine, paidornot;
        LinearLayout lineardata;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            vehical_no = itemView.findViewById(R.id.vehicalno);
            address = itemView.findViewById(R.id.address);
            contact = itemView.findViewById(R.id.contact);
            fine = itemView.findViewById(R.id.fine);
            lineardata = itemView.findViewById(R.id.lineardata);
            paidornot = itemView.findViewById(R.id.paidornot);
        }

    }

}
