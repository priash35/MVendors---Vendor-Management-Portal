package com.abaow;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.abaow.utils.RestInterfac;
import com.abaow.utils.StaticDataMember;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class StatusActivity extends AppCompatActivity {
    int userid,courseid;
    String status,coursename,orderid;
    ProgressDialog mProgressDialog;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_status);
        Intent mainIntent = getIntent();
        userid = mainIntent.getIntExtra("userid", 0);
        courseid = mainIntent.getIntExtra("courseid", 0);
        coursename = mainIntent.getStringExtra("coursename");
        //status = mainIntent.getStringExtra("transStatus");
        orderid = mainIntent.getStringExtra("orderid");
        //TextView tv4 = (TextView) findViewById(R.id.textView1);
        //tv4.setText(status);


        switch (mainIntent.getStringExtra("transStatus")){
            case "Transaction Successful!":
                status = "Success";
                break;
            case "Transaction Declined!":
                status = "Declined";
                break;
            case "Transaction Cancelled!":
                status = "Aborted";
                break;
            default:
                status = "Error";
                break;

        }
        updatestatus();
        if (status.equals("Success")) {
            registercourse();
        }else{
            showfailDialog(StatusActivity.this,"Payment "+status,"Please try again later or contact ABAOW");
        }

    }


    protected void registercourse() {

        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);
        //Creating a RestAdapter
        RestAdapter adapter1 = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter1.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.registercourse(
                courseid,
                userid,


                //Passing the values by getting it from editTexts


                //Creating an anonymous callback
                new retrofit.Callback<Response>() {


                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;
                        JSONArray usercourse = null;
                        JSONArray curriculum = null;


                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {


                                success = json.getInt("success");


                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                        // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}

                        if (success == 1) {
                            if (mProgressDialog.isShowing())
                                mProgressDialog.dismiss();
                            try {
                                showNextDialog(StatusActivity.this, "Registration Successful", "You have been registered for the course " + coursename.toString());

                            } catch (Exception e) {
                                Log.e("json error: ", e.toString());
                            }

                        } else {
                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(StatusActivity.this, "Invalid Credentials", "Please enter valid email or Password");

                        }
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //If any error occured displaying the error as toast
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                            showDialog(StatusActivity.this, "Network Error", "Problem connecting to internet. Please try again later");
                    }

                }
        );
    }
    public void showDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx,R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        builder.show();

    }
    public void showNextDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx, R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                Intent nxt = new Intent(StatusActivity.this, MainActivity.class);
                startActivity(nxt);
                StatusActivity.this.finish();
            }
        });

        builder.show();

    }
    protected void updatestatus() {

        //Creating a RestAdapter
        RestAdapter adapter1 = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter1.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.updatestatus(
                orderid,
                status,
                //Creating an anonymous callback
                new retrofit.Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;


                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);
                            json = new JSONObject(tokener);
                            if (json != null) {
                                success = json.getInt("success");
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //If any error occured displaying the error as toast

                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(StatusActivity.this, "Network Error", "Problem connecting to internet. Please try again later");
                    }

                }
        );
    }
    public void showfailDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx,R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                Intent nxt = new Intent(StatusActivity.this, CourseOverview.class);
                nxt.putExtra("course",courseid);
                startActivity(nxt);
                StatusActivity.this.finish();
            }
        });

        builder.show();

    }


}
