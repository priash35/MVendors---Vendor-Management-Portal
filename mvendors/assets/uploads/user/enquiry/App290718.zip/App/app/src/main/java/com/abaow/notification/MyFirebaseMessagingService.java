package com.abaow.notification;


import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.abaow.GetBlogs;
import com.abaow.R;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;


/**
 * Created by Belal on 5/27/2016.
 */

public class MyFirebaseMessagingService extends FirebaseMessagingService {


    private static final String TAG = "FirebaseMessageService";
    Bitmap bitmap;

    /**
     * Called when message is received.
     *
     * @param remoteMessage Object representing the message received from Firebase Cloud Messaging.
     */
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // There are two types of messages data messages and notification messages. Data messages are handled
        // here in onMessageReceived whether the app is in the foreground or background. Data messages are the type
        // traditionally used with GCM. Notification messages are only received here in onMessageReceived when the app
        // is in the foreground. When the app is in the background an automatically generated notification is displayed.
        // When the user taps on the notification they are returned to the app. Messages containing both notification
        // and data payloads are treated as notification messages. The Firebase console always sends notification
        // messages. For more see: https://firebase.google.com/docs/cloud-messaging/concept-options
        //
        Log.d(TAG, "From: " + remoteMessage.getFrom());

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());
        }

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
        }

        //The message which i send will have keys named [message, image, AnotherActivity] and corresponding values.
        //You can change as per the requirement.

        //message will contain the Push Message
        String message = remoteMessage.getData().get("message");
        //imageUri will contain URL of the image to be displayed with Notification
        String imageUri = remoteMessage.getData().get("image");
        //If the key AnotherActivity has  value as True then when the user taps on notification, in the app AnotherActivity will be opened.
        //If the key AnotherActivity has  value as False then when the user taps on notification, in the app MainActivity will be opened.
        String TrueOrFlase = remoteMessage.getData().get("AnotherActivity");

        String title = remoteMessage.getData().get("title");

        //To get a Bitmap image from the URL received
        bitmap = getBitmapfromUrl(imageUri);

        sendNotification(message, title , bitmap, TrueOrFlase);

    }


    /**
     * Create and show a simple notification containing the received FCM message.
     */

    private void sendNotification(String messageBody,String title, Bitmap image, String TrueOrFalse) {
        Intent intent = new Intent(this, GetBlogs.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("AnotherActivity", TrueOrFalse);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 /* Request code */, intent,
                PendingIntent.FLAG_ONE_SHOT);

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setLargeIcon(image)/*Notification icon image*/
                .setSmallIcon(R.drawable.common_google_signin_btn_icon_dark)
                /*.setContentTitle(messageBody).setContentTitle(title)*/
                .setStyle(new NotificationCompat.BigPictureStyle()
                        .bigPicture(image))/*Notification with Image*/
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent);

                NotificationCompat.BigTextStyle bigTextStyle =new  NotificationCompat.BigTextStyle();
                bigTextStyle.setBigContentTitle(title).bigText(messageBody);
                notificationBuilder.setStyle(bigTextStyle);


        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(0 /* ID of notification */, notificationBuilder.build());
    }

    /*
    *To get a Bitmap image from the URL received
    * */
    public Bitmap getBitmapfromUrl(String imageUrl) {
        try {
            URL url = new URL(imageUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            return bitmap;

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;

        }
    }

   /* private static final String TAG = "MyFirebaseMsgService";
    private static String user_trip_id;
    public static SharedPreferences pref;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        //Displaying data in log
        //It is optional
        Log.d(TAG, "From: " + remoteMessage.getFrom());
        Log.d(TAG, "Notification Message Body: " + remoteMessage.getNotification().getBody());
        Log.d(TAG, "Notification Message tITLE: " + remoteMessage.getNotification().getBody());
        Log.d(TAG, "Customer obj" + remoteMessage.getData());
        Log.d(TAG, "Customer msgtype flagg" + remoteMessage.getNotification().getTag());

        try {
            //remoteMessage.getData()
          //  if(remoteMessage.getNotification().getTag().equals("1"))
            sendNotification(remoteMessage.getNotification().getBody(),
                    remoteMessage.getNotification().getTitle(),
                    remoteMessage.getNotification().getTag(),remoteMessage.getData());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //This method is only generating push notification
    //It is same as we did in earlier posts 
    private void sendNotification(String messageBody, String messageTitle, String messageTag, Map<String,String> dataValues) {
        Intent intent=null ;//= new Intent(this, MainActivity.class);
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        String imageUri="";
        if(dataValues.get("image")!=null)
        imageUri = dataValues.get("image");
        Bitmap bitmap=null;
        if(imageUri!=null&&!imageUri.equals(""))
        bitmap = getBitmapfromUrl(imageUri);

*//*
* Tag values : a) for Assigned : 1
b) For Evaluated: 2
3) For Shared :  3
d) For commented: 4
* *//*

*//*        if(messageTag.equals("1"))
        {
            String id=dataValues.get("assignment_id");
            String title=dataValues.get("assignment_title");
            intent = new Intent(getApplicationContext(),AssignmentDetailsActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("assignment_id", id);
            intent.putExtra("tab_type_id", "1");
            intent.putExtra("str_title", title);
        }

        if(messageTag.equals("3"))
        {
            intent = new Intent(getApplicationContext(),ShareActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        }
        if(messageTag.equals("4"))
        {
        *//**//*    strAnsId = intent.getStringExtra("answer_id");
            strAssignmentId = intent.getStringExtra("assignment_id");
            strMainTitle = intent.getStringExtra("str_title");
*//**//*

            String answer_id=dataValues.get("ans_id");
            String id=dataValues.get("assignment_id");
            String title=dataValues.get("assignment_title");


            intent = new Intent(getApplicationContext(),ViewMyWorkActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
           *//**//* intent.putExtra("assignment_id", id);
            intent.putExtra("answer_id", answer_id);
            intent.putExtra("str_title", title);*//**//*
            intent.putExtra("assignment_id", id);
            intent.putExtra("shared_wid_me", "0");
            intent.putExtra("answer_id", answer_id);
            intent.putExtra("stringTitle",title);
        }
        if(messageTag.equals("5"))
        {

            *//**//* strAnsId = intent.getStringExtra("answer_id");
        strAssignmentId = intent.getStringExtra("assignment_id");
        strMainTitle = intent.getStringExtra("str_title");*//**//*
            String answer_id=dataValues.get("ans_id");
            String id=dataValues.get("assignment_id");
            String title=dataValues.get("assignment_title");
            System.out.println("Evaluation values answer_id "+answer_id+" id "+id+" title "+title);
            intent = new Intent(getApplicationContext(),EvaluationActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("assignment_id", id);
            intent.putExtra("call_from", "evaluation_list");
            intent.putExtra("answer_id", answer_id);
            intent.putExtra("str_title", title);

        }

        if(messageTag.equals("6"))
        {
            String login_status=dataValues.get("login_status");
            String student_id=dataValues.get("student_id");
            String faculty_id=dataValues.get("faculty_id");

            intent = new Intent(getApplicationContext(),FacultyListActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("login_status", login_status);
            intent.putExtra("student_id", student_id);
            intent.putExtra("faculty_id", faculty_id);

             System.out.println("Evaluation values student_id "+student_id+" login_status "+login_status+" faculty_id  "+faculty_id);

        }*//*
      *//*  if (messageTag.equals("1")) {
            System.out.println(" for Assigned : 1 number" + messageTag);
            intent = new Intent(getApplicationContext(), AssignmentDetailsActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            setMsgTag();

        } else if (messageTag.equals("2")) {
            System.out.println("for  For Evaluated: 2 number" + messageTag);
            dataRemove();
            intent = new Intent(getApplicationContext(),AssignmentDetailsActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);



          } else if (messageTag.equals("4")) {



        }*//*
        Bitmap icon = BitmapFactory.decodeResource(getApplicationContext().getResources(), R.drawable.abslogo_noti);

        Intent notificationIntent = new Intent(getApplicationContext(), MerchantNotification.class);
        notificationIntent.putExtra("callFrom","noti");
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent,
                PendingIntent.FLAG_ONE_SHOT);

        if(bitmap==null) {
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                    .setSmallIcon(R.drawable.abslogo_noti)
                    .setContentTitle(messageTitle)
                    .setContentText(messageBody)
                     .setSound(defaultSoundUri)
                    .setContentIntent(pendingIntent);
            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(0, notificationBuilder.build());
        }else
        {
            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                    .setSmallIcon(R.drawable.abslogo_noti)
                    .setContentTitle(messageTitle)
                    .setContentText(messageBody)
                    .setAutoCancel(true)
                    .setStyle(new NotificationCompat.BigPictureStyle()
                            .bigPicture(bitmap))*//*Notification with Image*//*
                    .setSound(defaultSoundUri)
                    .setContentIntent(pendingIntent);
            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.notify(0, notificationBuilder.build());

        }
    }


    public Bitmap getBitmapfromUrl(String imageUrl) {
        try {
            URL url = new URL(imageUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            return bitmap;

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;

        }
    }
    //    stores msg tag in shared preferences
    private void setMsgTag() {

    }

    //    Method to remove data on cancellation of booking
    private void dataRemove() {
        pref = getSharedPreferences("MyPrefsFile", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.remove("nearestLat");
        editor.remove("nearestLong");
        editor.remove("user_trip_id");
        editor.remove("trans_id");
        System.out.println("trip id after canellation in service::: " + user_trip_id);
//        editor.clear();
        editor.commit();
        System.out.println("in dataremove......transsaction id in service: " + user_trip_id);
        Log.v("SharedPreferenece:: ", "Logout ::");
    }*/
}