package com.abaow;

import android.graphics.Typeface;
import android.os.Build;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.MenuItem;
import android.widget.TextView;

public class PrivacyPolicy extends AppCompatActivity {

    Toolbar toolbar;

    Typeface notoFace, notoFaceBold;

    TextView para1 , para2 , para3 , para4 , para5 , para6 , para7 , para8 , para9 , para10 , para11;

    TextView useoftheapp , disclaimer , privacypolicy , refund , limitationofliability,textlink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_policy);
        toolbar = (Toolbar) findViewById(R.id.toolbaraprivacypolicy);
        setSupportActionBar(toolbar);
        toolbar.setTitle("Privacy Policy");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        useoftheapp = (TextView) findViewById(R.id.useoftheapp);
        disclaimer = (TextView) findViewById(R.id.disclaimer);
        privacypolicy = (TextView) findViewById(R.id.privacypolicy);
        refund  = (TextView) findViewById(R.id.refundandcancellation);
        limitationofliability = (TextView) findViewById(R.id.limitationofliability);
        textlink = (TextView) findViewById(R.id.textlink);

        useoftheapp.setTypeface(notoFaceBold);
        disclaimer.setTypeface(notoFaceBold);
        privacypolicy.setTypeface(notoFaceBold);
        refund.setTypeface(notoFaceBold);
        limitationofliability.setTypeface(notoFaceBold);

        para1 = (TextView) findViewById(R.id.paraone);
        para2 = (TextView) findViewById(R.id.paratwo);
        para3 = (TextView) findViewById(R.id.parathree);
        para4 = (TextView) findViewById(R.id.parafour);
        para5 = (TextView) findViewById(R.id.para5);
        para6 = (TextView) findViewById(R.id.para6);
        para7 = (TextView) findViewById(R.id.para7);
        para8 = (TextView) findViewById(R.id.para8);
        para9 = (TextView) findViewById(R.id.para9);
        para10 = (TextView) findViewById(R.id.para10);
        para11 = (TextView) findViewById(R.id.para11);

        para1.setTypeface(notoFace);
        para2.setTypeface(notoFace);
        para3.setTypeface(notoFace);
        para4.setTypeface(notoFace);
        para5.setTypeface(notoFace);
        para6.setTypeface(notoFace);
        para7.setTypeface(notoFace);
        para8.setTypeface(notoFace);
        para9.setTypeface(notoFace);
        para10.setTypeface(notoFace);
        para11.setTypeface(notoFace);


        notoFace = Typeface.createFromAsset(getApplicationContext().getAssets(), "NotoSans-Regular.ttf");
        notoFaceBold = Typeface.createFromAsset(getApplicationContext().getAssets(), "NotoSans-Regular.ttf");


        textlink.setClickable(true);
        textlink.setMovementMethod(LinkMovementMethod.getInstance());
        String text = "<a href='http://www.richandhappy.co.in/admin/privacy_policy'> For more details click here </a>";
        textlink.setText(Html.fromHtml(text));


    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    if (getParentActivityIntent() == null) {
                        // Log.i(TAG, "You have forgotten to specify the parentActivityName in the AndroidManifest!");
                        onBackPressed();
                    } else {
                        NavUtils.navigateUpFromSameTask(this);
                    }
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
