package com.abaow;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.abaow.Adapters.CurrentCourseAdapter;
import com.abaow.Adapters.OtherCourseAdapter;
import com.abaow.LocalDB.MerchantNotificationService;
import com.abaow.Pojo.Course;
import com.abaow.utils.Drawer;
import com.abaow.utils.RestInterfac;
import com.abaow.utils.StaticDataMember;
import com.abaow.utils.UtilityFile;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;

import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private CardView llcurrentcourse;
    private LinearLayout llothercourse;
    private static final int READ_INTERNET_PERMISSIONS_REQUEST = 333;
    private TextView tvNotificationCount;
    SharedPreferences sharedpreferences;
    private RecyclerView.Adapter    customadapter,customadapterother;
    public RecyclerView mRecyclerView,mRecyclerView1;
    private String  coursejson = "",name = "Test";
    private JSONArray coursejsonObj,othercourse;
    private Course course = null;
    private ArrayList<Course> listArray = new ArrayList<>();
    private ArrayList<Course> listArray1 = new ArrayList<>();
    private int userid;

    public static final String MyPREFERENCES = "mypref";

    private DrawerLayout mDrawerLayout;
    private ImageView imgDrawer;
    private Drawer dr;

    ProgressDialog mProgressDialog;
    int countNotification;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       /* Intent i = new Intent("com.android.vending.INSTALL_REFERRER");
//Set Package name
        i.setPackage("com.abaow");
//referrer is a composition of the parameter of the campaing
        i.putExtra("referrer", "ABCDEFG");
        sendBroadcast(i);
*/
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
         countNotification= sharedpreferences.getInt("notificationCount", 0);
        userid = sharedpreferences.getInt("loggedin_user_id", 0);
        name= sharedpreferences.getString("login_name", "");
        setnotification();
        setHeader();


        loadcurrcourses();

        if(sharedpreferences.getString("deviceId","")!=null)
        {
            try {
                System.out.println("Device Id "+sharedpreferences.getString("deviceId",""));
                writeException(sharedpreferences.getString("deviceId",""));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        startService(new Intent(this, MerchantNotificationService.class));
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        dr = new Drawer(this);
        dr.initializeDrawers(mDrawerLayout,name);
        imgDrawer = (ImageView) findViewById(R.id.imgDrawer);
        imgDrawer.setOnClickListener(MainActivity.this);


        if(getIntent().getStringExtra("callFrom")!=null)
        {
            Intent i=new Intent(MainActivity.this,MerchantNotification.class);
            startActivity(i);
        }


        if (getIntent().getExtras() != null) {

            for (String key : getIntent().getExtras().keySet()) {
                String value = getIntent().getExtras().getString(key);

                if (key.equals("AnotherActivity") && value.equals("True")) {
                    Intent intent = new Intent(this,GetBlogs.class);
                    intent.putExtra("value", value);
                    startActivity(intent);
                    finish();
                }


            }
        }

        subscribeToPushService();

    }



    private void subscribeToPushService() {
        FirebaseMessaging.getInstance().subscribeToTopic("news");

        Log.d("AndroidBash", "Subscribed");

        //Toast.makeText(MainActivity.this, "Subscribed", Toast.LENGTH_SHORT).show();

        String token = FirebaseInstanceId.getInstance().getToken();

        // Log and toast
        Log.d("AndroidBash", "" + token);

        // Toast.makeText(MainActivity.this, token, Toast.LENGTH_SHORT).show();
    }



    public static void writeException(String msg) throws IOException {
        String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());

        String file_name = UtilityFile.getMediaPath() + mydate + "token_key" + ".txt";
        try {
            PrintWriter writer = new PrintWriter(file_name, "UTF-8");
            writer.println(msg);


            writer.close();
        } catch (IOException e) {
            // do something
        }

    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgDrawer:

                    mDrawerLayout.openDrawer(dr.mDrawerList);

                break;
        }
    }

    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateUI(intent);

        }
    };

    /**
     * Method is used to set notification count
     *
     * @param intent
     */
    private void updateUI(Intent intent) {
        String counter = intent.getStringExtra("counter");
        tvNotificationCount.setText(String.valueOf(counter));
        if (Integer.valueOf(counter) > 0){
            tvNotificationCount.setText("0");
            Intent notificationIntent = new Intent(MainActivity.this, MerchantNotification.class);
            //notificationIntent.putExtra("parent",MainActivity.this.getClass().getSimpleName());
            startActivity(notificationIntent);
            //MainActivity.this.finish();
        }

    }
    @Override
    public void onResume() {
        super.onResume();
        MyApplication.activityResumed();
        registerReceiver(broadcastReceiver, new IntentFilter(MerchantNotificationService.BROADCAST_ACTION));

    }

    @Override
    public void onPause() {
        super.onPause();
        MyApplication.activityPaused();
        unregisterReceiver(broadcastReceiver);

    }
    public void loadcurrcourses() {
        getcurrcourses();
    }
    public void loadothercourses() {
        getothercourses();
    }
    public void getothercourses() {
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading.");
        mProgressDialog.show();

        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);
        //Creating a RestAdapter
        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.getOtherCourses(

                //Passing the values by getting it from editTexts
               userid,


                //Creating an anonymous callback
                new retrofit.Callback<Response>() {


                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;

                        String output = "";
                        JSONObject userinfo = null;

                        JSONObject json = null;
                        Intent nxt;
                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {

                                //"userdata":{"id":"3","name":"chetan","password":"chetan123","mobile":"23455432","email":"cj@gmail.com","city":"Pune","country":"India","status":"ACTIVE","created":"2017-11-14 04:16:41"},"message":"Success"}
                                success = json.getInt("success");
                                othercourse = json.getJSONArray("usercourse");


                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                        // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}

                        if (success == 1) {
                            Log.v("json name", "username" + name);
                            SharedPreferences.Editor editor = sharedpreferences.edit();
                            editor.putString("othercourse", othercourse.toString());
                            try {

                                for(int i=0;i<othercourse.length();i++){
                                    JSONObject json_obj = othercourse.getJSONObject(i);

                                    String desc = json_obj.getString("course_description");
                                    String name = json_obj.getString("course_name");
                                    String audio = json_obj.getString("intro_audio");
                                    String inst = json_obj.getString("instructor");
                                    String fee = json_obj.getString("fee");
                                    String language = json_obj.getString("language");
                                    String max = json_obj.getString("max_modules");
                                    String image = json_obj.getString("course_image");

                                    int id = json_obj.getInt("id");
                                    listArray1.add(new Course(id,name,desc,inst,audio,"","","","",image,fee,language,max,"0"));
                                }
                                // course.setCoursename();
                            }catch(JSONException j){
                                Log.e("Course JSON", j.toString());
                            }
                            final LinearLayoutManager layoutManager1= new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false);
                            mRecyclerView1 = (RecyclerView) findViewById(R.id.recycler_view_v);
                            mRecyclerView1.setLayoutManager(layoutManager1);
                            customadapterother = new OtherCourseAdapter(listArray1, MainActivity.this);
                            mRecyclerView1.setAdapter(customadapterother);
                            customadapterother.notifyDataSetChanged();


                        } else {
                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(MainActivity.this, "Invalid Credentials", "Please enter valid email or Password");

                        }
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();

                         /*else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Invalid Credentials", "please enter valid Email_Id and Password");
                        }*/

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //If any error occured displaying the error as toast
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(MainActivity.this, "Network Error", "Problem connecting to internet. Please try again later");
                    }
                }
        );

    }
    public void showDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx, R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        builder.show();
    }
    public void setnotification() {
        ImageView ivNotification = (ImageView) findViewById(R.id.imgNotification);
        tvNotificationCount = (TextView) findViewById(R.id.tvNotificationCount);

        tvNotificationCount.setText(String.valueOf(countNotification));
        ivNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvNotificationCount.setText("0");
                Intent notificationIntent = new Intent(MainActivity.this, MerchantNotification.class);
                startActivity(notificationIntent);

            }
        });
    }
    public void getcurrcourses() {
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();
        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);
        //Creating a RestAdapter
        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.getCurrCourses(
                //Passing the values by getting it from editTexts
                userid,
                new retrofit.Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;
                        Intent nxt;
                        try {

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);
                            json = new JSONObject(tokener);
                            if (json != null) {

                                success = json.getInt("success");
                                coursejsonObj = json.getJSONArray("usercourse");
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                        // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}

                        if (success == 1) {
                            Log.v("json name", "username" + name);
                            SharedPreferences.Editor editor = sharedpreferences.edit();
                            editor.putString("usercourse", coursejsonObj.toString());
                            try {

                                for(int i=0;i<coursejsonObj.length();i++){
                                    JSONObject json_obj = coursejsonObj.getJSONObject(i);

                                    String name = json_obj.getString("course_name");
                                    String inst = json_obj.getString("instructor");
                                    String date = json_obj.getString("start_date");
                                    String max =  json_obj.getString("max_modules");
                                    String done =  json_obj.getString("comp_modules");
                                    String image =  json_obj.getString("course_image");
                                    //String fee = json_obj.getString("fee");
                                    int id = json_obj.getInt("id");
                                    listArray.add(new Course(id,name,"",inst,"","","",date,"",image,"","",max,done));
                                }
                                // course.setCoursename();
                            }catch(JSONException j){
                                Log.e("Course JSON", j.toString());
                            }
                            if (!listArray.isEmpty()){
                                TextView nocourse = (TextView) findViewById(R.id.tvnocourse);
                                nocourse.setVisibility(View.GONE);
                                final LinearLayoutManager layoutManager= new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false);
                                mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
                                mRecyclerView.setLayoutManager(layoutManager);
                                customadapter = new CurrentCourseAdapter(listArray, MainActivity.this);
                                mRecyclerView.setAdapter(customadapter);
                                customadapter.notifyDataSetChanged();}
                            else{
                                TextView nocourse = (TextView) findViewById(R.id.tvnocourse);
                                nocourse.setVisibility(View.VISIBLE);
                            }



                        } else {
                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(MainActivity.this, "Invalid Credentials", "Please enter valid email or Password");

                        }
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        loadothercourses();

                         /*else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Invalid Credentials", "please enter valid Email_Id and Password");
                        }*/

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //If any error occured displaying the error as toast
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(MainActivity.this, "Network Error", "Problem connecting to internet. Please try again later");
                    }
                }
        );

    }

    @Override
    public void onBackPressed() {
        if (mProgressDialog.isShowing())
            mProgressDialog.dismiss();
        super.onBackPressed();
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }




    protected void setHeader() {
        TextView header = (TextView) findViewById(R.id.header_text);
        header.setText("Courses");
        ImageView imgLogo = (ImageView) findViewById(R.id.imglogo);
        imgLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeintent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(homeintent);
                MainActivity.this.finish();
            }
        });
    }
}
