package com.abaow;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.SystemClock;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.abaow.Pojo.Course;
import com.abaow.Pojo.Curriculum;
import com.abaow.utils.AvenuesParams;
import com.abaow.utils.Drawer;
import com.abaow.utils.RestInterfac;
import com.abaow.utils.ServiceUtility;
import com.abaow.utils.StaticDataMember;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class CourseOverview extends AppCompatActivity implements View.OnClickListener {
    //ViewPager simpleViewPager;
    //TabLayout tabLayout;
    TextView tvcoursename, tvinstname, tvfee, tvcoursedesc, tvduration, tvinst, tvinstdesc;
    private TextView tvNotificationCount;
    Button btnPay, btnPayTM;
    ImageView ivImginst,ivCourse;
    private int courseID, userid;
    ProgressDialog mProgressDialog;
    private RecyclerView.Adapter customadapter;
    private RecyclerView mRecyclerView;
    Course mCourse;
    private ArrayList<Curriculum> listArray = new ArrayList<>();
    SharedPreferences sharedpreferences;
    public static final String MyPREFERENCES = "mypref";
    //public static final String AccessCode = "AVCZ73EI22BP12ZCPB";//AVCZ73EI22BP12ZCPB
    public static final String AccessCode = "AVLR77FE96AW03RLWA";
    public static final String Merchantid = "148765";
    public static final String Currency = "INR";
    public String OrderId = "";
   /* public static final String RedirectURL = "http://www.abaow.com/RSA/ccavResponseHandler.php";
    public static final String CancelURL = "http://www.abaow.com/RSA/ccavResponseHandler.php";
    public static final String RSAURL = "http://www.abaow.com/RSA/GetRSA.php";*/

    public static final String RedirectURL = "http://richandhappy.co.in/RSA/ccavResponseHandler.php";
    public static final String CancelURL = "http://richandhappy.co.in/RSA/ccavResponseHandler.php";
    public static final String RSAURL = "http://richandhappy.co.in/RSA/GetRSA.php";

    private int countNotification,AudioDuration;

    private DrawerLayout mDrawerLayout;
    private ImageView imgDrawer;
    private Drawer dr;
    private String name;

    private SeekBar seekbar;
    public MediaPlayer mMediaPlayer;
    private boolean isPlayingAudio = false;
    private ImageView mPlay;
    private ImageView mPause;
    private RelativeLayout rlAudio;
    private Timer updateTimer;
    public String audiofile, course_fee;
    private int stopPosition = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            stopPosition = savedInstanceState.getInt("position");
        }
        setContentView(R.layout.activity_course_overview);
        courseID = getIntent().getExtras().getInt("course");
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        countNotification = sharedpreferences.getInt("notificationCount", 0);
        userid = sharedpreferences.getInt("loggedin_user_id", 0);
        name = sharedpreferences.getString("login_name", "");
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        dr = new Drawer(this);
        dr.initializeDrawers(mDrawerLayout, name);
        imgDrawer = (ImageView) findViewById(R.id.imgDrawer);
        imgDrawer.setOnClickListener(CourseOverview.this);
        setnotification();
        setHeader();
        initializeview();
        setCourse(courseID);

        initializeMediaContents();

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.imgDrawer:

                mDrawerLayout.openDrawer(dr.mDrawerList);

                break;
        }
    }

    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateUI(intent);
        }
    };

    /**
     * Method is used to set notification count
     *
     * @param intent
     */
    private void updateUI(Intent intent) {
        String counter = intent.getStringExtra("counter");
        tvNotificationCount.setText(String.valueOf(counter));

    }

    protected void initializeview() {
        tvcoursename = (TextView) findViewById(R.id.course_name);
        tvinstname = (TextView) findViewById(R.id.inst_name);
        tvfee = (TextView) findViewById(R.id.course_fee);
        tvcoursedesc = (TextView) findViewById(R.id.course_description_text);
        tvduration = (TextView) findViewById(R.id.hrs_of_content);
        tvinst = (TextView) findViewById(R.id.instructor_name);
        tvinstdesc = (TextView) findViewById(R.id.instructor_description_text);
        btnPay = (Button) findViewById(R.id.button_pay);
        btnPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createorder(1);
            }
        });
        btnPayTM = (Button) findViewById(R.id.button_paytm);
        btnPayTM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createorder(2);
            }
        });
        ivImginst = (ImageView) findViewById(R.id.imgInst);
        ivCourse = (ImageView) findViewById(R.id.imgCourse);
        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_curr_overview);
        LinearLayoutManager layoutManager = new LinearLayoutManager(CourseOverview.this, LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(layoutManager);
    }

    protected void setCourse(int course_id) {
        /*mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);*/
        //Creating a RestAdapter
        RestAdapter adapter1 = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter1.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.getCourseDetails(
                courseID,

                //Passing the values by getting it from editTexts


                //Creating an anonymous callback
                new retrofit.Callback<Response>() {


                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;
                        JSONArray usercourse = null;
                        JSONArray curriculum = null;


                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {


                                success = json.getInt("success");
                                usercourse = json.getJSONArray("coursedetail");
                                curriculum = json.getJSONArray("curriculum");


                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                        // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}

                        if (success == 1) {
                            try {

                                /*for (int i = 0; i < curriculum.length(); i++) {
                                    JSONObject jsoner = curriculum.getJSONObject(i);
                                    String name = jsoner.getString("module_name");
                                    Log.v("curr: ", "name");
                                    String desc = jsoner.getString("module_desc");
                                    String duration = jsoner.getString("duration");
                                    String audio = jsoner.getString("module_audio");
                                    int quiz = jsoner.getInt("module_quiz");
                                    int id = jsoner.getInt("course_id");
                                    int mod_id = jsoner.getInt("id");
                                    listArray.add(new Curriculum(id, mod_id, name, audio, quiz, desc, duration, "",""));

                                }

                                if (!listArray.isEmpty()) {
                                    customadapter = new CurriculumAdapter(listArray, CourseOverview.this);
                                    mRecyclerView.setAdapter(customadapter);
                                    customadapter.notifyDataSetChanged();
                                }*/
                                JSONObject jsoncourse = usercourse.getJSONObject(0);
                                tvcoursename.setText(jsoncourse.getString("course_name"));
                                tvinstname.setText(jsoncourse.getString("instructor"));
                                tvinst.setText(jsoncourse.getString("instructor"));
                                tvcoursedesc.setText(jsoncourse.getString("course_description"));
                                tvinstdesc.setText(jsoncourse.getString("profile"));
                                tvduration.setText(jsoncourse.getString("duration") + " mins");
                                course_fee = jsoncourse.getString("fee");
                                tvfee.setText("Fee: Rs " + jsoncourse.getString("fee"));
                                String IntroAudio = jsoncourse.getString("intro_audio");
                                String image = jsoncourse.getString("image");
                                String course_image = jsoncourse.getString("course_image");
                                if (!image.isEmpty()) {
                                    Picasso.with(getApplicationContext())
                                            .load(image)
                                            .into(ivImginst);
                                }
                                if (!course_image.isEmpty())
                                {
                                    Picasso.with(getApplicationContext())
                                            .load(course_image)
                                            .into(ivCourse);
                                }
                                if (!IntroAudio.isEmpty())
                                    PlayMusic(IntroAudio);


                            } catch (Exception e) {
                                Log.e("json error: ", e.toString());
                            }

                        } else {
                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(CourseOverview.this, "Invalid Credentials", "Please enter valid email or Password");

                        }
                        /*if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();*/

                         /*else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Invalid Credentials", "please enter valid Email_Id and Password");
                        }*/

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //If any error occured displaying the error as toast
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(CourseOverview.this, "Network Error", "Problem connecting to internet. Please try again");
                    }
                }
        );
    }

    public void showDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx, R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        builder.show();

    }

    protected void registercourse(int course_id) {
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);
        //Creating a RestAdapter
        RestAdapter adapter1 = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter1.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.registercourse(
                courseID,
                userid,


                //Passing the values by getting it from editTexts


                //Creating an anonymous callback
                new retrofit.Callback<Response>() {


                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;
                        JSONArray usercourse = null;
                        JSONArray curriculum = null;


                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {


                                success = json.getInt("success");


                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                        // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}

                        if (success == 1) {
                            try {
                                if (mProgressDialog.isShowing())
                                    mProgressDialog.dismiss();
                                showDialog(CourseOverview.this, "Registration Successful", "You have been registered for the course " + tvcoursename.getText().toString());
                                Intent nxt = new Intent(getApplicationContext(), MainActivity.class);
                                //nxt.putExtra("from", "");
                                //for opening the tabs
                                startActivity(nxt);
                                CourseOverview.this.finish();




                            } catch (Exception e) {
                                Log.e("json error: ", e.toString());
                            }

                        } else {
                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(CourseOverview.this, "Invalid Credentials", "Please enter valid email or Password");

                        }
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();

                         /*else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Invalid Credentials", "please enter valid Email_Id and Password");
                        }*/

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //If any error occured displaying the error as toast
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(CourseOverview.this, "Network Error", "Problem connecting to internet. Please try again");
                    }
                }
        );
    }

    public void setnotification() {
        ImageView ivNotification = (ImageView) findViewById(R.id.imgNotification);
        tvNotificationCount = (TextView) findViewById(R.id.tvNotificationCount);

        tvNotificationCount.setText(String.valueOf(countNotification));
        ivNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvNotificationCount.setText("0");
                Intent notificationIntent = new Intent(CourseOverview.this, MerchantNotification.class);
                startActivity(notificationIntent);
                //CourseOverview.this.finish();
            }
        });
    }

    public void initializeMediaContents() {
        rlAudio = (RelativeLayout) findViewById(R.id.rlAudio);


        seekbar = (SeekBar) findViewById(R.id.seekBar);
        seekbar.setMax(100);
        seekbar.getProgressDrawable().setColorFilter(Color.LTGRAY, PorterDuff.Mode.SRC_IN);
        seekbar.getThumb().setColorFilter(Color.RED, PorterDuff.Mode.SRC_IN);



        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if(!mMediaPlayer.isPlaying() || AudioDuration == 0){
                    seekbar.setProgress(0);

                }else{

                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {

                if (fromUser) {
                    if (mMediaPlayer.isPlaying()){
                        int secondaryPosition = seekbar.getSecondaryProgress();
                        if (progress < secondaryPosition) {
                            seekbar.setProgress(progress);
                            mMediaPlayer.seekTo(getProgressSeek(seekBar.getProgress()));
                        }
                    }
                }
            }
        });

        //mMediaPlayer = new MediaPlayer();
        //mMediaPlayer.start();
        rlAudio.setVisibility(View.VISIBLE);
        mPlay = (ImageView) findViewById(R.id.play);
        mPause = (ImageView) findViewById(R.id.pause);

        mPlay.setImageResource(R.drawable.pause);
        mPlay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (!isPlayingAudio) {
                    mPlay.setImageResource(R.drawable.play);
                    if (mMediaPlayer != null) {
                        mMediaPlayer.pause();
                        rlAudio.setKeepScreenOn(false);
                        isPlayingAudio = true;
                    }

                } else {
                    mPlay.setImageResource(R.drawable.pause);
                    //int mCurrentPosition = mMediaPlayer.getCurrentPosition();
                    //seekbar.setProgress(mCurrentPosition);
                    if (mMediaPlayer != null) {
                        seekbar.postDelayed(onEverySecond, 1000000000);
                        rlAudio.setKeepScreenOn(true);
                        mMediaPlayer.start();
                        isPlayingAudio = false;
                    }
                }
            }
        });

    }



    public void PlayMusic(String source) {
        mMediaPlayer = new MediaPlayer();
        rlAudio.setKeepScreenOn(true);
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Playing Audio");
        mProgressDialog.show();
        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);

        //mMediaPlayer.start();
        mPlay.setImageResource(R.drawable.pause);
        audiofile = source;

        mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        try {
            mMediaPlayer.setDataSource(source);
        } catch (IllegalArgumentException e) {
            Toast.makeText(getApplicationContext(), "You might not set the URI1 correctly!", Toast.LENGTH_LONG).show();
        } catch (SecurityException e) {
            Toast.makeText(getApplicationContext(), "You might not set the URI2 correctly!", Toast.LENGTH_LONG).show();
        } catch (IllegalStateException e) {
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            mMediaPlayer.prepareAsync();
        } catch (IllegalStateException e) {
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }


        mMediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                if (mProgressDialog.isShowing())
                    mProgressDialog.dismiss();

                mMediaPlayer.start();

                AudioDuration = mMediaPlayer.getDuration();

                updateMediaProgress();
            }
        });
        mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer mp) {
                rlAudio.setKeepScreenOn(false);

                //mMediaPlayer.setOnPreparedListener(null);
                //MediaPlayer.prepareAsync();
                //mMediaPlayer.stop();
                mMediaPlayer.stop();
                mMediaPlayer.reset();
                mMediaPlayer = null;
                if (updateTimer != null)
                    updateTimer.cancel();
                seekbar.setProgress(0);
                mPlay.setImageResource(R.drawable.play);
                /*curriculum.updatestatus(curriculum.getModuleid(),userID,curriculum.getCourseid());
                finish();
                startActivity(getIntent());*/

                //isPlayingAudio = true;
            }

        });
        mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener(){
            public boolean onError(MediaPlayer mp,int a,int b) {
                mMediaPlayer.reset();
                return true;

            }
        });
        mMediaPlayer.setOnBufferingUpdateListener(new MediaPlayer.OnBufferingUpdateListener() {
            public void onBufferingUpdate(MediaPlayer mp, int percent) {
                /** Method which updates the SeekBar secondary progress by current song loading from URL position*/
                seekbar.setSecondaryProgress(percent);
            }
        });
        mMediaPlayer.setOnSeekCompleteListener(new MediaPlayer.OnSeekCompleteListener() {
            @Override
            public void onSeekComplete(MediaPlayer arg0) {
                Log.v("Seek ", "onSeekComplete() current pos : " + arg0.getCurrentPosition());
                SystemClock.sleep(200);
                mMediaPlayer.start();
            }
        });

    }

    private void updateMediaProgress() {
        updateTimer = new Timer("progress Updater");
        updateTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (mMediaPlayer != null) {
                            int position = mMediaPlayer.getCurrentPosition();
                            //seekbar.setProgress(position / 1000);
                            if (AudioDuration > 0) {
                                seekbar.setProgress((position * 100) / AudioDuration);
                            }
                        }
                    }
                });
            }
        }, 0, 1000);
    }


    private Runnable onEverySecond = new Runnable() {

        @Override
        public void run() {

            if (seekbar != null) {
                seekbar.setProgress(mMediaPlayer.getCurrentPosition());
            }

            if (mMediaPlayer.isPlaying()) {
                seekbar.postDelayed(onEverySecond, 1000000000);
            } else {
                seekbar.setProgress(0);
            }


        }
    };

    private int getProgressSeek(int mProgress) {
        int progress = 0;
        progress = ((mProgress * AudioDuration) / 100);
        return progress;
    }

    @Override
    public void onBackPressed() {
        if (mProgressDialog.isShowing())
            mProgressDialog.dismiss();
        Intent homeintent = new Intent(CourseOverview.this, MainActivity.class);
        startActivity(homeintent);
        CourseOverview.this.finish();
    }

    protected void setHeader() {
        TextView header = (TextView) findViewById(R.id.header_text);
        header.setText("Course Overview");
        ImageView imgLogo = (ImageView) findViewById(R.id.imglogo);
        imgLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeintent = new Intent(CourseOverview.this, MainActivity.class);
                startActivity(homeintent);
                CourseOverview.this.finish();
            }
        });
    }

    protected void createorder(int mode) {
        final int paymode = mode;
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);
        //Creating a RestAdapter
        RestAdapter adapter1 = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter1.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.createorder(
                userid,
                courseID,
                course_fee,
                //Passing the values by getting it from editTexts


                //Creating an anonymous callback
                new retrofit.Callback<Response>() {


                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;
                        String order_id = "";


                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {
                                success = json.getInt("success");
                                if (success == 1) {
                                    OrderId = json.getString("orderid");
                                } else {
                                    OrderId = "";
                                }
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        if (success == 1) {
                            switch (paymode){
                                case 1:
                                    String vAccessCode = AccessCode;
                                    String vMerchantId = Merchantid;
                                    String vCurrency = Currency;
                                    String vAmount = ServiceUtility.chkNull(tvfee.getText()).toString().trim();
                                    if (!vAccessCode.equals("") && !vMerchantId.equals("") && !vCurrency.equals("") && !vAmount.equals("")) {
                                        Intent intent = new Intent(CourseOverview.this, WebViewActivity.class);
                                        intent.putExtra(AvenuesParams.ACCESS_CODE, vAccessCode);
                                        intent.putExtra(AvenuesParams.MERCHANT_ID, vMerchantId);
                                        intent.putExtra(AvenuesParams.ORDER_ID, OrderId);
                                        intent.putExtra(AvenuesParams.CURRENCY, vCurrency);
                                        intent.putExtra(AvenuesParams.AMOUNT, course_fee);
                                        intent.putExtra(AvenuesParams.REDIRECT_URL, RedirectURL);
                                        intent.putExtra(AvenuesParams.CANCEL_URL, CancelURL);
                                        intent.putExtra(AvenuesParams.RSA_KEY_URL, RSAURL);
                                        intent.putExtra("userid", userid);
                                        intent.putExtra("courseid", courseID);
                                        intent.putExtra("coursename", tvcoursename.getText().toString());
                                        startActivity(intent);
                                        //CourseOverview.this.finish();
                                    }else {
                                        Log.e("Error: ", "All parameters are mandatory.");
                                    }
                                    break;
                                case 2:
                                    Intent intent = new Intent(CourseOverview.this, PaytmActivity.class);
                                    intent.putExtra(AvenuesParams.ORDER_ID, OrderId);
                                    intent.putExtra(AvenuesParams.AMOUNT, course_fee);
                                    intent.putExtra("userid", userid);
                                    intent.putExtra("courseid", courseID);
                                    intent.putExtra("coursename", tvcoursename.getText().toString());
                                    startActivity(intent);

                                    break;
                                default:
                                    break;

                            }

                        }



                         else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(CourseOverview.this, "Network Error","Unable to complete this transaction. Please try again later");
                        }

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //If any error occured displaying the error as toast
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(CourseOverview.this, "Network Error", "Problem connecting to internet. Please try again later");
                    }
                }
        );


    }
    @Override
    public void onResume() {
        super.onResume();

        if (mMediaPlayer != null) {
            mMediaPlayer.seekTo(stopPosition);
            if (!isPlayingAudio) {
                mMediaPlayer.start();
                mPlay.setImageResource(R.drawable.pause);
                updateMediaProgress();

            }
        }
    }
    @Override
    public void onDestroy() {
        if (mMediaPlayer != null) {
            mMediaPlayer.release();
            mMediaPlayer = null;
        }
        if (mProgressDialog.isShowing())
            mProgressDialog.dismiss();
        super.onDestroy();
    }
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mMediaPlayer != null) {
            stopPosition = mMediaPlayer.getCurrentPosition();
            mMediaPlayer.pause();
            outState.putInt("position", stopPosition);
        }
    }
    @Override
    protected void onStop() {
           /* if (mMediaPlayer != null) {
                mMediaPlayer.pause();
            }*/
        if (mProgressDialog.isShowing())
            mProgressDialog.dismiss();
        super.onStop();
    }
    @Override
    public void onPause() {
        super.onPause();

        if (mMediaPlayer != null) {
          //  mMediaPlayer.pause();
        }
    }



}
