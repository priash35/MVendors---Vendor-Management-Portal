package com.abaow.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import android.support.v4.widget.DrawerLayout;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.abaow.AboutUs;
import com.abaow.ActivitySendFeedback;
import com.abaow.Adapters.DrawerItemCustomAdapter;
import com.abaow.CompletedCourses;
import com.abaow.ContactUs;
import com.abaow.GetBlogs;
import com.abaow.LocalDB.MerchantNotificationService;
import com.abaow.LoginActivity;
import com.abaow.MainActivity;
import com.abaow.MyProfile;
import com.abaow.PrivacyPolicy;
import com.abaow.R;

import org.apache.commons.lang3.StringUtils;


/**
 * Created by chetan on 22/11/17.
 */
public class Drawer {
    private static final String TAG = Drawer.class.getSimpleName();
    private Context mContext;
    int layout;
    private DrawerLayout mDrawerLayout;
    public ListView mDrawerList;
    SharedPreferences sharedpreferences;

    public Drawer(Context context) {

        mContext = context;
        sharedpreferences = mContext.getSharedPreferences("mypref", Context.MODE_PRIVATE);

    }

    public void initializeDrawers(DrawerLayout DL,String name) {


        mDrawerLayout = (DrawerLayout) DL.findViewById(R.id.drawer_layout);


        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);


        mDrawerList = (ListView) DL.findViewById(R.id.color_list_right_drawer);

        ObjectDrawerItem[] rdrawerItem = new ObjectDrawerItem[10];
        rdrawerItem[0] = new ObjectDrawerItem(R.drawable.ic_user_nav, StringUtils.capitalize(name));
        rdrawerItem[1] = new ObjectDrawerItem(R.drawable.profile, "My Profile");
        rdrawerItem[2] = new ObjectDrawerItem(R.drawable.list, "Completed Courses");
        rdrawerItem[3] = new ObjectDrawerItem(R.drawable.conversation, "Talk To Expert");
        rdrawerItem[4] = new ObjectDrawerItem(R.drawable.blog_1, "Blogs");
        rdrawerItem[5] = new ObjectDrawerItem(R.drawable.playbutton, "How To Use");
        rdrawerItem[6] = new ObjectDrawerItem(R.drawable.network, "About Us");
        rdrawerItem[7] = new ObjectDrawerItem(R.drawable.padlock, "Privacy And Refund");
        rdrawerItem[8] = new ObjectDrawerItem(R.drawable.phonecall, "Contact Us");
        rdrawerItem[9] = new ObjectDrawerItem(R.drawable.logout, "Logout");
/*
     rdrawerItem[1] = new ObjectDrawerItem(R.drawable.iidentity_black, "My Profile");
        rdrawerItem[2] = new ObjectDrawerItem(R.drawable.ic_list_black_18dp, "Completed Courses");
        rdrawerItem[3] = new ObjectDrawerItem(R.drawable.ic_chat_black_18dp, "Talk To Expert");
        rdrawerItem[4] = new ObjectDrawerItem(R.drawable.blog, "Blogs");
        rdrawerItem[5] = new ObjectDrawerItem(R.drawable.play_23, "How To Use");
        rdrawerItem[6] = new ObjectDrawerItem(R.drawable.ic_power_settings_new_black_18dp, "Logout");
*/
       /* //  rdrawerItem[4] = new ObjectDrawerItem(R.drawable.group,"Create Group");
        //  rdrawerItem[5] = new ObjectDrawerItem(R.drawable.gear_128,"Settings");
        // rdrawerItem[3] = new ObjectDrawerItem(R.mipmap.ic_advertisement_nav, "All Advertisements");
        rdrawerItem[3] = new ObjectDrawerItem(R.drawable.ic_nav_bankinfo, "Update Bank Info");
        rdrawerItem[4] = new ObjectDrawerItem(R.drawable.ic_nav_myintrest, "My Interests");
        rdrawerItem[5] = new ObjectDrawerItem(R.drawable.ic_nav_browse_adv, "Browse All Merchants");
        rdrawerItem[6] = new ObjectDrawerItem(R.drawable.ic_nav_share, "Share With Friends");
        rdrawerItem[7] = new ObjectDrawerItem(R.drawable.ic_nav_help, "Help And Support");
        rdrawerItem[8] = new ObjectDrawerItem(R.mipmap.ic_logout_nav, "Logout");*/

        DrawerItemCustomAdapter radapter = new DrawerItemCustomAdapter(mContext, R.layout.listview_item_row, rdrawerItem);
        mDrawerList.setAdapter(radapter);
        mDrawerList.setOnItemClickListener(new lDrawerItemClickListener());
    }

    private class lDrawerItemClickListener implements AdapterView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position,
                                long id) {

            lDrawerSelectItem(position);
        }

    }

    private void lDrawerSelectItem(int position) {

        // update the main content by replacing fragments

        switch (position) {
            case 0:
                mDrawerLayout.closeDrawers();

                Intent intentHome = new Intent(mContext,MainActivity.class);
                mContext.startActivity(intentHome);

                break;
            case 1:
                // Toast.makeText(getApplicationContext(), "Update clicked", Toast.LENGTH_SHORT).show();
                mDrawerLayout.closeDrawers();
                Intent intentUpdate = new Intent(mContext,MyProfile.class);

                mContext.startActivity(intentUpdate);
                ((Activity)mContext).finish();

                break;
            case 2:
                mDrawerLayout.closeDrawers();
                Intent intentcompcourse = new Intent(mContext, CompletedCourses.class);
                mContext.startActivity(intentcompcourse);
                ((Activity)mContext).finish();
                break;
            case 3:
                mDrawerLayout.closeDrawers();
                Intent intentfeedback = new Intent(mContext, ActivitySendFeedback.class);
                mContext.startActivity(intentfeedback);
                ((Activity)mContext).finish();
                break;
            case 4:

                Intent blogs=new Intent(mContext,GetBlogs.class);
                mContext.startActivity(blogs);
                break;
            case 5:
                Intent i=new Intent(mContext,PLayVideos.class);
                mContext.startActivity(i);
                break;
            case 6:
                Intent aboutus=new Intent(mContext,AboutUs.class);
                mContext.startActivity(aboutus);
                break;
            case 7:
                Intent privacypolicy=new Intent(mContext,PrivacyPolicy.class);
                mContext.startActivity(privacypolicy);
                break;
            case 8:
                Intent contactus=new Intent(mContext,ContactUs.class);
                mContext.startActivity(contactus);

         /*       //https://youtu.be/kFgSxivTWQQ
                Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + "kFgSxivTWQQ"));
                Intent webIntent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://youtu.be/kFgSxivTWQQ"));
                try {
                    mContext.startActivity(appIntent);
                } catch (ActivityNotFoundException ex) {
                    mContext.startActivity(webpolicyIntent);
                }*/
                break;
            case 9:
                mDrawerLayout.closeDrawers();
                SharedPreferences.Editor editor = sharedpreferences .edit();
                editor.putString("username", null);
                editor.putString("logout", "LOGOUT");
                editor.putString("password", null);
                editor.putInt("loggedin_user_id",0);
                editor.apply();
                mContext.stopService(new Intent(mContext, MerchantNotificationService.class));
                mDrawerLayout.closeDrawers();
                Intent intentLogout = new Intent(mContext, LoginActivity.class);
                intentLogout.setFlags(intentLogout.FLAG_ACTIVITY_NEW_TASK | intentLogout.FLAG_ACTIVITY_CLEAR_TASK);
                mContext.startActivity(intentLogout);
                ((Activity)mContext).finish();
                break;




            default:
                break;

        }

    }
}
