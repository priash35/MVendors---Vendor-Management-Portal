package com.abaow;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.abaow.Pojo.Country;
import com.abaow.utils.Drawer;
import com.abaow.utils.RestInterfac;
import com.abaow.utils.StaticDataMember;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

public class MyProfile extends AppCompatActivity implements View.OnClickListener{


    private EditText etFname, etMobile, etEmail, password;

    private Button btnSubmit;
    private ProgressDialog mProgressDialog;
    SharedPreferences sharedpreferences;

    private Typeface notoFace, notoFaceBold;

    private String lastName = "";
    private String firstName = "";


    private EditText edAlertInput, edOtpNo;
    private final static String TAG = Registration.class.getSimpleName();


    private static final String TAG_SUCCESS = "success";
    private static final String TAG_USER_REGISTER = "registered";
    private static final String TAG_REGISTRATION_CONFIRM = "registration_confirm";
    private String mMobileNo;
    private Boolean isProfileLoaded = false;

    private DrawerLayout mDrawerLayout;
    private ImageView imgDrawer;
    private Drawer dr;
    private String name;
    private int user_id;

    private SearchableSpinner mCitySpinner, mCountrySpinner;
    private Spinner mLanguageSpinner;
    private List<String> mListLanguage,mListLanguageId;

    private List<String> mListCountry;
    private List<String> mListCountryId;
    private List<Country> mCountry;
    private List<String> mListCity;
    private List<String> mListCityId;
    private String mCityId;
    private String mCountryId,mLanguageId;
    private ArrayAdapter mCountryAdapter;
    private ArrayAdapter<String> mCityAdapter,mLanguageAdapter;
    private String mCityName, mCountryName;
    private TextView tvHintCity, tvHintArea,tvHintLanguage;
    private LinearLayout lleditprofile;
    private int countNotification;
    private TextView tvNotificationCount;




    private boolean isEmailValid(String email) {
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z0-9]+\\.+[a-z]+";
        if (!email.toString().trim().matches(emailPattern))
            return false;
        else
            return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_my_profile);
        setnotification();
        setHeader();
        sharedpreferences = getSharedPreferences("mypref", Context.MODE_PRIVATE);

        SharedPreferences prefs = this.getSharedPreferences("mypref", this.MODE_PRIVATE);
        //userLoginId = prefs.getString(TAG_LOGIN_ID, null);
        boolean isUserRegistered = prefs.getBoolean(TAG_USER_REGISTER, false);
        boolean isRegisConfirm = prefs.getBoolean(TAG_REGISTRATION_CONFIRM, false);
        mMobileNo = prefs.getString("Mobile", null);
        name= prefs.getString("login_name", "");
        user_id = prefs.getInt("loggedin_user_id", 0);

       /* ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, mListLanguage);*/

        notoFace = Typeface.createFromAsset(getResources().getAssets(), "NotoSans-Regular.ttf");
        notoFaceBold = Typeface.createFromAsset(getResources().getAssets(), "NotoSans-Bold.ttf");

        etFname = (EditText) findViewById(R.id.etFname);
        etEmail = (EditText) findViewById(R.id.etEmail);
        etMobile = (EditText) findViewById(R.id.etMobile);
        password = (EditText) findViewById(R.id.etPwd);
        //etCity = (EditText) findViewById(R.id.etCity);
        //etCountry = (EditText) findViewById(R.id.etCountry);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(this);
        /*btnUpdate.setOnClickListener(this);
        btnUpdate.setVisibility(View.GONE);*/
        btnSubmit.setVisibility(View.VISIBLE);


        etMobile.setFocusable(true);
        password.setFocusable(true);

        etFname.setTypeface(notoFace);
        etEmail.setTypeface(notoFace);
        etMobile.setTypeface(notoFace);
       // etCity.setTypeface(notoFace);
        //etCountry.setTypeface(notoFace);
        lleditprofile = (LinearLayout) findViewById(R.id.editprofile);
        mCountrySpinner = (SearchableSpinner) findViewById(R.id.spinnerCountry);
        mCountrySpinner.getBackground().setColorFilter(getResources().getColor(R.color.new_dark_grey), PorterDuff.Mode.SRC_ATOP);


        mCitySpinner = (SearchableSpinner) findViewById(R.id.spinnerCity);
        mCitySpinner.setVisibility(View.GONE);
        mCitySpinner.getBackground().setColorFilter(getResources().getColor(R.color.new_dark_grey), PorterDuff.Mode.SRC_ATOP);
        tvHintArea = (TextView) findViewById(R.id.tvHintSpCountry);
        tvHintCity = (TextView) findViewById(R.id.tvHintSpCity);
        tvHintLanguage = (TextView) findViewById(R.id.tvHintLanguage);
        tvHintCity.setTypeface(notoFace);
        tvHintArea.setTypeface(notoFace);
        tvHintLanguage.setTypeface(notoFace);
        mListCountry = new ArrayList<String>();
        mListCountryId = new ArrayList<String>();
        mListLanguage = new ArrayList<String>();
        mListLanguageId = new ArrayList<String>();

        mLanguageSpinner = (Spinner)findViewById(R.id.spnLanguage);
        mLanguageSpinner.getBackground().setColorFilter(getResources().getColor(R.color.new_dark_grey), PorterDuff.Mode.SRC_ATOP);

        password.setTypeface(notoFace);
        btnSubmit.setTypeface(notoFaceBold);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        dr = new Drawer(this);
        dr.initializeDrawers(mDrawerLayout,name);
        imgDrawer = (ImageView) findViewById(R.id.imgDrawer);
        imgDrawer.setOnClickListener(this);
        /*try {
            ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                    connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
                getAllLanguages();

            } else //No Internet connection
            {
                showDialog(MyProfile.this, "Please check Internet Connection", "");
            }

        } catch (Exception e) {
            Log.e(MyProfile.class.getSimpleName(), "connectivity manager " + e.getMessage());
        }*/
        GetCurrentCustomerDetails();

    }



    @Override
    public void onResume(){
        super.onResume();

    }

    @Override
    public void onStop() {
        super.onStop();

    }

    @Override
    protected void onDestroy() {

        super.onDestroy();
    }

    private void GetCurrentCustomerDetails() {
        /*mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();*/
        lleditprofile.setVisibility(View.VISIBLE);
        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.getUserInfo(

                //Passing the values by getting it from editTexts
                user_id,


                //Creating an anonymous callback
                new Callback<Response>() {

                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String mCity="",mCountry="";

                        //An string to store output from the server
                        String output = "";
                        JSONArray jsonObj;
                        JSONObject json = null;
                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            //{"customer_details":[{"id":"21","firstname":"vnts","lastname":"vnts","mobile":"7588676808","email":"vnts@gmail.com","dob":"1966-05-24","City":"hgff","city":"pune","pincode":"411029","gender":"Male","image":"http:\/\/referplus.ele45.com\/referplus\/app\/webroot\/img\/uploads\/users\/vnts_16-05-24_10-45-05.png"}],"success":1,"message":"Customer details"}
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            jsonObj = json.getJSONArray("userinfo");
                            if (json != null) {
                                for (int i = 0; i < jsonObj.length(); i++) {
                                    JSONObject obj = jsonObj.getJSONObject(i);
                                    System.out.println("JSON Object: " + json);
                                    etFname.setText(obj.getString("name"));
                                    //etLname.setText(obj.getString("lastname"));
                                    etEmail.setText(obj.getString("email"));
                                    mCity = obj.getString("city");
                                    mCountry = obj.getString("country");
                                    mLanguageId = obj.getString("language");
                                    //mLanguageSpinner.setSelection(mListLanguageId.indexOf(mLanguageId));

                                    etMobile.setText(obj.getString("mobile"));
                                    password.setText(obj.getString("password"));



                                }

                            }
                            // Toast.makeText(this, json.getString("meassage"),Toast.LENGTH_LONG).show();
                            //  showDialog(this,"success", json.getString("meassage"));
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        mCityId = mCity;

                        mCountryId = mCountry;
                        /*if (!mListCountry.isEmpty() && !TextUtils.isEmpty(mCountry)) {
                            int index = mListCountryId.indexOf(mCountryId);
                            mCountryName = String.valueOf(MyProfile.this.mCountry.get(index).getCountryName());
                            mCountrySpinner.setSelection(index);
                        }else {
                            mCountryId = "1";
                            int index = mListCountryId.indexOf(mCountryId);
                            mCountryName = String.valueOf(MyProfile.this.mCountry.get(index).getCountryName());
                            mCountrySpinner.setSelection(index);
                        }*/
                        /*try{
                            if (!mListCityId.isEmpty() && !TextUtils.isEmpty(mCityId)) {
                                int index = mListCityId.indexOf(mCityId);
                                mCityName = mListCity.get(index);
                                mCitySpinner.setSelection(index);
                            }
                        }catch(Exception e){}*/
                        isProfileLoaded = true;
                        getAllLanguages();
                        getAllCountry();
                        //mCitySpinner.setVisibility(View.VISIBLE);
                        /*if (!mListLanguageId.isEmpty() && !TextUtils.isEmpty(mLanguageId)) {
                                int index = mListLanguageId.indexOf(mLanguageId);
                                //mLa = mListCity.get(index);
                                mLanguageSpinner.setSelection(index);
                            }*/

                       /* if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();*/

                    }


                    @Override
                    public void failure(RetrofitError error) {
                        /*if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();*/
                        //If any error occured displaying the error as toast
                        //Toast.makeText(this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(MyProfile.this, "Please check Internet Connection", "");
                    }
                }
        );
    }


    public void showDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx, R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        builder.show();
    }


    private void showSuccessDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx, R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                Intent nxt = new Intent(MyProfile.this, MainActivity.class);
                startActivity(nxt);
                MyProfile.this.finish();
            }
        });

        builder.show();
    }
    public String getStringImage(Bitmap bmp) {
        if (bmp == null)
            return "";
        else {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();

            bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] imageBytes = baos.toByteArray();
            String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
            return encodedImage;
        }
    }



    private void updateuser() {
        //Here we will handle the http request to insert user to mysql db
        //Creating a RestAdapter
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();
        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);


        //Creating object for our interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.updateuser(

                //Passing the values by getting it from editTexts
                user_id,
                firstName + " "+lastName,
                password.getText().toString(),
                etMobile.getText().toString(),
                etEmail.getText().toString(),
                mCountryId,
                mCityId,
                mLanguageId,



                //Creating an anonymous callback
                new Callback<Response>() {

                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String mloginId = "";
                        String mloginName = "";
                        String mMessage = "";
                        //An string to store output from the server
                        String output = "";
                        JSONObject json = null;
                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            Log.v("Save Profile: ", output);
                            //{"id":"44","username":"haha","success":1,"message":"User registered successfully"}
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {
                                System.out.println("JSON EE Object: " + json);
                                success = json.getInt("success");
                                /*mloginId = json.getString("id");
                                mloginName = json.getString("username");
                                mMessage = json.getString("message");*/
                            }
                            // Toast.makeText(this, json.getString("meassage"),Toast.LENGTH_LONG).show();
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();

                        if (success == 1) {
                            //cleanView();
                            //showDialog(MyProfile.this, "Success", "Profile Saved.");

                            showSuccessDialog(MyProfile.this, "Success", "Profile Saved.");

                        } else {
                            //   Toast.makeText(this, "Sorry,User Not Registered successfully",Toast.LENGTH_LONG).show();
                            showDialog(MyProfile.this, "Failed", "Failed to save profile");
                        }

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //If any error occured displaying the error as toast
                        //Toast.makeText(this, error.toString(),Toast.LENGTH_LONG).show();
                        if (isFinishing()) {
                            showDialog(MyProfile.this, "Please check Internet Connection", "");
                        }
                    }
                }
        );
    }



    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnSubmit:

                //    String lname = etLname.getText().toString();

                String nameTokens[] = etFname.getText().toString().trim().split("\\s");

                if (nameTokens.length > 1) {
                    firstName = nameTokens[0].trim().toString();
                    lastName = nameTokens[1].trim().toString();
                } else {
                    //         name = nameTokens.toString();
                    firstName = etFname.getText().toString().trim();
                    lastName = "";

                }

                String Email = etEmail.getText().toString();
                String Mobile = etMobile.getText().toString();
                mMobileNo=Mobile;

                String pwd = password.getText().toString();


                if (firstName.equals("")) {
                    showDialog(this, "Empty First Name", "please enter First Name");
                } else if (Email.equals("")) {
                    // Toast.makeText(this, "please enter Email", Toast.LENGTH_SHORT).show();
                    showDialog(this, "Empty Email", "pleas                         e enter Email");
                } else if (Mobile.equals("")) {
                    // Toast.makeText(this, "please enter Mobile", Toast.LENGTH_SHORT).show();
                    showDialog(this, "Empty Mobile", "please enter Mobile");
                }/* else if (city.equals("")) {
                    // Toast.makeText(this, "please enter City", Toast.LENGTH_SHORT).show();
                    showDialog(this, "Empty City", "please enter City");
                }*/ else if (!isEmailValid(Email)) {
                    //  Toast.makeText(this, "please enter valid email", Toast.LENGTH_SHORT).show();
                    showDialog(this, "Invalid Email", "please enter valid email");
                } else if (Mobile.length() < 10 || Mobile.length() > 10) {
                    //  Toast.makeText(this, "Mobile number must have 10 digits", Toast.LENGTH_SHORT).show();
                    showDialog(this, "Invalid Mobile", "Mobile number must have 10 digits");
                } else if (TextUtils.isEmpty(pwd)) {
                    showDialog(this, "Empty Password", "please enter password");
                } else if (pwd.length() < 8) {
                    showDialog(this, "Short Password", "Password characters must be 8+");
                } else {
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("Mobile", Mobile);
                    editor.putString("username", null);
                    editor.putString("password", null);

                    editor.apply();
                    updateuser();

                }
                break;
            case R.id.imgDrawer:

                mDrawerLayout.openDrawer(dr.mDrawerList);

                break;

            default:
                break;

           /* case R.id.imgDrawer:
                mDrawerLayout.openDrawer(mDrawerList);
                break;*/
        }

    }


    private void cleanView() {
        etFname.setText("");
        etMobile.setText("");
        etEmail.setText("");
        password.setText("");

    }
    private void getAllCountry() {
        //While the app fetched data we are displaying a progress dialog
        //Creating a rest adapter


        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url)
                .build();
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating an object of our api interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method
        api.getCountry(
                //Passing the values by getting it from editTexts
                user_id,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        //Dismissing the loading progressbar

                        //Calling a method to show the list
                        BufferedReader reader = null;

                        //An string to store output from the server
                        String output = "";
                        JSONObject json = null;
                        int success = 0;
                        try {
                            //Initializing buffered reader
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));

                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);
                            try {
                                json = new JSONObject(tokener);
                                if (json != null) {
                                    mCountry = new ArrayList<Country>();
                                    //mListCity.add(0, "City");
                                    System.out.println("JSON Object: " + json);
                                    success = json.getInt("success");
                                    JSONArray productObj = json.getJSONArray("country"); // JSON Array
                                    if (productObj != null) {
                                        for (int i = 0; i < productObj.length(); i++) {
                                            JSONObject category1 = productObj.getJSONObject(i);//0th element
                                            Country obj1 = new Country();
                                            String cityId = category1.getString("id");
                                            if (cityId != null) {
                                                obj1.setCountryId(Integer.parseInt(cityId));
                                            }
                                            obj1.setCountryName(category1.getString("country_name"));
                                            obj1.setmSlug(category1.getString("country_name"));
                                            mCountry.add(i, obj1);
                                            // mListCity.add(mListCity.size(), category1.getString("name"));
                                        }
                                    }
                                    //

                                } else {
                                    Log.e(TAG, "JSONobject is null");
                                }

                            } catch (JSONException e) {
                                Log.e(TAG, "JSONExeption: " + e.getMessage());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        //if (MyApplication.isActivityVisible()) {
                            if (success == 1) {
                                for (Country city : mCountry) {
                                    mListCountry.add(mListCountry.size(), city.getCountryName());
                                    mListCountryId.add(mListCountryId.size(), String.valueOf(city.getCountryId()));
                                }
                                mCountryAdapter = new ArrayAdapter(MyProfile.this, R.layout.new_spinner_item, mListCountry);
                                mCountrySpinner.setAdapter(mCountryAdapter);
                                try{
                                    if (!mListCountryId.isEmpty() && !TextUtils.isEmpty(mCountryId)) {
                                        int index = mListCountryId.indexOf(mCountryId);
                                        mCountryName = mListCountry.get(index);
                                        mCountrySpinner.setSelection(index);
                                    }
                                }catch(Exception e){}
                                //mCountrySpinner.setTitle("Select Country");
                                mCountrySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                    @Override
                                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                        mCountryId = String.valueOf(mCountry.get(mCountrySpinner.getSelectedItemPosition()).getCountryId());
                                        mCountryName = mCountry.get(mCountrySpinner.getSelectedItemPosition()).getCountryName();
                                        try {
                                            ConnectivityManager connectivityManager = (ConnectivityManager) MyProfile.this.getSystemService(Context.CONNECTIVITY_SERVICE);
                                            if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                                    connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
                                                //mProgressDialog.show();
                                                getAllCity(mCountryId);

                                            } else //No Internet connection
                                            {
                                                //noDataConnectionAlert();
                                                showDialog(MyProfile.this, "Network Error", "Problem connecting to internet. Please try again later");
                                                //Toast.makeText(MyProfile.this, "No internet connection", Toast.LENGTH_SHORT).show();
                                            }

                                        } catch (Exception e) {
                                            Log.e(TAG, "connectivity manager " + e.getMessage());
                                        }

                                    }

                                    @Override
                                    public void onNothingSelected(AdapterView<?> adapterView) {

                                    }
                                });

                                //GetCurrentCustomerDetails();
                                //getAllLanguages();
                               /* if (mProgressDialog.isShowing()){
                                    mProgressDialog.dismiss();
                                }*/
                            }

                        }

                    //}

                    @Override
                    public void failure(RetrofitError error) {
                        //you can handle the errors here
                        //if (MyApplication.isActivityVisible()) {
                        /*if (mProgressDialog.isShowing()){
                            mProgressDialog.dismiss();
                        }*/
                            showDialog(MyProfile.this, "Network Error", "Problem connecting to internet. Please try again later");
                            //Toast.makeText(MyProfile.this, "Problem connecting to internet. Please try again", Toast.LENGTH_SHORT).show();
                            Log.e(TAG, error.toString());
                        //}
                        //Toast.makeText(DiscountMasterActivity.this, "Problem connecting to internet. Please try again", Toast.LENGTH_LONG).show();
                    }
                });
    }
    /**
     * Method to get Citys of selected city
     *
     * @param ids
     */
    private void getAllCity(String ids) {
        //While the app fetched data we are displaying a progress dialog
        //Creating a rest adapter
        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url)
                .build();
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating an object of our api interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method
        api.getCity(
                //Passing the values by getting it from editTexts
                ids,

                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        //Dismissing the loading progressbar

                        //Calling a method to show the list
                        BufferedReader reader = null;

                        //An string to store output from the server
                        String output = "";
                        JSONObject json = null;
                        int success = 0;
                        try {
                            //Initializing buffered reader
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));

                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);
                            try {
                                mListCity = new ArrayList<String>();
                                mListCityId = new ArrayList<String>();
                                json = new JSONObject(tokener);
                                if (json != null) {
                                    System.out.println("JSON Object City: " + json);
                                    success = json.getInt("success");
                                    JSONArray productObj = json.getJSONArray("city"); // JSON Array
                                    if (productObj != null) {
                                        for (int i = 0; i < productObj.length(); i++) {
                                            //JSONObject CityData = productObj.getJSONObject(0);//0th element
                                            //System.out.println("JSON CityData: " + json);
                                            //JSONArray arry = CityData.getJSONArray(mListCountryId.get(mCountrySpinner.getSelectedItemPosition()));
                                            //int size = arry.length();
                                            //for (int j = 0; j < size; j++) {
                                               // City CityObj = new City();
                                                JSONObject CityData1 = productObj.getJSONObject(i);//0th element
                                                mListCity.add(mListCity.size(), CityData1.getString("city_name"));
                                                mListCityId.add(mListCityId.size(), CityData1.getString("id"));

                                            //}

                                        }
                                    }
                                    //

                                } else {
                                    Log.e(TAG, "JSONobject is null");
                                }

                            } catch (JSONException e) {
                                Log.e(TAG, "JSONExeption: " + e.getMessage());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        //                       if (MyApplication.isActivityVisible()) {
                        if (success == 1) {
                           /* if (mProgressDialog.isShowing()) {
                                mProgressDialog.dismiss();
                            }*/

                            mCityAdapter = new ArrayAdapter<String>(MyProfile.this, R.layout.new_spinner_item, mListCity);

                            mCitySpinner.setAdapter(mCityAdapter);
                            mCitySpinner.setTitle("Select City");
                            mCitySpinner.setVisibility(View.VISIBLE);

                            try{
                            if (!mListCityId.isEmpty() && !TextUtils.isEmpty(mCityId)) {
                                int index = mListCityId.indexOf(mCityId);
                                mCityName = mListCity.get(index);
                                mCitySpinner.setSelection(index);
                            }
                            }catch(Exception e){}
                            mCitySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                    int position = mCitySpinner.getSelectedItemPosition();
                                    mCityName = mListCity.get(mCitySpinner.getSelectedItemPosition());
                                    mCityId = mListCityId.get(mCitySpinner.getSelectedItemPosition());
                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> adapterView) {

                                }
                            });
                           /* if (!isProfileLoaded){
                                GetCurrentCustomerDetails();}*/

                        } else {
                           /* if (mProgressDialog.isShowing())
                                mProgressDialog.dismiss();*/
                            showDialog(MyProfile.this, "No City", "No City found. Please try again");
                            //Toast.makeText(MyProfile.this, "No Citys", Toast.LENGTH_LONG).show();
                        }
                        // }

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //you can handle the errors here
                        //if (MyApplication.isActivityVisible()) {
                            /*if (mProgressDialog.isShowing())
                                mProgressDialog.dismiss();*/
                            showDialog(MyProfile.this, "Network Error", "Problem connecting to internet. Please try again");
                            //Toast.makeText(MyProfile.this, "Problem connecting to internet. Please try again", Toast.LENGTH_SHORT).show();
                            Log.e(TAG, error.toString());
                        //}
                        //Toast.makeText(DiscountMasterActivity.this, "Problem connecting to internet. Please try again", Toast.LENGTH_LONG).show();
                    }
                });
    }
    private void getAllLanguages() {
        //While the app fetched data we are displaying a progress dialog
        //Creating a rest adapter
        //lleditprofile.setVisibility(View.GONE);
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url)
                .build();
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating an object of our api interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method
        api.getLanguages(
                //Passing the values by getting it from editTexts
                "none",
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        //Dismissing the loading progressbar

                        //Calling a method to show the list
                        BufferedReader reader = null;

                        //An string to store output from the server
                        String output = "";
                        JSONObject json = null;
                        int success = 0;
                        try {
                            //Initializing buffered reader
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));

                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);
                            try {
                                json = new JSONObject(tokener);
                                if (json != null) {

                                    //mListCity.add(0, "City");
                                    System.out.println("JSON Object: " + json);
                                    success = json.getInt("success");
                                    JSONArray productObj = json.getJSONArray("language"); // JSON Array
                                    if (productObj != null) {
                                        for (int i = 0; i < productObj.length(); i++) {
                                            JSONObject category1 = productObj.getJSONObject(i);//0th element

                                            mListLanguageId.add(category1.getString("id"));

                                            mListLanguage.add(category1.getString("language"));
                                            // mListCity.add(mListCity.size(), category1.getString("name"));
                                        }
                                    }
                                    //

                                } else {
                                    Log.e(TAG, "JSONobject is null");
                                }

                            } catch (JSONException e) {
                                Log.e(TAG, "JSONExeption: " + e.getMessage());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        //if (MyApplication.isActivityVisible()) {
                        if (success == 1) {

                            mLanguageAdapter = new ArrayAdapter(MyProfile.this, R.layout.new_spinner_item, mListLanguage);
                            mLanguageSpinner.setAdapter(mLanguageAdapter);

                            if (!mListLanguageId.isEmpty() && !TextUtils.isEmpty(mLanguageId)) {
                                int index = mListLanguageId.indexOf(mLanguageId);
                                //mLa = mListCity.get(index);
                                mLanguageSpinner.setSelection(index);
                            }

                            mLanguageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                    mLanguageId = mListLanguageId.get(i);
                                    //mCountryName = mCountry.get(mCountrySpinner.getSelectedItemPosition()).getCountryName();


                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> adapterView) {

                                    if (mProgressDialog.isShowing()){
                                        mProgressDialog.dismiss();
                                    }
                                }
                            });
                            getAllCountry();

                            if (mProgressDialog.isShowing()){
                                mProgressDialog.dismiss();
                            }
                        }

                    }


                    //}

                    @Override
                    public void failure(RetrofitError error) {
                        //you can handle the errors here
                        //if (MyApplication.isActivityVisible()) {
                        if (mProgressDialog.isShowing()){
                            mProgressDialog.dismiss();
                        }
                        showDialog(MyProfile.this, "Network Error", "Problem connecting to internet. Please try again");
                        //Toast.makeText(MyProfile.this, "Problem connecting to internet. Please try again", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, error.toString());
                        //}
                        //Toast.makeText(DiscountMasterActivity.this, "Problem connecting to internet. Please try again", Toast.LENGTH_LONG).show();
                    }
                });
    }
    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        if (mProgressDialog.isShowing())
            mProgressDialog.dismiss();
        Intent homeintent = new Intent(MyProfile.this, MainActivity.class);
        startActivity(homeintent);
        MyProfile.this.finish();
    }
    public void setnotification() {
        ImageView ivNotification = (ImageView) findViewById(R.id.imgNotification);
        tvNotificationCount = (TextView) findViewById(R.id.tvNotificationCount);

        tvNotificationCount.setText(String.valueOf(countNotification));
        ivNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvNotificationCount.setText("0");
                Intent notificationIntent = new Intent(MyProfile.this, MerchantNotification.class);
                startActivity(notificationIntent);
                //MyProfile.this.finish();
            }
        });
    }
    protected void setHeader() {
        TextView header = (TextView) findViewById(R.id.header_text);
        header.setText("My Profile");
        ImageView imgLogo = (ImageView) findViewById(R.id.imglogo);
        imgLogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homeintent = new Intent(MyProfile.this, MainActivity.class);
                startActivity(homeintent);
                MyProfile.this.finish();
            }
        });
    }


}
