package com.abaow.utils;


import android.app.ProgressDialog;
import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Binder;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.abaow.Pojo.Curriculum;
import com.abaow.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;


/**
 * Created by chetan on 14/4/18.
 */
public class PlayAudioBinder extends Binder{
    public MediaPlayer mMediaPlayer;



    private boolean isPlayingAudio = false;
    public String audiofile;
    // Caller activity context, used when play local audio file.
    private Context context = null;

    public boolean isLastmodule() {
        return lastmodule;
    }

    boolean lastmodule = false;
    int AudioDuration;
    Curriculum curriculum;
    int secProgess;

    public Handler getAudioProgressUpdateHandler() {
        return audioProgressUpdateHandler;
    }

    public void setAudioProgressUpdateHandler(Handler audioProgressUpdateHandler) {
        this.audioProgressUpdateHandler = audioProgressUpdateHandler;
    }

    private Handler audioProgressUpdateHandler;

    public int getUpdatestatus() {
        return updatestatus;
    }

    public void setUpdatestatus(int updatestatus) {
        this.updatestatus = updatestatus;
    }

    int updatestatus=4;

    public int getUserID() {
        return UserID;
    }

    public void setUserID(int userID) {
        UserID = userID;
    }

    int UserID;

    public boolean isPlayingAudio() {
        return isPlayingAudio;
    }

    public void setPlayingAudio(boolean playingAudio) {
        isPlayingAudio = playingAudio;
    }

    public int getSecProgess() {
        return secProgess;
    }

    public void setSecProgess(int secProgess) {
        this.secProgess = secProgess;
        Message updateAudioProgressMsg = new Message();
        updateAudioProgressMsg.what = 3;
        audioProgressUpdateHandler.sendMessage(updateAudioProgressMsg);
    }
    public Context getContext() {
        return context;
    }
    public void setContext(Context context) {
        this.context = context;
    }
    public void PlayMusic(String source,final Curriculum curriculum) {
        if (mMediaPlayer != null) {
            if (mMediaPlayer.isPlaying()) {
                mMediaPlayer.stop();
                mMediaPlayer = null;
            }
        }
        mMediaPlayer = new MediaPlayer();
        audiofile = source;
        mMediaPlayer.setWakeMode(context, PowerManager.PARTIAL_WAKE_LOCK);
        mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        try {
            //mMediaPlayer.setDataSource(source);
            //        source = Environment.getExternalStorageDirectory()+"/Music/AUD-20170925-WA0025.mp3";
            Log.v("FILEPATH: ",source);
            mMediaPlayer.setDataSource(source);
        } catch (IllegalArgumentException e) {
            Toast.makeText(getContext(), "You might not set the URI1 correctly!", Toast.LENGTH_LONG).show();
        } catch (SecurityException e) {
            Toast.makeText(getContext(), "You might not set the URI2 correctly!", Toast.LENGTH_LONG).show();
        } catch (IllegalStateException e) {
            Toast.makeText(getContext(), e.toString(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            mMediaPlayer.prepareAsync();
            //AudioDuration = duration(source);

            Log.v("Duration: ",Integer.toString(AudioDuration));
        } catch (IllegalStateException e) {
            Toast.makeText(getContext(), e.toString(), Toast.LENGTH_LONG).show();
        }/*catch (IOException e) {
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }*/
        mMediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                mMediaPlayer.start();
                setPlayingAudio(true);
                AudioDuration = mMediaPlayer.getDuration();
                Message updateAudioProgressMsg = new Message();
                updateAudioProgressMsg.what = 1;
                audioProgressUpdateHandler.sendMessage(updateAudioProgressMsg);
                //updateMediaProgress();
            }
        });
        mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
            public void onCompletion(MediaPlayer mp) {
                mMediaPlayer.stop();
                mMediaPlayer.release();
                mMediaPlayer = null;
                setPlayingAudio(false);
                updatestatus(curriculum.getModuleid(),getUserID(),curriculum.getCourseid());
                Message updateAudioProgressMsg = new Message();
                updateAudioProgressMsg.what = 2;
                audioProgressUpdateHandler.sendMessage(updateAudioProgressMsg);
                /*startActivity(getIntent());
                ViewCourseActivity.this.finish();*/
            }

        });
        mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener(){
            public boolean onError(MediaPlayer mp,int a,int b) {
                mMediaPlayer.reset();

                return true;

            }
        });
        mMediaPlayer.setOnBufferingUpdateListener(new MediaPlayer.OnBufferingUpdateListener() {
            public void onBufferingUpdate(MediaPlayer mp, int percent) {
                /** Method which updates the SeekBar secondary progress by current song loading from URL position*/
                setSecProgess(percent);
            }
        });
        mMediaPlayer.setOnSeekCompleteListener(new MediaPlayer.OnSeekCompleteListener() {
            @Override
            public void onSeekComplete(MediaPlayer arg0) {
                Log.v("Seek ", "onSeekComplete() current pos : " + arg0.getCurrentPosition());
                SystemClock.sleep(200);
                mMediaPlayer.start();
            }
        });



    }
    public void updatestatus(final int mmoduleid,int userid,int courseid){



        RestAdapter adapter1 = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter

        RestInterfac api = adapter1.create(RestInterfac.class);


        api.updatecrr(
                mmoduleid,
                userid,
                courseid,

                new retrofit.Callback<Response>() {


                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;
                        JSONArray usercourse = null;
                        String[] curriculum;


                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {


                                success = json.getInt("success");
                                int lastmo = json.getInt("last_module");
                                if (lastmo == mmoduleid){
                                    lastmodule = true;
                                }else{
                                    lastmodule = false;
                                }



                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                        // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}

                        if (success == 1) {
                            setUpdatestatus(1);
                        } else {
                            setUpdatestatus(2);
                        }

                         /*else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Invalid Credentials", "please enter valid Email_Id and Password");
                        }*/

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        Log.e("Update Status Error: ",error.toString());
                        setUpdatestatus(3);
                        //If any error occured displaying the error as toast

                    }
                }
        );

    }
    // Start play audio.
    public void startAudio()
    {

        if(mMediaPlayer!=null) {
            mMediaPlayer.start();
        }
    }
    // Pause playing audio.
    public void pauseAudio()
    {
        if(mMediaPlayer!=null) {
            mMediaPlayer.pause();
        }
    }

    // Stop play audio.
    public void stopAudio()
    {
        if(mMediaPlayer!=null) {
            mMediaPlayer.stop();
            destroyAudioPlayer();
        }
    }
    // Destroy audio player.
    private void destroyAudioPlayer()
    {
        if(mMediaPlayer!=null)
        {
            if(mMediaPlayer.isPlaying())
            {
                mMediaPlayer.stop();
            }

            mMediaPlayer.release();

            mMediaPlayer = null;
        }
    }

    // Return current audio play position.
    public int getCurrentAudioPosition()
    {
        int ret = 0;
        if(mMediaPlayer != null)
        {
            ret = mMediaPlayer.getCurrentPosition();
        }
        return ret;
    }
    public int getAudioDuration()
    {
        int ret = 0;
        if(mMediaPlayer != null)
        {
            ret = mMediaPlayer.getDuration();
        }
        return ret;
    }
    public void seekto(int seek){
        mMediaPlayer.seekTo(seek);
    }

}
