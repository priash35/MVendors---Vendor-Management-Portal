package com.abaow.utils;

/**
 * Created by chetan on 12/12/17.
 */
public class Constants {
    public static final String PARAMETER_SEP = "&";
    public static final String PARAMETER_EQUALS = "=";
    //public static final String TRANS_URL = "https://test.ccavenue.com/transaction/initTrans";
    public static final String TRANS_URL = "https://secure.ccavenue.com/transaction/initTrans";
    public static final String IMAGE_CAPTURE_DIR="Logs";
    public static final String HOME="RichnHappy";


}
