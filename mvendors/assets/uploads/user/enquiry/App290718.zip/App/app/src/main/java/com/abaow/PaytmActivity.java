package com.abaow;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;


import com.abaow.utils.AvenuesParams;
import com.abaow.utils.RestInterfac;
import com.abaow.utils.StaticDataMember;
import com.paytm.pgsdk.PaytmMerchant;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.HashMap;
import java.util.Map;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;



public class PaytmActivity extends AppCompatActivity  implements PaytmPaymentTransactionCallback {
    ProgressDialog mProgressDialog;
    Intent mainIntent;
    String coursename,email,phone,order_status;
    int courseid;

    private String orderId="" , mid="", custid="", amt="",website,channel,industry_type;
    //String url ="http://www.blueappsoftware.com/payment/payment_paytm/generateChecksum.php";
    String varifyurl =  ""; //
            //"https://securegw.paytm.in/theia/paytmCallback?paytmpay=";//
            //"https://pguat.paytm.com/paytmchecksum/paytmCallback.jsp";
    String CHECKSUMHASH ="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
        //initOrderId();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        mainIntent = getIntent();
        custid = Integer.toString(mainIntent.getIntExtra("userid",0));
        courseid = mainIntent.getIntExtra("courseid",0);
        coursename = mainIntent.getStringExtra("coursename");
        orderId =  mainIntent.getStringExtra("order_id");
        amt =  mainIntent.getStringExtra("amount");
        GetCurrentCustomerDetails();

        //getChecksum();

    }



    @Override
    public void onTransactionResponse(Bundle bundle) {
        Log.e("checksum1 ", " respon true " + bundle.toString());
        order_status =bundle.getString("STATUS");
        updatestatus();
        if (order_status.equalsIgnoreCase("TXN_SUCCESS")){
            registercourse();
        }else{
            showDialog(PaytmActivity.this, "Transaction Not Successful", "Please try again later.");
        }

        //showDialog(PaytmActivity.this, bundle.toString(), "");
    }

    @Override
    public void networkNotAvailable() {
        showDialog(PaytmActivity.this, "Network Unavailable", "Please try again later.");
    }

    @Override
    public void clientAuthenticationFailed(String s) {
        showDialog(PaytmActivity.this, "Login Failed", "Please try again.");
    }

    @Override
    public void someUIErrorOccurred(String s) {
        Log.e("checksum ", " ui fail respon  "+ s );
        showDialog(PaytmActivity.this, "Error", "Please try your purchase again");
    }

    @Override
    public void onErrorLoadingWebPage(int i, String s, String s1) {
        Log.e("checksum2 ", " error loading pagerespon true "+ s + "  s1 " + s1);
        showDialog(PaytmActivity.this, "Error", "Please try your purchase again");
    }

    @Override
    public void onBackPressedCancelTransaction() {
        Log.e("checksum3 ", " cancel call back respon  " );
        showDialog(PaytmActivity.this, "Transaction Cancelled", "Your purchase is cancelled");

    }

    @Override
    public void onTransactionCancel(String s, Bundle bundle) {
        Log.e("checksum4 ", "  transaction cancel " );
        Intent nxt = new Intent(PaytmActivity.this, CourseOverview.class);
        nxt.putExtra("course",courseid);
        startActivity(nxt);
        PaytmActivity.this.finish();
    }
    private void getChecksum() {
        // listView = (ListView) findViewById(R.id.course_detail);

        // Defined Array values to show in ListView

        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);
        //Creating a RestAdapter
        RestAdapter adapter1 = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter1.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.getCheckSum(
                mid,
                orderId,
                custid,
                channel,
                amt,
                website,
                varifyurl+orderId,
                industry_type,
                //email,
                //"7777777777",//phone
                //Passing the values by getting it from editTexts


                //Creating an anonymous callback
                new retrofit.Callback<Response>() {


                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;
                        JSONArray usercourse = null;
                        String[] curriculum;

                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {
                                CHECKSUMHASH = json.getString("CHECKSUMHASH");
                                String ordid = json.getString("ORDER_ID");
                                String status = json.getString("payt_STATUS");
                                Log.e("checksum response ",CHECKSUMHASH + " "+ordid+" "+status);



                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                        // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}


                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //PaytmPGService Service =PaytmPGService.getStagingService();
                        // when app is ready to publish use production service
                         PaytmPGService  Service = PaytmPGService.getProductionService();

                        // now call paytm service here
                        //below parameter map is required to construct PaytmOrder object, Merchant should replace below map values with his own values
                        Map<String, String> paramMap = new HashMap<String, String>();
                        //these are mandatory parameters
                        // ye sari valeu same hon achaiye

                        //MID provided by paytm
                        paramMap.put("MID", mid);
                        paramMap.put("ORDER_ID", orderId);
                        paramMap.put("CUST_ID", custid);
                        paramMap.put("CHANNEL_ID", channel);
                        paramMap.put("TXN_AMOUNT", amt);
                        paramMap.put("WEBSITE", website);
                        paramMap.put("CALLBACK_URL" ,varifyurl+orderId);
                        //paramMap.put( "EMAIL" , email);   // no need
                        //paramMap.put( "MOBILE_NO" , "7777777777");  // phone
                        paramMap.put("CHECKSUMHASH" ,CHECKSUMHASH);
                        //paramMap.put("PAYMENT_TYPE_ID" ,"CC");    // no need
                        paramMap.put("INDUSTRY_TYPE_ID", industry_type);

                        PaytmOrder Order = new PaytmOrder( paramMap);

                        Log.e("checksum22 ", paramMap.toString());


                        Service.initialize(Order,null);
                        // start payment service call here
                        Service.startPaymentTransaction(PaytmActivity.this, true, true, PaytmActivity.this  );


                         /*else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Invalid Credentials", "please enter valid Email_Id and Password");
                        }*/

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //If any error occured displaying the error as toast
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(PaytmActivity.this, error.toString(), "");
                    }
                }
        );
    }

    public void showDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx, R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                Intent nxt = new Intent(PaytmActivity.this, CourseOverview.class);
                nxt.putExtra("course",courseid);
                startActivity(nxt);
                PaytmActivity.this.finish();
            }
        });

        builder.show();
    }
    private void GetCurrentCustomerDetails() {
        /*mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();*/

        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.getUserInfoAll(

                //Passing the values by getting it from editTexts
                Integer.parseInt(custid),


                //Creating an anonymous callback
                new Callback<Response>() {

                    @Override
                    public void success(retrofit.client.Response result, retrofit.client.Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String mCity="",mCountry="";

                        //An string to store output from the server
                        String output = "";
                        JSONArray jsonObj;
                        JSONObject json = null;
                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            //{"customer_details":[{"id":"21","firstname":"vnts","lastname":"vnts","mobile":"7588676808","email":"vnts@gmail.com","dob":"1966-05-24","City":"hgff","city":"pune","pincode":"411029","gender":"Male","image":"http:\/\/referplus.ele45.com\/referplus\/app\/webroot\/img\/uploads\/users\/vnts_16-05-24_10-45-05.png"}],"success":1,"message":"Customer details"}
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            jsonObj = json.getJSONArray("userinfo");
                            if (json != null) {
                                for (int i = 0; i < jsonObj.length(); i++) {
                                    JSONObject obj = jsonObj.getJSONObject(i);
                                    System.out.println("JSON Object: " + json);

                                    email =obj.getString("email");
                                    phone = obj.getString("mobile");
                                }
                                getPaytmparams();

                            }
                            // Toast.makeText(this, json.getString("meassage"),Toast.LENGTH_LONG).show();
                            //  showDialog(this,"success", json.getString("meassage"));
                        } catch (IOException e) {
                            showDialog(PaytmActivity.this, "Network Error", "Please try again later.");
                        } catch (JSONException e) {
                            showDialog(PaytmActivity.this, "Network Error", "Please try again later.");
                        }



                    }


                    @Override
                    public void failure(RetrofitError error) {
                        /*if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();*/
                        //If any error occured displaying the error as toast
                        //Toast.makeText(this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(PaytmActivity.this, "Network Error", "Please try again later.");
                    }
                }
        );
    }
    private void getPaytmparams() {
        /*mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();*/

        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.getPaytmparams(

                //Passing the values by getting it from editTexts
                "161070",


                //Creating an anonymous callback
                new Callback<Response>() {

                    @Override
                    public void success(retrofit.client.Response result, retrofit.client.Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String mCity="",mCountry="";

                        //An string to store output from the server
                        String output = "";
                        JSONArray jsonObj;
                        JSONObject json = null;
                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            //{"customer_details":[{"id":"21","firstname":"vnts","lastname":"vnts","mobile":"7588676808","email":"vnts@gmail.com","dob":"1966-05-24","City":"hgff","city":"pune","pincode":"411029","gender":"Male","image":"http:\/\/referplus.ele45.com\/referplus\/app\/webroot\/img\/uploads\/users\/vnts_16-05-24_10-45-05.png"}],"success":1,"message":"Customer details"}
                            JSONTokener tokener = new JSONTokener(output);
                            json = new JSONObject(tokener);
                            if (json != null) {


                                mid = json.getString("MID");
                                industry_type = json.getString("INDUSTRY_TYPE_ID");
                                channel = json.getString("CHANNEL_ID");
                                website = json.getString("WEBSITE");
                                varifyurl = json.getString("CALLBACK_URL");
                                getChecksum();

                            }



                            // Toast.makeText(this, json.getString("meassage"),Toast.LENGTH_LONG).show();
                            //  showDialog(this,"success", json.getString("meassage"));
                        } catch (IOException e) {
                            showDialog(PaytmActivity.this, "Network Error", "Please try again later.");
                        } catch (JSONException e) {
                            showDialog(PaytmActivity.this, "Network Error", "Please try again later.");
                        }



                    }


                    @Override
                    public void failure(RetrofitError error) {
                        /*if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();*/
                        //If any error occured displaying the error as toast
                        //Toast.makeText(this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(PaytmActivity.this, "Network Error", "Please try again later.");
                    }
                }
        );
    }
    protected void registercourse() {

        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);
        //Creating a RestAdapter
        RestAdapter adapter1 = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter1.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.registercourse(
                courseid,
                Integer.parseInt(custid),


                //Passing the values by getting it from editTexts


                //Creating an anonymous callback
                new retrofit.Callback<Response>() {


                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;
                        JSONArray usercourse = null;
                        JSONArray curriculum = null;


                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {


                                success = json.getInt("success");


                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                        // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}

                        if (success == 1) {
                            if (mProgressDialog.isShowing())
                                mProgressDialog.dismiss();
                            try {
                                showNextDialog(PaytmActivity.this, "Registration Successful", "You have been registered for the course " + coursename.toString());

                            } catch (Exception e) {
                                Log.e("json error: ", e.toString());
                            }

                        } else {
                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(PaytmActivity.this, "Invalid Credentials", "Please enter valid email or Password");

                        }
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //If any error occured displaying the error as toast
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(PaytmActivity.this, "Network Error", "Problem connecting to internet. Please try again later");
                    }

                }
        );
    }
    public void showNextDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx, R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                Intent nxt = new Intent(PaytmActivity.this, MainActivity.class);
                startActivity(nxt);
                PaytmActivity.this.finish();
            }
        });

        builder.show();

    }
    protected void updatestatus() {

        //Creating a RestAdapter
        RestAdapter adapter1 = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter1.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.updatestatus(
                orderId,
                order_status,
                //Creating an anonymous callback
                new retrofit.Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;


                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);
                            json = new JSONObject(tokener);
                            if (json != null) {
                                success = json.getInt("success");
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //If any error occured displaying the error as toast

                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(PaytmActivity.this, "Network Error", "Problem connecting to internet. Please try again later");
                    }

                }
        );
    }

}
