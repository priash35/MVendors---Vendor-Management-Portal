package com.abaow;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Handler;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.abaow.utils.RestInterfac;
import com.abaow.utils.StaticDataMember;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Timer;
import java.util.TimerTask;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by admin on 9/19/2016.
 */
public class Resetpassword extends Activity {

    EditText edttxt;
    Button btnSubmit;
    TextView txtOTP;
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList, mDrawerListBottom;
    private ImageView imgDrawer, imgBack;
    private String loginId, loginName;
    private String old_password, new_password;
    StringBuilder strBuilder;
    LinearLayout llBottom;
    private String tabToOpen = "0";
    public static final String MyPREFERENCES = "mypref";
    private String catIdString, name;
    SharedPreferences sharedpreferences;
    private String from, fromFilter = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initUi();

    }

    private void initUi()
    {
        setContentView(R.layout.activity_resetpassword);
        Typeface notoFace = Typeface.createFromAsset(getResources().getAssets(), "NotoSans-Regular.ttf");
        Typeface notoFaceBold = Typeface.createFromAsset(getResources().getAssets(), "NotoSans-Bold.ttf");
        sharedpreferences = getSharedPreferences("mypref", Context.MODE_PRIVATE);

        //sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        //loginId = Integer.toString(sharedpreferences.getInt("loggedin_user_id", 0));
        //loginName = sharedpreferences.getString("login_name", null);
        //catIdString = sharedpreferences.getString("catIdString", null);

        //name = sharedpreferences.getString("loggedin_user_name", null);
        //Log.v("name to be printed", "" + name);
        /*if (catIdString == null) {
            catIdString = "";
        }

        if (loginId == null) {
            try {
                loginId = getIntent().getExtras().getString("loggedin_user_id");
            } catch (NullPointerException e) {

            }

        }
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString("loggedin_user_id", loginId);

        editor.apply();*/
      /*  from = getIntent().getExtras().getString("from");
        fromFilter = getIntent().getExtras().getString("fromFilter");*/
        //

        txtOTP = (TextView) findViewById(R.id.txtOTP);
        txtOTP.setTypeface(notoFaceBold);

        btnSubmit = (Button) findViewById(R.id.btnSubmit);

        if(sharedpreferences.getString("passwordBtn",null)!=null) {
            if (sharedpreferences.getString("passwordBtn", null).equals("0"))
            {
                btnSubmit.setVisibility(View.GONE);
                showDialog(Resetpassword.this,"Try After short while","Please try again after minute if you did'nt receive OTP");
                //Toast.makeText(Resetpassword.this,"Please try after some time if you did'nt receive OTP",Toast.LENGTH_SHORT).show();
            }else
            {
                btnSubmit.setVisibility(View.VISIBLE);

            }
        }
        edttxt = (EditText) findViewById(R.id.edttxt);
        edttxt.setTypeface(notoFace);
        btnSubmit.setTypeface(notoFaceBold);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //   Intent i = new Intent(Resetpassword.this, LoginActivity.class);
                btnSubmit.setVisibility(View.GONE);
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putString("passwordBtn", "0");
                editor.apply();
                final Handler handler=new Handler();
                final Runnable Update = new Runnable() {
                    public void run() {
                      //  btnSubmit.setVisibility(View.VISIBLE);
                        //initUi();
                        System.out.println("Post Delayed Inside Dialog  ");
                        SharedPreferences.Editor editor = sharedpreferences.edit();
                        editor.putString("passwordBtn", "1");
                        editor.apply();


                    }
                };
                handler.postDelayed(Update,60000);
                ForgetPassword();

           /*     Timer swipeTimer = new Timer();
                swipeTimer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        handler.post(Update);
                    }
                }, 6000, 6000);
*/


                //  startActivity(i);
            }
        });
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void ForgetPassword() {
/*
 mProgressDialog = new ProgressDialog(getActivity().getBaseContext());
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();
*/

        //Creating a RestAdapter
        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.resetpwd(

                edttxt.getText().toString().trim(),

                //  input_new_pass.getText().toString().trim(),

                //Creating an anonymous callback
                new Callback<Response>() {


                    @Override
                    public void success(Response result, Response response) {

                        BufferedReader reader = null;
                        int success = 0;
                        String mloginId = "";
                        //An string to store output from the server
                        String output = "";
                        JSONObject json = null;
                        JSONArray jsonObj;
                        
                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            //{"success":1,"collected_coupons":8,"awarded_coupons":9,"total_credit_points":"17","message":"Coupons count and credit points of this customer"}
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);

                            if (json != null) {

                                if (json.getInt("success") == 0) {
                                    showDialog(Resetpassword.this, "Reset Password Unsuccessful", json.getString("message"));
                                    btnSubmit.setVisibility(View.VISIBLE);

                                } else if (json.getInt("success") == 2){
                                    showDialog(Resetpassword.this, "Pending Activation", json.getString("message"));

                                }
                                else{
                                    //showDialog(Resetpassword.this, "Rest Password Successful", json.getString("message"));
                                    Intent intent = new Intent(Resetpassword.this, LoginActivity.class);
                                    String extra = "reset";
                                    intent.putExtra("update", extra.toString());
                                    startActivity(intent);
                                    Resetpassword.this.finish();
                                }

                            }

                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }

                    @Override
                    public void failure(RetrofitError error) {
                        Log.e("Forgot Password Error", "" + error.toString());

                        showDialog(Resetpassword.this, "Network Error", "Problem connecting to internet. Please try again later");
                    }
                });

    }

    public void showDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(Resetpassword.this, R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                /*Intent intent = new Intent(Resetpassword.this, LoginActivity.class);
                String extra = "reset";
                intent.putExtra("update", extra.toString());
                startActivity(intent);
                Resetpassword.this.finish();*/
            }
        });

        builder.show();
    }
    @Override
    public void onBackPressed() {

        super.onBackPressed();
    }

}

