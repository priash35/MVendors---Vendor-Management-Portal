package com.example.hp.myapplication;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


public class AddRecordActivity extends AppCompatActivity {

    Button btnAddRecord;
    EditText vehicle_no,driver_name,address,contact,fine;
    RadioGroup payment_mode;
    RadioButton paid, not_paid, radioButton;
    DatabaseHelper myDb;
    String mode="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_record);
        myDb = new DatabaseHelper(this);
        vehicle_no=(EditText) findViewById(R.id.textVNoValue);
        driver_name=(EditText) findViewById(R.id.textDriverNameValue);
        address=(EditText) findViewById(R.id.textAddressValue);
        contact=(EditText) findViewById(R.id.textMobileNumberValue);
        fine=(EditText) findViewById(R.id.textFineValue);
        payment_mode = (RadioGroup) findViewById(R.id.payment_mode);

        //payment_mode.setOnCheckedChangeListener((RadioGroup.OnCheckedChangeListener) this);
        //payment_mode.setOnCheckedChangeListener((RadioGroup.OnCheckedChangeListener) this);

        paid = (RadioButton)findViewById(R.id.paid);
        not_paid = (RadioButton)findViewById(R.id.not_paid);
        btnAddRecord=(Button) findViewById(R.id.btnAddRecords);


        RadioGroup rg = (RadioGroup) findViewById(R.id.payment_mode);

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch(checkedId){
                    case R.id.paid:
                        mode="Paid";
                        // do operations specific to this selection
                        break;
                    case R.id.not_paid:
                        mode="Not Paid";
                        // do operations specific to this selection
                        break;

                }
            }
        });

        btnAddRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isInserted = myDb.insertData(vehicle_no.getText().toString(),driver_name.getText().toString(),address.getText().toString(),contact.getText().toString(),fine.getText().toString(),mode.toString());
                if(isInserted == true) {
                    Toast.makeText(AddRecordActivity.this, "Data Inserted", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(AddRecordActivity.this, UpdateChoiceActivity.class);
                    startActivity(intent);
                }
                else
                    Toast.makeText(AddRecordActivity.this,"Data not Inserted",Toast.LENGTH_LONG).show();
            }

        });


    }
}
