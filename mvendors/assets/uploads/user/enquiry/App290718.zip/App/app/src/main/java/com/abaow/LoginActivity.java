package com.abaow;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.abaow.utils.OnSmsCatchListener;
import com.abaow.utils.RestInterfac;
import com.abaow.utils.SmsVerifyCatcher;
import com.abaow.utils.StaticDataMember;
import com.abaow.utils.UtilityFile;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.FacebookSdk;
import com.facebook.LoggingBehavior;
import com.facebook.appevents.AppEventsConstants;
import com.facebook.appevents.AppEventsLogger;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.FirebaseMessaging;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;



public class LoginActivity extends Activity  {

    private final static String TAG = LoginActivity.class.getSimpleName();

        /*    public CallbackManager callbackManager;
            private AccessTokenTracker accessTokenTracker;
            private ProfileTracker profileTracker;*/
        private ContactsContract.Profile currentProfile;
        private FirebaseAnalytics mFirebaseAnalytics;
        private EditText uname, password;
        TextView register, forgot, tvTitle,tv;
        private Typeface notoFaceBold, notoFace;
        Button submit,createacc;
        SharedPreferences sharedpreferences;
        ProgressDialog mProgressDialog;
        String sharedprefLogin;
        String mloginId = "",from ="";
        String mloginName = "", mobile = "", role = "", name = "", img = "";
        private static final int REQUEST_WRITE_STORAG = 77;
        private static final int REQUEST_READ_STORAG = 55;
        private static final String TAG_REGISTRATION_CONFIRM = "registration_confirm";
        private static final String TAG_USER_REGISTER = "registered";
        boolean isUserRegistered = false;
        boolean isRegisConfirm = false;
        RequestQueue mRequestQueue;
        SmsVerifyCatcher smsVerifyCatcher;


        private Button btnFacebook, btnTwitterLogin;
    /*private LoginButton facebookButton;
    private TwitterLoginButton twitterLoginButton;*/

        public static void writeException_1(String msg) throws IOException {
            String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());

            String file_name = UtilityFile.getRootDir() + File.separator + "error_file" + ".txt";
            try {
                PrintWriter writer = new PrintWriter(file_name, "UTF-8");
                writer.println(msg);
                writer.close();
            } catch (IOException e) {
                // do something
            }

        }

        @Override
        protected void onResume() {
            super.onResume();
            String userName = sharedpreferences.getString("username", null);
            String pwd = sharedpreferences.getString("password", null);

            if (pwd != null && userName != null) {
                uname.setText(userName);
                password.setText(pwd);
                //  getUser();
            }
            isUserRegistered = sharedpreferences.getBoolean(TAG_USER_REGISTER, false);
            isRegisConfirm = sharedpreferences.getBoolean(TAG_REGISTRATION_CONFIRM, false);
            if (isUserRegistered && !isRegisConfirm) {
                Intent nxt = new Intent(getApplicationContext(), Registration.class);
                startActivity(nxt);
                //   LoginActivity.this.finish();
            }
        }

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
            //      char[] matrix = new char[] {'H', 'e', 'l', 'l', 'o'};

            //  mFirebaseAnalytics.logEvent();
            //    System.out.println(matrix[7]);

            try {

                //   Bundle bundle = new Bundle();
                //  bundle.putString(FirebaseAnalytics.Param.ITEM_ID, id);

                //   mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT);

                FacebookSdk.sdkInitialize(getApplicationContext());
                AppEventsLogger.activateApp(this);
                AppEventsLogger logger = AppEventsLogger.newLogger(this);
                logger.logEvent(AppEventsConstants.EVENT_NAME_PURCHASED);
                FacebookSdk.setIsDebugEnabled(true);
                FacebookSdk.addLoggingBehavior(LoggingBehavior.APP_EVENTS);

                UtilityFile.createMediaDir();

       /* FacebookSdk.sdkInitialize(getApplicationContext());

        //Initializing TwitterAuthConfig, these two line will also added automatically while configuration we did
        TwitterAuthConfig authConfig = new TwitterAuthConfig(TWITTER_KEY, TWITTER_SECRET);
        Fabric.with(this, new Twitter(authConfig));


*/
                if (getIntent().hasExtra("update")) {
                    from = getIntent().getExtras().getString("update");
                }
                sharedpreferences = getSharedPreferences("mypref", Context.MODE_PRIVATE);
                //    requestWindowFeature(Window.FEATURE_NO_TITLE);
                submit = (Button) findViewById(R.id.btnSubmit);
                smsVerifyCatcher = new SmsVerifyCatcher(this, new OnSmsCatchListener<String>() {
                    @Override
                    public void onSmsCatch(String message) {
                        String code = parseCode(message);//Parse verification code
                        password.setText(code);//set code in edit text
                        //then you can send verification code to server
                    }
                });
                smsVerifyCatcher.setPhoneNumberFilter("ABAOWS");
                requestPermissions();

                sharedprefLogin = sharedpreferences.getString("logout", null);
                if ((sharedprefLogin == null) || !(sharedprefLogin.equals("LOGIN"))) {
                    sharedprefLogin = "Logout";
                } else {

                }
                Calendar c = Calendar.getInstance();


                if (sharedprefLogin.equals("LOGIN")) {

                    Intent nxt = new Intent(LoginActivity.this, MainActivity.class);
                    nxt.putExtra("loggedin_user_id", mloginId);
                    nxt.putExtra("login_name", mloginName);
                    //nxt.putExtra("loggedin_user_name", name);
                    //nxt.putExtra("image", img);
                    //for tab layout
                    //nxt.putExtra("MyTab", "0");
                    Log.v("intent put", "name to be printeddd" + name);
                    startActivity(nxt);
                    LoginActivity.this.finish();


                } else {


                /*requestWindowFeature(Window.FEATURE_NO_TITLE);
                this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                        WindowManager.LayoutParams.FLAG_FULLSCREEN);*/
                    isUserRegistered = sharedpreferences.getBoolean(TAG_USER_REGISTER, false);
                    isRegisConfirm = sharedpreferences.getBoolean(TAG_REGISTRATION_CONFIRM, false);
                    if (isUserRegistered && !isRegisConfirm) {
                        Intent nxt = new Intent(getApplicationContext(), Registration.class);
                        startActivity(nxt);
                        //  LoginActivity.this.finish();
                    }

                    setContentView(R.layout.login);


                    notoFace = Typeface.createFromAsset(getResources().getAssets(), "NotoSans-Regular.ttf");
                    notoFaceBold = Typeface.createFromAsset(getResources().getAssets(), "NotoSans-Bold.ttf");

                    uname = (EditText) findViewById(R.id.uid);
                    password = (EditText) findViewById(R.id.pwd);
                    register = (TextView) findViewById(R.id.tvregister);
                    tv = (TextView) findViewById(R.id.tv);
                    forgot = (TextView) findViewById(R.id.forgot_password);
                    createacc = (Button) findViewById(R.id.btnCreateAnacc);

                    if (from.equals("reset")) {
                        password.requestFocus();
                        System.out.println("Inside Dialog  ");
                        showDialog(LoginActivity.this, "Password Reset", "Password Reset Successfully");
                   /* forgot.setVisibility(View.GONE);
                    Handler handler=new Handler();
                    Runnable Update = new Runnable() {
                        public void run() {
                            forgot.setVisibility(View.VISIBLE);
                            System.out.println("Post Delayed Inside Dialog  ");

                        }
                    };
                    handler.postDelayed(Update,600000);
*/
                    }

                    submit = (Button) findViewById(R.id.btnSubmit);


                    uname.setTypeface(notoFace);
                    password.setTypeface(notoFace);
                    register.setTypeface(notoFace);
                    forgot.setTypeface(notoFace);
                    submit.setTypeface(notoFaceBold);
                    createacc.setTypeface(notoFaceBold);

                    mRequestQueue = Volley.newRequestQueue(this);





                    createacc.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent nxt = new Intent(getApplicationContext(), Registration.class);
                            startActivity(nxt);
                            //    LoginActivity.this.finish();
                        }
                    });
                    tv.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent nxt = new Intent(getApplicationContext(), Registration.class);
                            startActivity(nxt);
                            //    LoginActivity.this.finish();
                        }
                    });

                    submit.setOnClickListener(new OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            getYoutubeurl();
                            getUser();

                        }
                    });

                    forgot.setOnClickListener(new OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent nxt1 = new Intent(getApplicationContext(), Resetpassword.class);
                            startActivity(nxt1);
                            //      LoginActivity.this.finish();
                        }
                    });
                }


            }catch (Exception e)
            {
                try {
                    writeException_1(e.toString());
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }

        }

        private void getYoutubeurl() {

            StringRequest stringRequest = new StringRequest(Request.Method.GET, StaticDataMember.youtubeurl, new com.android.volley.Response.Listener<String>() {
                @Override
                public void onResponse(String response) {


                    int code = 0;
                    String msg;

                    try {
                        JSONObject jsonObject1 = new JSONObject(response);

                        JSONArray jsonArray = jsonObject1.getJSONArray("url");
                        System.out.print("response :----" + jsonObject1.toString());
                        code = jsonObject1.getInt("success");
                        msg = jsonObject1.getString("message");


                        if (code == 0) {
                            Toast.makeText(LoginActivity.this, code, Toast.LENGTH_SHORT).show();
                        } else {

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);

                                String acceptedurl = jsonObject.getString("video_url");

                                SharedPreferences.Editor editor = sharedpreferences.edit();
                                editor.putString("videourl",acceptedurl);
                                editor.apply();
                                System.out.print("abaowvideourl"+acceptedurl);
                            }
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }

            }, new com.android.volley.Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    Log.d("", ""+error.toString());

                }
            });

            mRequestQueue.add(stringRequest);

        }

        @Override
        protected void onDestroy() {
            super.onDestroy();
            SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.putString("passwordBtn", "1");
            editor.apply();

        }

        /**
         * method to initialise facebook login
         */

        public void showDialog(Context ctx, String title, CharSequence message) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(ctx, R.style.MyDialogTheme);

            if (title != null) builder.setTitle(title);

            builder.setMessage(message);
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });

            builder.show();
        }



        public void requestPermissions() {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_READ_STORAG);
            } else {
            }

            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_STORAG);
            } else {
            }
            int GET_MY_PERMISSION = 1;
            if(ContextCompat.checkSelfPermission(LoginActivity.this,Manifest.permission.READ_SMS)
                    != PackageManager.PERMISSION_GRANTED){
                if(ActivityCompat.shouldShowRequestPermissionRationale(LoginActivity.this,
                        Manifest.permission.READ_SMS)){
            /* do nothing*/
                }
                else{

                    ActivityCompat.requestPermissions(LoginActivity.this,
                            new String[]{Manifest.permission.READ_SMS},GET_MY_PERMISSION);
                }
            }
        }

        @Override
        public void onStop() {
            super.onStop();
            smsVerifyCatcher.onStop();

        }
        @Override
        protected void onStart() {
            super.onStart();
            smsVerifyCatcher.onStart();
        }



        @Override
        public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            if (requestCode == REQUEST_READ_STORAG) {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    smsVerifyCatcher.onRequestPermissionsResult(requestCode, permissions, grantResults);
                } else {
                    Toast.makeText(this, "Please grant read storage permission to read data from SD Card", Toast.LENGTH_SHORT).show();
                }
            } else {
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            }

       /* if (requestCode == REQUEST_WRITE_STORAG) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            } else {
                Toast.makeText(this, "Please grant write storage permission to write data into SD Card", Toast.LENGTH_SHORT).show();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }*/
        }

        /**
         * Method to get login details of user
         */
        public void getUser() {
            mProgressDialog = new ProgressDialog(this);
            mProgressDialog.setIndeterminate(true);
            mProgressDialog.setMessage("Loading...");
            mProgressDialog.show();

            //new code added as my progress dialog was getting dismissed if user click on screen
            mProgressDialog.setCancelable(false);
            mProgressDialog.setCanceledOnTouchOutside(false);
            //Creating a RestAdapter
            RestAdapter adapter = new RestAdapter.Builder()
                    .setEndpoint(StaticDataMember.url) //Setting the Root URL
                    .build(); //Finally building the adapter
            //final RestAdapter adapter = httpsAdapter.createAdapter(this);

            //Creating object for our interface

            RestInterfac api = adapter.create(RestInterfac.class);

            //Defining the method insertuser of our interface
            api.getUser(

                    //Passing the values by getting it from editTexts
                    uname.getText().toString(),
                    password.getText().toString(),


                    //Creating an anonymous callback
                    new retrofit.Callback<Response>() {


                        @Override
                        public void success(Response result, Response response) {
                            BufferedReader reader = null;
                            int success = 0;
                            String mloginId = "";
                            String mloginName = "", mobile = "", memail = "", name = "", img = "";
                            String mCityName = "", mCityId = "";
                            //An string to store output from the server
                            String output = "";
                            JSONObject userinfo = null;
                            JSONArray usercourse = null;
                            JSONObject json = null;
                            Intent nxt;
                            try {
                                //Initializing buffered reader

                                reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                                //Reading the output in the string
                                output = reader.readLine();
                                JSONTokener tokener = new JSONTokener(output);

                                json = new JSONObject(tokener);
                                if (json != null) {

                                    //"userdata":{"id":"3","name":"chetan","password":"chetan123","mobile":"23455432","email":"cj@gmail.com","city":"Pune","country":"India","status":"ACTIVE","created":"2017-11-14 04:16:41"},"message":"Success"}
                                    success = json.getInt("success");
                                    if (json.has("userdata")) {
                                        userinfo = json.getJSONObject("userdata");                                  //usercourse = json.getJSONArray("usercourse");


                                        mloginId = userinfo.getString("id");
                                        mloginName = userinfo.getString("name");
                                        mobile = userinfo.getString("mobile");
                                    }
                                    //memail = userinfo.getString("email");
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                            // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}

                            if (success == 1) {
                                if (mProgressDialog.isShowing())
                                    mProgressDialog.dismiss();

                                Log.v("json name", "username" + name);
                                SharedPreferences.Editor editor = sharedpreferences.edit();
                                editor.putString("username", uname.getText().toString());
                                editor.putString("password", password.getText().toString());
                                editor.putString("Mobile", mobile);
                                editor.putString("logout", "LOGIN");
                                editor.putInt("loggedin_user_id", Integer.parseInt(mloginId));
                                editor.putString("login_name", mloginName);
                                //editor.putString("currcourse", usercourse.toString());


                                nxt = new Intent(LoginActivity.this, MainActivity.class);
                                System.out.println(" Logged User Id " + mloginId);
                                nxt.putExtra("loggedin_user_id", mloginId);
                                nxt.putExtra("login_name", mloginName);
                                editor.apply();

                                startActivity(nxt);
                                LoginActivity.this.finish();

                            } else {
                                // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                                showDialog(LoginActivity.this, "Invalid Credentials", "Please enter valid email or Password");

                            }
                            if (mProgressDialog.isShowing())
                                mProgressDialog.dismiss();

                         /*else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Invalid Credentials", "please enter valid Email_Id and Password");
                        }*/

                        }

                        @Override
                        public void failure(RetrofitError error) {
                            //If any error occured displaying the error as toast
                            if (mProgressDialog.isShowing())
                                mProgressDialog.dismiss();
                            //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Please check Internet Connection", "");
                        }
                    }
            );


        }

            @Override
            public void onBackPressed() {
                super.onBackPressed();
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }

            private String parseCode(String message) {
                Pattern p = Pattern.compile("\\d{8}");
                Matcher m = p.matcher(message);
                String code = "";
                while (m.find()) {
                    code = m.group(0);
                }
                return code;
            }

}




