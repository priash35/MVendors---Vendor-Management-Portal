package com.abaow.utils;

import java.util.ArrayList;

import retrofit.Callback;
import retrofit.client.Response;
import retrofit.http.Field;
import retrofit.http.FormUrlEncoded;
import retrofit.http.POST;

/**
 * Created by admin on 4/12/2016.
 */
public interface RestInterfac {
    @FormUrlEncoded
    @POST("/users/create_user")
    public void insertUser(
            @Field("name") String firstname,
            @Field("password") String password,
            @Field("mobile") String mobile,
            @Field("email") String email,
            @Field("city") String city,
            @Field("country") String country,
            @Field("language") String language,
            @Field("franchise") String franchise,
            Callback<Response> callback);
    @FormUrlEncoded
    @POST("/users/update_user")
    public void updateuser(
            @Field("id") int id,
            @Field("name") String firstname,
            @Field("password") String password,
            @Field("mobile") String mobile,
            @Field("email") String email,
            @Field("country") String country,
            @Field("city") String city,
            @Field("language") String language,
            Callback<Response> callback);

    @FormUrlEncoded
    @POST("/users/login_user")
    public void getUser(
            @Field("name") String username,
            @Field("password") String password,
            Callback<Response> cb);
//userid=42
   @FormUrlEncoded
    @POST("/users/getblogs")
    public void getBlogs(
            @Field("userid") String username,
            Callback<Response> cb);

    @FormUrlEncoded
    @POST("/users/check_otp")
    public void merchantOTP(
            @Field("mobile") String mobile_no,
            @Field("otp") String otp,
            Callback<Response> cb);


    @FormUrlEncoded
    @POST("/users/reset_password")
    public void resetpwd(
            @Field("mobile") String mobile,

            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/users/resend_pin")
    public void resendOTP(
            @Field("mobile") String mobile,

            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/courses/course_curriculum")
    public void getCourse(
            @Field("id") int courseid,
            @Field("user_id") int userid,
            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/courses/get_quiz")
    public void getquiz(
            @Field("userid") int userid,
            @Field("id") int quizid,
            @Field("courseid") int courseid,
            @Field("moduleid") int moduleid,

            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/courses/update_quiz")
    public void updatequiz(
            @Field("userid") int userid,
            @Field("courseid") int courseid,
            @Field("moduleid") int moduleid,
            @Field("ans[]") ArrayList<String> ans,

            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/users/get_user")
    public void getUserInfo(
            @Field("userid") int userid,
            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/users/get_user_info")
    public void getUserInfoAll(
            @Field("userid") int userid,
            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/users/other_courses")
    public void getOtherCourses(
            @Field("userid") int userid,
            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/courses/course_details")
    public void getCourseDetails(
            @Field("course_id") int userid,
            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/courses/register_course")
    public void registercourse(
            @Field("course_id") int courseid,
            @Field("user_id") int userid,
            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/users/curr_courses")
    public void getCurrCourses(
            @Field("userid") int userid,
            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/courses/update_curr")
    public void updatecrr(
            @Field("moduleid") int moduleid,
            @Field("userid") int userid,
            @Field("courseid") int courseid,
            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/notifications/getnotifications")
    public void getNotification(
            @Field("id") String userid,
            @Field("date_from") String date_time,

            Callback<Response> response);
    @FormUrlEncoded
    @POST("/users/getcountry")
    public void getCountry(
            @Field("id") int userid,
            Callback<Response> response);
    @FormUrlEncoded
    @POST("/users/getcity")
    public void getCity(
            @Field("countryid") String countryid,
             Callback<Response> response);
    @FormUrlEncoded
    @POST("/users/getlanguage")
    public void getLanguages(
            @Field("countryid") String countryid,
            Callback<Response> response);
    @FormUrlEncoded
    @POST("/users/addFeedbackapp")
    public void sendFeedback(
            @Field("userid") String customer_id,
            @Field("message") String message,
            Callback<Response> callback);
    @FormUrlEncoded
    @POST("/users/completedcourses")
    public void getCompCourses(
            @Field("userid") int userid,
            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/orders/create_order")
    public void createorder(
            @Field("user_id") int userid,
            @Field("course_id") int courseid,
            @Field("fee") String fee,
            Callback<Response> cb);
    @FormUrlEncoded
    @POST("/orders/update_status")
    public void updatestatus(
            @Field("order_id") String orderid,
            @Field("status") String status,
            Callback<Response> cb);
 @FormUrlEncoded
 @POST("/paytm/generateChecksum.php")
 public void getCheckSum(
         @Field("MID") String mid,
         @Field("ORDER_ID") String order_id,
         @Field("CUST_ID") String cust_id,
         @Field("CHANNEL_ID") String channel_id,
         @Field("AMOUNT") String amount,
         @Field("WEBSITE") String website,
         @Field("CALLBACK_URL") String url,
         @Field("INDUSTRY_TYPE") String industry,
         //@Field("EMAIL") String email,
         //@Field("MOBILE_NO") String mobile,
         Callback<Response> cb);
 @FormUrlEncoded
 @POST("/paytm/paytmparams.php")
 public void getPaytmparams(
         @Field("key") String key,
         Callback<Response> cb);

}
