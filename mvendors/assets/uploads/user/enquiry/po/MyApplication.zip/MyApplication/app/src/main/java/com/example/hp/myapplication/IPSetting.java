package com.example.hp.myapplication;

public class IPSetting {
    public static String ip="http://192.168.0.8/traffic";
}
