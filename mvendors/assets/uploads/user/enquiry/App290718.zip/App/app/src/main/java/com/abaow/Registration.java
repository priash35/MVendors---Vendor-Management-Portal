package com.abaow;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;

import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.Html;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.support.design.widget.TextInputLayout;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.abaow.Pojo.Country;
import com.abaow.utils.OnSmsCatchListener;
import com.abaow.utils.RestInterfac;
import com.abaow.utils.SmsVerifyCatcher;
import com.abaow.utils.StaticDataMember;
import com.abaow.utils.httpsAdapter;

import com.toptoche.searchablespinnerlibrary.SearchableSpinner;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;



public class Registration extends Activity implements View.OnClickListener {
    private final int SELECT_PHOTO = 1;
    private EditText etFname, etMobile, etEmail, password,confirmEmail;
    private TextView txtSignUp, txtRegistration;
    private String gender = "", user_id, user_name;
    private Button btnSubmit;
    private Pattern pattern;
    private Matcher matcher;
    private RadioButton radioMale, radioFemale;
    private int year;
    private int month;
    private int day;
    private String oldImg;
    private Bitmap selectedImage;
    private ProgressDialog mProgressDialog;
    SharedPreferences sharedpreferences;
    static final int DATE_DIALOG_ID = 999;
    private ImageView imgProfile, datepick;
    private Typeface notoFace, notoFaceBold;

    private String lastName = "";
    private String firstName = "";
    private static final int REQUEST_WRITE_STORAG = 77;
    private static final int REQUEST_READ_STORAG = 55;

    private EditText edAlertInput, edOtpNo;
    private final static String TAG = Registration.class.getSimpleName();
    private SearchableSpinner mCitySpinner, mCountrySpinner;
    private Spinner mLanguageSpinner;
    private List<String> mListLanguage,mListLanguageId;

    private List<String> mListCountry;
    private List<String> mListCountryId;
    private List<Country> mCountry;
    private List<String> mListCity;
    private List<String> mListCityId;
    private String mCityId;
    private String mCountryId,mLanguageId;
    private ArrayAdapter mCountryAdapter;
    private ArrayAdapter<String> mCityAdapter,mLanguageAdapter;
    private String mCityName, mCountryName;
    private TextView tvHintCity, tvHintArea,tvHintLanguage;


    private static final String TAG_SUCCESS = "success";
    private static final String TAG_USER_REGISTER = "registered";
    private static final String TAG_REGISTRATION_CONFIRM = "registration_confirm";
    //This is your KEY and SECRET
    //And it would be added automatically while the configuration
    //private static final String TWITTER_KEY = "THJFyADhqzJrmRthzoEQNcvnE";
    //private static final String TWITTER_SECRET = "bp2Iq5ZNkHJTL46NLDEpyyCpOotQVkVB4mCV9R51jbQvr2hq2W";


    private Button btnFacebook, btnTwitterLogin;


    private String mMobileNo,mFranchise;
    private Boolean isAlert = false;
    SmsVerifyCatcher smsVerifyCatcher;


    /* //for Navigation Drawer

     private DrawerLayout mDrawerLayout;
     private ListView mDrawerList, mDrawerListBottom;
     private ImageView imgDrawer, imgBack;
     private String loginId, loginName;
     private String old_password, new_password;
     StringBuilder strBuilder;
     LinearLayout llBottom;
     private String tabToOpen = "0";
     public static final String MyPREFERENCES = "mypref";
     private String catIdString;
     String name;
 */
    private boolean isEmailValid(String email) {
        //String emailPattern = "[a-zA-Z0-9._-]+@[a-z0-9]+\\.+[a-z]+";
        String emailPattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        if (!email.toString().trim().matches(emailPattern))
            return false;
        else
            return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);

        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
      //  setContentView(R.layout.activity_registration);
        setContentView(R.layout.activity_registration);
        sharedpreferences = getSharedPreferences("mypref", Context.MODE_PRIVATE);

        SharedPreferences prefs = Registration.this.getSharedPreferences("mypref", Registration.this.MODE_PRIVATE);
        //userLoginId = prefs.getString(TAG_LOGIN_ID, null);
        boolean isUserRegistered = prefs.getBoolean(TAG_USER_REGISTER, false);
        boolean isRegisConfirm = prefs.getBoolean(TAG_REGISTRATION_CONFIRM, false);
        mMobileNo = prefs.getString("Mobile", null);
        mFranchise = prefs.getString("Franchise", "None");
        if (isUserRegistered && !isRegisConfirm) {
            inputAlert();
        }

        notoFace = Typeface.createFromAsset(getResources().getAssets(), "NotoSans-Regular.ttf");
        notoFaceBold = Typeface.createFromAsset(getResources().getAssets(), "NotoSans-Bold.ttf");

        etFname =  (EditText) findViewById(R.id.etFname);
        etEmail =  (EditText)findViewById(R.id.etEmail);
        confirmEmail =  (EditText)findViewById(R.id.confirmEmail);
        etMobile =  (EditText)findViewById(R.id.etMobile);
        password =  (EditText)findViewById(R.id.etPwd);

        btnSubmit = (Button) findViewById(R.id.btnSave);
        //edOtpNo = new EditText(Registration.this);

        btnSubmit.setOnClickListener(this);
        /*btnUpdate.setOnClickListener(this);
        btnUpdate.setVisibility(View.GONE);*/
        btnSubmit.setVisibility(View.VISIBLE);


        etMobile.setFocusable(true);
        password.setFocusable(true);

        etFname.setTypeface(notoFace);
        etEmail.setTypeface(notoFace);
        confirmEmail.setTypeface(notoFace);
        etMobile.setTypeface(notoFace);
        password.setTypeface(notoFace);
        btnSubmit.setTypeface(notoFaceBold);
        mCountrySpinner = (SearchableSpinner) findViewById(R.id.spinnerCountry);
        mCountrySpinner.getBackground().setColorFilter(getResources().getColor(R.color.new_dark_grey), PorterDuff.Mode.SRC_ATOP);
        tvHintLanguage = (TextView) findViewById(R.id.tvHintLanguage);
        tvHintLanguage.setTypeface(notoFace);
        mCitySpinner = (SearchableSpinner) findViewById(R.id.spinnerCity);
        mCitySpinner.getBackground().setColorFilter(getResources().getColor(R.color.new_dark_grey), PorterDuff.Mode.SRC_ATOP);
        tvHintArea = (TextView) findViewById(R.id.tvHintSpCountry);
        tvHintCity = (TextView) findViewById(R.id.tvHintSpCity);
        tvHintCity.setTypeface(notoFace);
        tvHintArea.setTypeface(notoFace);
        mListCountry = new ArrayList<String>();
        mListCountryId = new ArrayList<String>();
        mListLanguage = new ArrayList<String>();
        mListLanguageId = new ArrayList<String>();

        mLanguageSpinner = (Spinner)findViewById(R.id.spnLanguage);
        mLanguageSpinner.getBackground().setColorFilter(getResources().getColor(R.color.new_dark_grey), PorterDuff.Mode.SRC_ATOP);
        getAllCountry();
       // btnUpdate.setTypeface(notoFaceBold);

        // String f = getIntent().getExtras().getString("from");
        /*if (getIntent().getExtras().getString("from") != null && !getIntent().getExtras().getString("from").equals("")) {
            if (getIntent().getExtras().getString("from").equals("update")) {
                user_id = getIntent().getExtras().getString("loginId");
                user_name = getIntent().getExtras().getString("loginName");

                btnSubmit.setVisibility(View.VISIBLE);
                btnSubmit.setText("UPDATE");


                etMobile.setFocusable(false);
                password.setFocusable(false);
                GetCurrentCustomerDetails();

            }
        }*/
        smsVerifyCatcher = new SmsVerifyCatcher(this, new OnSmsCatchListener<String>() {
            @Override
            public void onSmsCatch(String message) {
                System.out.println("SMS recieved");
                String code = parseCode(message);//Parse verification code
                edOtpNo.setText(code);//set code in edit text
                //then you can send verification code to server
            }
        });
        smsVerifyCatcher.setPhoneNumberFilter("ABAOWS");
        requestPermissions();
    }

    @Override
    public void onResume(){
        super.onResume();
        sharedpreferences = getSharedPreferences("mypref", Context.MODE_PRIVATE);

        SharedPreferences prefs = Registration.this.getSharedPreferences("mypref", Registration.this.MODE_PRIVATE);
        boolean isRegisConfirm = prefs.getBoolean(TAG_REGISTRATION_CONFIRM,false);
        boolean isUserRegistered = prefs.getBoolean(TAG_USER_REGISTER, false);
        if (isUserRegistered && !isRegisConfirm) {
            inputAlert();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        smsVerifyCatcher.onStop();
    }

    @Override
    protected void onDestroy() {
        
        super.onDestroy();
    }
    @Override
    protected void onStart() {
        super.onStart();
        smsVerifyCatcher.onStart();
    }



    public void showDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx,R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        builder.show();
    }




   

    public String getStringImage(Bitmap bmp) {
        if (bmp == null)
            return "";
        else {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();

            bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] imageBytes = baos.toByteArray();
            String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
            return encodedImage;
        }
    }

   

    private void insertUser() {
        //Here we will handle the http request to insert user to mysql db
        //Creating a RestAdapter
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();
        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);


        //Creating object for our interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.insertUser(

                //Passing the values by getting it from editTexts
                firstName + " "+lastName,
                password.getText().toString(),
                etMobile.getText().toString(),
                etEmail.getText().toString(),
                mCityId,
                mCountryId,
                mLanguageId,
                mFranchise,



                //Creating an anonymous callback
                new Callback<Response>() {

                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String mloginId = "";
                        String mloginName = "";
                        String mMessage = "";
                        //An string to store output from the server
                        String output = "";
                        JSONObject json = null;
                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            //{"id":"44","username":"haha","success":1,"message":"User registered successfully"}
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {
                                System.out.println("JSON Object: " + json);
                                success = json.getInt("success");
                                /*mloginId = json.getString("id");
                                mloginName = json.getString("username");
                                mMessage = json.getString("message");*/
                            }
                            // Toast.makeText(Registration.this, json.getString("meassage"),Toast.LENGTH_LONG).show();
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();

                        if (success == 1) {
                            //cleanView();
                            SharedPreferences.Editor editor = Registration.this.getSharedPreferences("mypref", Registration.this.MODE_PRIVATE).edit();
                            editor.putBoolean(TAG_USER_REGISTER, true);
                            editor.putBoolean(TAG_REGISTRATION_CONFIRM,false);
                            editor.apply();
                            inputAlert();
                            //showSuccessDialog(Registration.this, "success", mMessage, mloginId, mloginName);

                        } else {
                            //   Toast.makeText(Registration.this, "Sorry,User Not Registered successfully",Toast.LENGTH_LONG).show();
                            showDialog(Registration.this, "Registration Failed", "Email_id or Phone number already exist..");
                        }

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        showDialog(Registration.this, "Registration Failed", "Please contact ABAOW.");
                        //If any error occured displaying the error as toast
                        //Toast.makeText(Registration.this, error.toString(),Toast.LENGTH_LONG).show();
                        /*if (isFinishing()) {
                            showDialog(Registration.this, "Please check Internet Connection", "");
                        }*/
                    }
                }
        );
    }



    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnSave:

                //    String lname = etLname.getText().toString();

                String nameTokens[] = etFname.getText().toString().trim().split("\\s");

                if (nameTokens.length > 1) {
                    firstName = nameTokens[0].trim().toString();
                    lastName = nameTokens[1].trim().toString();
                } else {
                    //         name = nameTokens.toString();
                    firstName = etFname.getText().toString().trim();
                    lastName = "";

                }

                String Email = etEmail.getText().toString();
                String cEmail = confirmEmail.getText().toString();
                String Mobile = etMobile.getText().toString();
                mMobileNo=Mobile;

                String pwd = password.getText().toString();


                if (firstName.equals("")) {
                    showDialog(Registration.this, "Empty First Name", "please enter First Name");
                } else if (Email.equals("")) {
                    // Toast.makeText(Registration.this, "please enter Email", Toast.LENGTH_SHORT).show();
                    showDialog(Registration.this, "Empty Email", "please enter Email");
                }else if (cEmail.equals("")) {
                    // Toast.makeText(Registration.this, "please enter Email", Toast.LENGTH_SHORT).show();
                    showDialog(Registration.this, "Empty Confirm Email", "please enter Confirm Email");
                } else if (Mobile.equals("")) {
                    // Toast.makeText(Registration.this, "please enter Mobile", Toast.LENGTH_SHORT).show();
                    showDialog(Registration.this, "Empty Mobile", "please enter Mobile");
                }/* else if (city.equals("")) {
                    // Toast.makeText(Registration.this, "please enter City", Toast.LENGTH_SHORT).show();
                    showDialog(Registration.this, "Empty City", "please enter City");
                }*/ else if (!isEmailValid(Email)) {
                    //  Toast.makeText(Registration.this, "please enter valid email", Toast.LENGTH_SHORT).show();
                    showDialog(Registration.this, "Invalid Email", "please enter valid email");
                }else if (!isEmailValid(cEmail)) {
                    //  Toast.makeText(Registration.this, "please enter valid email", Toast.LENGTH_SHORT).show();
                    showDialog(Registration.this, "Invalid Confirm Email", "please enter valid email");
                } else if (Mobile.length() < 10 || Mobile.length() > 10) {
                    //  Toast.makeText(Registration.this, "Mobile number must have 10 digits", Toast.LENGTH_SHORT).show();
                    showDialog(Registration.this, "Invalid Mobile", "Mobile number must have 10 digits");
                } else if (TextUtils.isEmpty(pwd)) {
                    showDialog(Registration.this, "Empty Password", "please enter password");
                } else if (pwd.length() < 8) {
                    showDialog(Registration.this, "Short Password", "Password characters must be 8+");
                }else if (!cEmail.equals(Email)) {
                    showDialog(Registration.this, "Email Not Match", "Email and Confirm Email does not match");
                } else {
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("Mobile", Mobile);
                    editor.putString("username", null);
                    editor.putString("password", null);

                    editor.apply();
                    insertUser();
                    //setsmscatch();

                }
                break;

            default:
                break;

           /* case R.id.imgDrawer:
                mDrawerLayout.openDrawer(mDrawerList);
                break;*/
        }

    }


    private void cleanView() {
        etFname.setText("");
        etMobile.setText("");
        etEmail.setText("");
        password.setText("");
    }


    /**
     * method is used to create alert dialog
     * for Forgot Password and to Get OTP
     */
    private void inputAlert() {
        if (!isAlert) {

            Typeface noto_reguler = Typeface.createFromAsset(getAssets(), "NotoSans-Regular.ttf");
            Typeface noto_bold = Typeface.createFromAsset(getAssets(), "NotoSans-Bold.ttf");

            Resources resources = getResources();
            ContextThemeWrapper ctw = new ContextThemeWrapper(this, R.style.AlertDialog);
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(ctw,R.style.MyDialogTheme);
            alertDialog.setTitle(getString(R.string.action_merchant_otp_title));
            alertDialog.setMessage(getString(R.string.action_merchant_otp_message));
            LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            params1.setMargins(0, 15, 0, 0);

            LinearLayout linearLayout = new LinearLayout(Registration.this);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            linearLayout.setLayoutParams(params1);

            edAlertInput = new EditText(Registration.this);
            edAlertInput.setTypeface(noto_reguler);
            edOtpNo = new EditText(Registration.this);
            edOtpNo.setTypeface(noto_reguler);


            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);

            TextInputLayout tiInput = new TextInputLayout(Registration.this);


            TextInputLayout tiOTP = new TextInputLayout(Registration.this);
            tiOTP.setHint(getString(R.string.otp_prompt));
            tiOTP.setLayoutParams(lp);

            //edAlertInput.setHint(getString(R.string.prompt_mobile_no));
            edAlertInput.setHintTextColor(resources.getColor(R.color.colorPrimary));
            edAlertInput.setTextColor(resources.getColor(R.color.black));
            edAlertInput.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.astrick_red, 0);
            edAlertInput.setInputType(InputType.TYPE_CLASS_PHONE);
            edAlertInput.setLayoutParams(lp);
            edAlertInput.setText(mMobileNo);
            tiInput.addView(edAlertInput);

            //edOtpNo.setHint(getString(R.string.otp_prompt));
            edOtpNo.setHintTextColor(resources.getColor(R.color.colorPrimary));
            edOtpNo.setTextColor(resources.getColor(R.color.black));
            edOtpNo.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.astrick_red, 0);
            edOtpNo.setInputType(InputType.TYPE_CLASS_NUMBER);
            edOtpNo.setLayoutParams(lp);
            edOtpNo.requestFocus();
            tiOTP.addView(edOtpNo);

            linearLayout.addView(tiInput);
            linearLayout.addView(tiOTP);
            alertDialog.setView(linearLayout);
            alertDialog.setIcon(R.drawable.password);

            alertDialog.setPositiveButton("Ok",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

            alertDialog.setNegativeButton("Cancel",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            isAlert = false;
                            dialog.cancel();
                        }
                    });
            alertDialog.setNeutralButton("Resend Pin",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                   /*         isAlert = false;
                            dialog.cancel();
                            resendOTP(mMobileNo);
             */           }
                    });
            final AlertDialog dialog = alertDialog.create();
            dialog.setCanceledOnTouchOutside(false);
            isAlert = true;

            //alertDialog.setNeutralButton()


           // dialog.getButton()
            dialog.show();
            //alertDialog.show();
            final Button resend = dialog.getButton(DialogInterface.BUTTON_NEUTRAL);
            resend.setClickable(false);

            new CountDownTimer(46000, 1000) { // adjust the milli seconds here

                public void onTick(long millisUntilFinished) {
                    long count=millisUntilFinished/1000;
                    resend.setText(""+count);
                }

                public void onFinish() {
                    resend.setText("Resend");
                    resend.setClickable(true);
                }
            }.start();

        /*    Handler handler = null;
            handler = new Handler();
            handler.postDelayed(new Runnable(){
                public void run(){
                    resend.setClickable(true);
                }
            }, 30000);
*/
            resend.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    isAlert = false;

                    new CountDownTimer(46000, 1000) { // adjust the milli seconds here

                        public void onTick(long millisUntilFinished) {
                            long count=millisUntilFinished/1000;
                            resend.setText(""+count);
                       }

                        public void onFinish() {
                            resend.setText("Resend");
                            resend.setClickable(true);

                        }
                    }.start();
                    //     dialog.cancel();

                    resendOTP(mMobileNo);


           /*         Handler handler = null;
                    handler = new Handler();
                    handler.postDelayed(new Runnable(){
                        public void run(){
                            resend.setClickable(true);

                        }
                    }, 30000);

         */       }
            });

            Button theButton = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
            theButton.setOnClickListener(new CustomListener(dialog));
        }
    }

    /**
     * allow alert dialog visible even if click on
     * positive button
     *
     * @author vaibhav
     */
    class CustomListener implements View.OnClickListener {
        private final Dialog dialog;

        public CustomListener(Dialog dialog) {
            this.dialog = dialog;
        }

        @Override
        public void onClick(View v) {
            String mMailId = edAlertInput.getText().toString().trim();
            String mOTP = edOtpNo.getText().toString().trim();
            if (mMailId.trim().length() == 0) {
                edAlertInput.setError(Html.fromHtml("<font color='red'>Please enter Mobile No!</font>"));

            }/* else if (mobileValidation(mMailId)) {
                edAlertInput.setError(Html.fromHtml("<font color='red'>Please enter valid Mobile No!</font>"));
            }*/ else if (mOTP.trim().length() == 0) {
                edOtpNo.setError(Html.fromHtml("<font color='red'>Please enter OTP!</font>"));

            }  else {
                isAlert = false;
                dialog.dismiss();
                InputMethodManager imm = (InputMethodManager) Registration.this
                        .getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm.isAcceptingText()) {
                    hideSoftKeyboard(Registration.this);
                }
                try {
                   /* ConnectivityManager connectivityManager = (ConnectivityManager) Registration.this.getSystemService(Context.CONNECTIVITY_SERVICE);
                    if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                            connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {*/
                        merchantOTP(mMailId, mOTP);
                    /*} else //No Internet connection
                    {
                        //noDataConnectionAlert();
                        Toast.makeText(Registration.this, "No internet connection", Toast.LENGTH_LONG).show();
                    }*/

                } catch (Exception e) {
                    Log.e(TAG, "connectivity manager " + e.getMessage());
                }


            }

        }
    }


    private void merchantOTP(final String mobile_no, String otp) {
        //Here we will handle the http request to insert user to mysql db
        final ProgressDialog mProgress = new ProgressDialog(Registration.this);
        mProgress.setIndeterminate(true);
        mProgress.setMessage("Loading...");
        mProgress.setCancelable(false);
        mProgress.show();
        //Creating a RestAdapter
        /*RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build();*/ //Finally building the adapter
        final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.merchantOTP(

                //Passing the values by getting it from editTexts
                mobile_no,
                otp,
                //Creating an anonymous callback
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        //On success we will read the server's output using bufferedreader
                        //Creating a bufferedreader object
                        BufferedReader reader = null;
                        JSONObject json = null;
                        //An string to store output from the server
                        String output = "";
                        int success = 0;
                        try {
                            //Initializing buffered reader
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));

                            //Reading the output in the string
                            output = reader.readLine();
                            Log.e(TAG, "Output: " + output);
                            JSONTokener tokener = new JSONTokener(output);
                            try {
                                json = new JSONObject(tokener);
                                if (json != null) {
                                    System.out.println("JSON Object: " + json);
                                    success = json.getInt(TAG_SUCCESS);
                                } else {
                                    Log.e(TAG, "JSONobject is null");
                                }

                            } catch (JSONException e) {
                                Log.e(TAG, "JSONExeption: " + e.getMessage());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        //showDialogProgress(false);

                        if (mProgress.isShowing()) {
                            mProgress.dismiss();
                        }
                        if (success > 0) {
                            cleanView();
                            isAlert = false;
                            SharedPreferences.Editor editor = Registration.this.getSharedPreferences("mypref", Registration.this.MODE_PRIVATE).edit();
                            //editor.putBoolean(TAG_USER_REGISTER, false);
                            editor.putBoolean(TAG_REGISTRATION_CONFIRM, true);
                            editor.apply();
                            inputAlert(getString(R.string.dialog_merchant_success_title), getString(R.string.dialog_merchant_success_body));
                        } else {
                            mMobileNo = mobile_no;
                            inputAlert(getString(R.string.dialog_merchant_failur_title), getString(R.string.dialog_merchant_failur_body));
                        }

                        //Displaying the output as a toast

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //showDialogProgress(false);
                        //If any error occured displaying the error as toast

                        if (mProgress.isShowing()) {
                            mProgress.dismiss();
                        }
                        showDialog(Registration.this, "Network Error", "Problem connecting to internet. Please try again later");
                    }
                }
        );
        //cleanView();
        isAlert = false;
        /*SharedPreferences.Editor editor = Registration.this.getSharedPreferences("mypref", Registration.this.MODE_PRIVATE).edit();
        editor.putBoolean(TAG_USER_REGISTER, false);
        editor.putBoolean(TAG_REGISTRATION_CONFIRM, true);
        editor.apply();*/
        //inputAlert(getString(R.string.dialog_merchant_success_title), getString(R.string.dialog_merchant_success_body));
    }


    /**
     * method is used to create alert dialog
     * for Forgot Password
     */
    private void inputAlert(final String title, final String bodyMsg) {
        Resources resources = getResources();
        ContextThemeWrapper ctw = new ContextThemeWrapper(Registration.this, R.style.AlertDialog);
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(ctw,R.style.MyDialogTheme);
        alertDialog.setTitle(title);
        alertDialog.setMessage(bodyMsg);

        alertDialog.setIcon(android.R.drawable.ic_dialog_alert);

        alertDialog.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        if (bodyMsg.equals(getString(R.string.dialog_merchant_success_body))) {
                            Intent login = new Intent(Registration.this, LoginActivity.class);
                            startActivity(login);
                            Registration.this.finish();
                        } else if (title.equals(getString(R.string.dialog_merchant_failur_title))) {
                            inputAlert();
                        }
                    }
                });

        if (bodyMsg.equals(getString(R.string.dialog_merchant_success_body))) {
            alertDialog.setNegativeButton("Cancel",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
        } else {
            alertDialog.setNegativeButton("Resend OTP",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                            resendOTP(mMobileNo);
                        }
                    });
        }
        //    final AlertDialog dialog = alertDialog.create();
        //    dialog.show();
        alertDialog.show();
    }



    private void resendOTP(final String mobileNo) {
        //Here we will handle the http request to insert user to mysql db
        //Creating a RestAdapter
        final ProgressDialog mProgress = new ProgressDialog(Registration.this);
        mProgress.setIndeterminate(true);
        mProgress.setMessage("Loading...");
        mProgress.setCancelable(false);
        mProgress.show();

        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.resendOTP(

                //Passing the values by getting it from editTexts
                mobileNo,

                //Creating an anonymous callback
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        //On success we will read the server's output using bufferedreader
                        //Creating a bufferedreader object
                        BufferedReader reader = null;
                        JSONObject json = null;
                        //An string to store output from the server
                        String output = "";
                        int success = 0;
                        try {
                            //Initializing buffered reader
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));

                            //Reading the output in the string
                            output = reader.readLine();
                            Log.e(TAG, "Output: " + output);
                            JSONTokener tokener = new JSONTokener(output);
                            try {
                                json = new JSONObject(tokener);
                                if (json != null) {
                                    System.out.println("JSON Object: " + json);
                                    success = json.getInt(TAG_SUCCESS);
                                } else {
                                    Log.e(TAG, "JSONobject is null");
                                }

                            } catch (JSONException e) {
                                Log.e(TAG, "JSONExeption: " + e.getMessage());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        //showDialogProgress(false);

                        if (mProgress.isShowing()) {
                            mProgress.dismiss();
                        }
                        if (success > 0) {
                            //setsmscatch();
                            inputAlert();
                        }

                        //Displaying the output as a toast

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //showDialogProgress(false);
                        //If any error occured displaying the error as toast
                        if (mProgress.isShowing()) {
                            mProgress.dismiss();
                        }
                        showDialog(Registration.this, "Network Error", "Problem connecting to internet. Please try again later");
                    }
                }
        );
    }

    private boolean otpValidation(String otpString) {
        if (otpString.length() == 6) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Method is used to hide keyboard
     *
     * @param activity
     */
    private static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
    }
    private void getAllCountry() {
        //While the app fetched data we are displaying a progress dialog
        //Creating a rest adapter
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url)
                .build();
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating an object of our api interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method
        api.getCountry(
                //Passing the values by getting it from editTexts
                0,
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        //Dismissing the loading progressbar

                        //Calling a method to show the list
                        BufferedReader reader = null;

                        //An string to store output from the server
                        String output = "";
                        JSONObject json = null;
                        int success = 0;
                        try {
                            //Initializing buffered reader
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));

                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);
                            try {
                                json = new JSONObject(tokener);
                                if (json != null) {
                                    mCountry = new ArrayList<Country>();
                                    //mListCity.add(0, "City");
                                    System.out.println("JSON Object: " + json);
                                    success = json.getInt("success");
                                    JSONArray productObj = json.getJSONArray("country"); // JSON Array
                                    if (productObj != null) {
                                        for (int i = 0; i < productObj.length(); i++) {
                                            JSONObject category1 = productObj.getJSONObject(i);//0th element
                                            Country obj1 = new Country();
                                            String cityId = category1.getString("id");
                                            if (cityId != null) {
                                                obj1.setCountryId(Integer.parseInt(cityId));
                                            }
                                            obj1.setCountryName(category1.getString("country_name"));
                                            obj1.setmSlug(category1.getString("country_name"));
                                            mCountry.add(i, obj1);
                                            // mListCity.add(mListCity.size(), category1.getString("name"));
                                        }
                                    }
                                    //

                                } else {
                                    Log.e(TAG, "JSONobject is null");
                                }

                            } catch (JSONException e) {
                                Log.e(TAG, "JSONExeption: " + e.getMessage());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        //if (MyApplication.isActivityVisible()) {
                        if (success == 1) {
                            int countryPos=0,i=0;
                            for (Country city : mCountry) {

                                if( city.getCountryName().equals("India"))
                                    countryPos=i;
                                mListCountry.add(mListCountry.size(), city.getCountryName());
                                mListCountryId.add(mListCountryId.size(), String.valueOf(city.getCountryId()));
                                i++;
                            }

                            mCountryAdapter = new ArrayAdapter(Registration.this, R.layout.new_spinner_item, mListCountry);
                            mCountrySpinner.setAdapter(mCountryAdapter);
                            mCountrySpinner.setSelection(countryPos);
                            mCountrySpinner.setTitle("Select Country");
                            mCountrySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                    mCountryId = String.valueOf(mCountry.get(mCountrySpinner.getSelectedItemPosition()).getCountryId());
                                    mCountryName = mCountry.get(mCountrySpinner.getSelectedItemPosition()).getCountryName();
                                    try {
                                        ConnectivityManager connectivityManager = (ConnectivityManager) Registration.this.getSystemService(Context.CONNECTIVITY_SERVICE);
                                        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
                                            mProgressDialog.show();
                                            getAllCity(mCountryId);

                                        } else //No Internet connection
                                        {
                                            //noDataConnectionAlert();
                                            showDialog(Registration.this, "Network Error", "Problem connecting to internet. Please try again later");
                                            //Toast.makeText(Registration.this, "No internet connection", Toast.LENGTH_SHORT).show();
                                        }

                                    } catch (Exception e) {
                                        Log.e(TAG, "connectivity manager " + e.getMessage());
                                    }

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> adapterView) {

                                }
                            });
                            if (mProgressDialog.isShowing()){
                                mProgressDialog.dismiss();
                            }

                            getAllLanguages();
                        }
                    }

                    //}

                    @Override
                    public void failure(RetrofitError error) {
                        //you can handle the errors here
                        //if (MyApplication.isActivityVisible()) {
                        showDialog(Registration.this, "Network Error", "Problem connecting to internet. Please try again later");
                        //Toast.makeText(Registration.this, "Problem connecting to internet. Please try again", Toast.LENGTH_SHORT).show();
                        //Log.e(TAG, error.toString());
                        //}
                        //Toast.makeText(DiscountMasterActivity.this, "Problem connecting to internet. Please try again", Toast.LENGTH_LONG).show();
                    }
                });
    }
    /**
     * Method to get Citys of selected city
     *
     * @param ids
     */
    private void getAllCity(String ids) {
        //While the app fetched data we are displaying a progress dialog
        //Creating a rest adapter
        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url)
                .build();
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating an object of our api interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method
        api.getCity(
                //Passing the values by getting it from editTexts
                ids,

                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        //Dismissing the loading progressbar

                        //Calling a method to show the list
                        BufferedReader reader = null;

                        //An string to store output from the server
                        String output = "";
                        JSONObject json = null;
                        int success = 0,cityPos=0;
                        try {
                            //Initializing buffered reader
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));

                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);
                            try {
                                mListCity = new ArrayList<String>();
                                mListCityId = new ArrayList<String>();
                                json = new JSONObject(tokener);
                                if (json != null) {
                                    System.out.println("JSON Object: " + json);
                                    success = json.getInt("success");
                                    JSONArray productObj = json.getJSONArray("city"); // JSON Array
                                    if (productObj != null) {
                                        for (int i = 0; i < productObj.length(); i++) {
                                            //JSONObject CityData = productObj.getJSONObject(0);//0th element
                                            //System.out.println("JSON CityData: " + json);
                                            //JSONArray arry = CityData.getJSONArray(mListCountryId.get(mCountrySpinner.getSelectedItemPosition()));
                                            //int size = arry.length();
                                            //for (int j = 0; j < size; j++) {
                                            // City CityObj = new City();
                                            JSONObject CityData1 = productObj.getJSONObject(i);//0th element
                                            mListCity.add(mListCity.size(), CityData1.getString("city_name"));
                                            mListCityId.add(mListCityId.size(), CityData1.getString("id"));
                                            if(CityData1.getString("city_name").equals("Pune"))
                                                cityPos=i;
                                            //}

                                        }
                                    }
                                    //

                                } else {
                                    Log.e(TAG, "JSONobject is null");
                                }

                            } catch (JSONException e) {
                                Log.e(TAG, "JSONExeption: " + e.getMessage());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        //                       if (MyApplication.isActivityVisible()) {
                        if (success == 1) {
                            if (mProgressDialog.isShowing()) {
                                mProgressDialog.dismiss();
                            }

                            mCityAdapter = new ArrayAdapter<String>(Registration.this, R.layout.new_spinner_item, mListCity);
                            mCitySpinner.setAdapter(mCityAdapter);
                            mCitySpinner.setSelection(cityPos);
                            mCitySpinner.setTitle("Select City");
                            /*if (!mListCityId.isEmpty() && !TextUtils.isEmpty(mCityId)) {
                                int index = mListCityId.indexOf(mCityId);
                                mCityName = mListCity.get(index);
                                mCitySpinner.setSelection(index);
                            }*/
                            mCitySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                    int position = mCitySpinner.getSelectedItemPosition();
                                    mCityName = mListCity.get(mCitySpinner.getSelectedItemPosition());
                                    mCityId = mListCityId.get(mCitySpinner.getSelectedItemPosition());
                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> adapterView) {

                                }
                            });
                        } else {
                            if (mProgressDialog.isShowing())
                                mProgressDialog.dismiss();
                            showDialog(Registration.this, "No City", "No City found. Please try again later");
                            //Toast.makeText(Registration.this, "No Citys", Toast.LENGTH_LONG).show();
                        }
                        // }

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //you can handle the errors here
                        //if (MyApplication.isActivityVisible()) {
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        showDialog(Registration.this, "Network Error", "Problem connecting to internet. Please try again later");
                        //Toast.makeText(Registration.this, "Problem connecting to internet. Please try again", Toast.LENGTH_SHORT).show();
                        //Log.e(TAG, error.toString());
                        //}
                        //Toast.makeText(DiscountMasterActivity.this, "Problem connecting to internet. Please try again", Toast.LENGTH_LONG).show();
                    }
                });
    }
    private void getAllLanguages() {
        //While the app fetched data we are displaying a progress dialog
        //Creating a rest adapter
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url)
                .build();
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating an object of our api interface
        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method
        api.getLanguages(
                //Passing the values by getting it from editTexts
                "none",
                new Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        //Dismissing the loading progressbar

                        //Calling a method to show the list
                        BufferedReader reader = null;

                        //An string to store output from the server
                        String output = "";
                        JSONObject json = null;
                        int success = 0;
                        try {
                            //Initializing buffered reader
                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));

                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);
                            try {
                                json = new JSONObject(tokener);
                                if (json != null) {

                                    //mListCity.add(0, "City");
                                    System.out.println("JSON Object: " + json);
                                    success = json.getInt("success");
                                    JSONArray productObj = json.getJSONArray("language"); // JSON Array
                                    if (productObj != null) {
                                        for (int i = 0; i < productObj.length(); i++) {
                                            JSONObject category1 = productObj.getJSONObject(i);//0th element

                                            mListLanguageId.add(category1.getString("id"));

                                            mListLanguage.add(category1.getString("language"));
                                            // mListCity.add(mListCity.size(), category1.getString("name"));
                                        }
                                    }
                                    //

                                } else {
                                    Log.e(TAG, "JSONobject is null");
                                }

                            } catch (JSONException e) {
                                Log.e(TAG, "JSONExeption: " + e.getMessage());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        //if (MyApplication.isActivityVisible()) {
                        if (success == 1) {

                            mLanguageAdapter = new ArrayAdapter(Registration.this, R.layout.new_spinner_item, mListLanguage);
                            mLanguageSpinner.setAdapter(mLanguageAdapter);

                            mLanguageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                    mLanguageId = mListLanguageId.get(i);
                                    //mCountryName = mCountry.get(mCountrySpinner.getSelectedItemPosition()).getCountryName();


                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> adapterView) {

                                }
                            });
                            if (mProgressDialog.isShowing()){
                                mProgressDialog.dismiss();
                            }


                        }
                    }

                    //}

                    @Override
                    public void failure(RetrofitError error) {
                        //you can handle the errors here
                        //if (MyApplication.isActivityVisible()) {
                        showDialog(Registration.this, "Network Error", "Problem connecting to internet. Please try again later");
                        //Toast.makeText(Registration.this, "Problem connecting to internet. Please try again", Toast.LENGTH_SHORT).show();
                        //Log.e(TAG, error.toString());
                        //}
                        //Toast.makeText(DiscountMasterActivity.this, "Problem connecting to internet. Please try again", Toast.LENGTH_LONG).show();
                    }
                });
    }
    @Override
    public void onBackPressed() {

        if (mProgressDialog.isShowing())
            mProgressDialog.dismiss();
        super.onBackPressed();
    }
    private String parseCode(String message) {
        Pattern p = Pattern.compile("\\d{6}");
        Matcher m = p.matcher(message);
        String code = "";
        while (m.find()) {
            code = m.group(0);
        }
        return code;
    }
    public void requestPermissions() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_READ_STORAG);
        } else {
        }

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_STORAG);
        } else {
        }
        int GET_MY_PERMISSION = 1;
        if(ContextCompat.checkSelfPermission(Registration.this, Manifest.permission.READ_SMS)
                != PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(Registration.this,
                    Manifest.permission.READ_SMS)){
            /* do nothing*/
            }
            else{

                ActivityCompat.requestPermissions(Registration.this,
                        new String[]{Manifest.permission.READ_SMS},GET_MY_PERMISSION);
            }
        }



    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_READ_STORAG) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                smsVerifyCatcher.onRequestPermissionsResult(requestCode, permissions, grantResults);
            } else {
                Toast.makeText(this, "Please grant read storage permission to read data from SD Card", Toast.LENGTH_SHORT).show();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        }

       /* if (requestCode == REQUEST_WRITE_STORAG) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            } else {
                Toast.makeText(this, "Please grant write storage permission to write data into SD Card", Toast.LENGTH_SHORT).show();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }*/
    }





}
