package com.abaow.Adapters;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.abaow.MainActivity;
import com.abaow.Pojo.Curriculum;
import com.abaow.R;
import com.abaow.ViewCourseActivity;
import com.abaow.utils.RestInterfac;
import com.abaow.utils.StaticDataMember;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by admin on 8/24/2016.
 */
public class CurriculumAdapter extends RecyclerView
        .Adapter<CurriculumAdapter
        .DataObjectHolder> {

    //private static final String TAG = CustomAdapter.class.getSimpleName();
    private String coupon_id, customer_id, return_to_id;

    private ArrayList<Curriculum> listArray = new ArrayList<>();
    private ArrayList<String> listquestions = new ArrayList<>();
    Typeface notoFace, notoFaceBold;

    SharedPreferences sharedpreferences;
    ViewGroup par;
    private int screenWidth;
    private ProgressDialog mProgressDialog;
    private ListView myNames;
    private QuizAdapter adapter;
    private Dialog dialog;
    Button submit,cancel;
    int userid;
    int max;
    int clickposition = -1;
    Curriculum curriculum;
    String coursename;
    Boolean lastmodule = false;
    Context context;
    FragmentManager fragmentManager;


    public CurriculumAdapter(Context context) {
        this.context = context;
    }

    public CurriculumAdapter(ArrayList<Curriculum> list,int max,Context context) {
        listArray.addAll(list);
        this.context = context;
        this.max = max;

    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.curriculum, parent, false);
        par = parent;
        sharedpreferences = parent.getContext().getSharedPreferences("mypref", Context.MODE_PRIVATE);
        userid = sharedpreferences.getInt("loggedin_user_id", 0);
        coursename = sharedpreferences.getString("coursename", "");

        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        notoFace = Typeface.createFromAsset(parent.getContext().getAssets(), "NotoSans-Regular.ttf");
        notoFaceBold = Typeface.createFromAsset(parent.getContext().getAssets(), "NotoSans-Bold.ttf");

        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(CurriculumAdapter.DataObjectHolder holder, int position) {

        //   holder.cpvalue.setText("Rs." + listArray.get(position).getCpValue() + " OFF");
        holder.tvcount.setText(String.valueOf(position+1)+".");
        holder.tvmodulename.setText(UppercaseFirstLetters(listArray.get(position).getModulename()));
        holder.tvdesc.setText(UppercaseFirstLetters(listArray.get(position).getDescription()));
        holder.tvduration.setText("Duration: "+listArray.get(position).getDuration()+" mins.");
//        holder.txtdistance.setText(listArray.get(position).getDistancemeters());


        holder.tvcount.setTypeface(notoFaceBold);
        holder.tvmodulename.setTypeface(notoFaceBold);
        holder.tvdesc.setTypeface(notoFace);
        holder.tvduration.setTypeface(notoFace);
        //if (((listArray.get(position).getStatus().equals("ACTIVE") || listArray.get(position).getStatus().equals("DONE")))&&(position == clickposition)) {
        if (position == clickposition) {
            holder.llayout.setBackground(context.getResources().getDrawable(R.drawable.bg_layout_newblue));
            holder.tvcount.setTextColor(context.getResources().getColor(R.color.white));
            holder.tvmodulename.setTextColor(context.getResources().getColor(R.color.white));
            holder.tvdesc.setTextColor(context.getResources().getColor(R.color.white));
            holder.tvduration.setTextColor(context.getResources().getColor(R.color.white));
            holder.llcardview.setVisibility(View.VISIBLE);
            ((ViewCourseActivity) context).mRecyclerView.scrollToPosition(holder.getAdapterPosition());
        }else{
            if(listArray.get(position).getStatus().equals("ACTIVE")){
                holder.llayout.setBackground(context.getResources().getDrawable(R.drawable.bg_layout_newgreen));
                holder.tvcount.setTextColor(context.getResources().getColor(R.color.white));
                holder.tvmodulename.setTextColor(context.getResources().getColor(R.color.white));
                holder.tvdesc.setTextColor(context.getResources().getColor(R.color.white));
                holder.tvduration.setTextColor(context.getResources().getColor(R.color.white));
                holder.llcardview.setVisibility(View.VISIBLE);


            }else {
                if(listArray.get(position).getStatus().equals("DONE")) {
                    holder.llayout.setBackground(context.getResources().getDrawable(R.drawable.border_pending));

                    holder.tvcount.setTextColor(context.getResources().getColor(R.color.blue));
                    holder.tvmodulename.setTextColor(context.getResources().getColor(R.color.blue));
                    holder.tvdesc.setTextColor(context.getResources().getColor(R.color.new_dark_grey));
                    holder.tvduration.setTextColor(context.getResources().getColor(R.color.blue));
                    holder.llcardview.setVisibility(View.VISIBLE);

                }else {
                    holder.llcardview.setVisibility(View.GONE);
                    //holder.llcardview.removeViewAt(holder.getAdapterPosition());
                }
            }
        }


    }

    @Override
    public int getItemCount() {
        return listArray.size();
    }

    public class DataObjectHolder extends RecyclerView.ViewHolder
            implements View
            .OnClickListener {

        TextView tvcount,tvmodulename,tvdesc,tvduration;
        ImageView imCourse;
        CardView llcardview;
        LinearLayout llayout;


        public DataObjectHolder(View itemView) {
            super(itemView);
            // cpvalue = (TextView) itemView.findViewById(R.id.tvcpValue);
            tvcount = (TextView) itemView.findViewById(R.id.count);
            tvmodulename = (TextView) itemView.findViewById(R.id.tvmodulename);
            tvdesc = (TextView) itemView.findViewById(R.id.tvmoddesc);
            tvduration = (TextView) itemView.findViewById(R.id.tvduration);
            llcardview = (CardView) itemView.findViewById(R.id.curr_view);
            llayout = (LinearLayout) itemView.findViewById(R.id.cur_layout);

            dialog = new Dialog(context);
            dialog.setContentView(R.layout.custom_dialogue);
            submit = (Button) dialog.findViewById(R.id.btnSubmit);
            submit.setOnClickListener(this);
            cancel = (Button) dialog.findViewById(R.id.btnCancel);
            cancel.setOnClickListener(this);


            //onclick listener
            llcardview.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {

            switch (v.getId()) {

                case R.id.curr_view:
                    clickposition = getAdapterPosition();
                    curriculum = listArray.get(getAdapterPosition());
                    /*if (getAdapterPosition()==max-1){
                        lastmodule = true;
                    } else{
                        lastmodule = false;
                    }*/
                    // Toast.makeText(context, "btnRatingsClicked..", Toast.LENGTH_SHORT).show();
                    //llayout = (LinearLayout) itemView.findViewById(R.id.cur_layout);

                   if (curriculum.getStatus().equals("ACTIVE") || curriculum.getStatus().equals("DONE")) {
                       //llayout.setBackground(context.getResources().getDrawable(R.drawable.bg_layout_red));
                       if (curriculum.getQuiz() != 0) {
                           ((ViewCourseActivity) context).StopAudio();
                           quizquestion(userid,curriculum.getQuiz(),curriculum.getCourseid(),curriculum.getModuleid());

                       } else {
                           //((ViewCourseActivity)context).initializeMediaContents();
                           ((ViewCourseActivity) context).PlayMusic(curriculum.getAudio(),curriculum);
                           /*curriculum.updatestatus(curriculum.getModuleid(),userid,curriculum.getCourseid());
                           Intent intent = new Intent(context, ViewCourseActivity.class);
                           intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                           intent.putExtra("courseid", curriculum.getCourseid());
                           context.startActivity(intent);
                           ((Activity)context).finish();*/
                       }
                       notifyDataSetChanged();
                   }

                    break;
                case R.id.btnSubmit:
                    if (validatequiz())
                        updatequiz(dialog,curriculum);

                    break;
                case R.id.btnCancel:
                    dialog.dismiss();
                    break;


            }

        }
    }



    public static String UppercaseFirstLetters(String str) {
        boolean prevWasWhiteSp = true;
        char[] chars = str.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if (Character.isLetter(chars[i])) {
                if (prevWasWhiteSp) {
                    chars[i] = Character.toUpperCase(chars[i]);
                }
                prevWasWhiteSp = false;
            } else {
                prevWasWhiteSp = Character.isWhitespace(chars[i]);
            }
        }
        return new String(chars);
    }

    public void quizquestion(int userid,int quiz_id,int courseid,int moduleid){


        mProgressDialog = new ProgressDialog(context);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);
        //Creating a RestAdapter
        RestAdapter adapter1 = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter1.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.getquiz(
                userid,
                quiz_id,
                courseid,
                moduleid,
                //Passing the values by getting it from editTexts


                //Creating an anonymous callback
                new retrofit.Callback<Response>() {


                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;
                        JSONArray quiz = null;
                        JSONArray answer = null;
                        listquestions.clear();


                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            Log.v("Curr Output: ",output.toString());
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {


                                success = json.getInt("success");
                                quiz = json.getJSONArray("quiz");
                                if (json.has("answers")){
                                answer = json.getJSONArray("answers");}



                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                        // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}

                        if (success == 1) {
                            try {
                                for(int i=0;i<quiz.length();i++) {
                                    JSONObject jsoner = quiz.getJSONObject(i);
                                    String question = jsoner.getString("question");
                                    if (answer != null) {
                                        JSONObject jsoner1 = answer.getJSONObject(i);
                                        question += "," + jsoner1.getString("answer");

                                    }

                                    listquestions.add(question);

                                }


                                dialog.setTitle("Quiz");

                                myNames= (ListView) dialog.findViewById(R.id.List);

                                adapter = new QuizAdapter(context,R.layout.names_view,listquestions );
                                myNames.setAdapter(adapter);
                                dialog.show();

                            }
                            catch(Exception e){
                                Log.e("json error: ",e.toString());
                            }

                        } else {
                            listquestions.add("No questions");
                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(context, "Invalid Credentials", "Please enter valid email or Password");

                        }
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();


                         /*else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Invalid Credentials", "please enter valid Email_Id and Password");
                        }*/

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        listquestions.add("No questions");
                        //If any error occured displaying the error as toast
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(context, "Network Error", "Problem connecting to internet. Please try again later");

                    }
                }

        );




    }
    public void showDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx,R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        builder.show();
    }
    public void updatequiz(final Dialog dialog, Curriculum curr){


        mProgressDialog = new ProgressDialog(context);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();
        ArrayList<String> ansList = new ArrayList<String>();
        int itemsCount = myNames.getChildCount();
        for (int i = 0; i < itemsCount; i++) {
            View view = myNames.getChildAt(i);

            String answer = ((TextView) view.findViewById(R.id.edtext)).getText().toString();
            ansList.add(i,answer);
        }


        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);


        //Creating a RestAdapter
        RestAdapter adapter1 = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter1.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.updatequiz(
                userid,
                curr.getCourseid(),
                curr.getModuleid(),
                ansList,
                //Passing the values by getting it from editTexts


                //Creating an anonymous callback
                new retrofit.Callback<Response>() {


                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;


                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {


                                success = json.getInt("success");
                                String xx = json.getString("message");


                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                        // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}

                        if (success == 1) {
                            dialog.dismiss();
                            showSuccessDialog(context,"Success","Quiz Saved Successfully");


                        } else {

                        }
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();


                         /*else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Invalid Credentials", "please enter valid Email_Id and Password");
                        }*/

                    }

                    @Override
                    public void failure(RetrofitError error) {

                        //If any error occured displaying the error as toast
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(context, "Network Error", "Problem connecting to internet. Please try again later");

                    }
                }

        );




    }
    public void showSuccessDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx,R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                updatestatus(curriculum.getModuleid(),userid,curriculum.getCourseid());
            }
        });

        builder.show();
    }
    public void updatestatus(final int mmoduleid, int userid, final int courseid){
       // boolean successstat;



        RestAdapter adapter1 = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter

        RestInterfac api = adapter1.create(RestInterfac.class);


        api.updatecrr(
                mmoduleid,
                userid,
                courseid,

                new retrofit.Callback<Response>() {


                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;
                        JSONArray usercourse = null;
                        String[] curriculum;

                        try {
                            //Initializing buffered reader

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);

                            json = new JSONObject(tokener);
                            if (json != null) {


                                success = json.getInt("success");
                                int lastmo = json.getInt("last_module");
                                if (lastmo == mmoduleid){
                                    lastmodule = true;
                                }else{
                                    lastmodule = false;
                                }



                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                        // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}

                        if (success == 1) {
                            if (!lastmodule) {
                                Intent intent = new Intent(context, ViewCourseActivity.class);
                                //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                intent.putExtra("courseid", courseid);
                                intent.putExtra("coursename", coursename);
                                intent.putExtra("max", max);
                                context.startActivity(intent);
                                ((Activity) context).finish();
                            }else{
                                lastmodule = false;
                                ((ViewCourseActivity) context).coursefinish();

                            }
                        } else {


                        }

                         /*else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Invalid Credentials", "please enter valid Email_Id and Password");
                        }*/

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        Log.e("Update Status Error: ",error.toString());
                        showDialog(context, "Network Error", "Problem connecting to internet. Please try again later");
                        //If any error occured displaying the error as toast

                    }
                }
        );
        //return successstat;
    }
    public boolean validatequiz() {
        boolean valid = true;
        int itemsCount = myNames.getChildCount();
        for (int i = 0; i < itemsCount; i++) {
            View view = myNames.getChildAt(i);
            EditText reply = (EditText) view.findViewById(R.id.edtext);
            String answer = reply.getText().toString();
            if (answer.isEmpty()) {
                valid = false;
                reply.requestFocus();
                reply.setError("Please enter your answer");
            }
        }
        return valid;
    }
    /*public void coursefinish() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(context,R.style.MyDialogTheme);
        String title = "Congratulations!";
        if (title != null) builder.setTitle(title);

        builder.setMessage("You have successfully completed the course. This course is now available to you in the Completed Courses menu");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                Intent intent = new Intent(context, MainActivity.class);
                //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                ((Activity)context).finish();

            }
        });

        builder.show();
    }*/

}