package com.abaow.Pojo;

/**
 * Created by admin on 4/20/2016.
 */
public class Course {


    private int courseid;
    private String coursename;
    private String coursedesc;
    private String instructor;
    private String audio;
    private String totalmodules;
    private String currentmodule;
    private String startdate;
    private String status;
    private String image;
    private String fee;
    private String language;
    private String max;


    private String comp;

    public String getMax() {
        return max;
    }

    public void setMax(String max) {
        this.max = max;
    }

    public Course(int mcourseid, String mcoursename, String mcoursedesc, String minstructor, String maudio, String mtotalmodules, String mcurrentmodule, String mstartdate,
                  String mstatus, String mimage, String mfee, String mlanguage, String mMax, String mComp) {
        this.courseid = mcourseid;
        this.coursename = mcoursename;
        this.coursedesc = mcoursedesc;
        this.instructor = minstructor;
        this.audio = maudio;
        this.totalmodules = mtotalmodules;
        this.currentmodule = mcurrentmodule;
        this.startdate = mstartdate;
        this.status = mstatus;
        this.image = mimage;
        this.fee = mfee;
        this.language = mlanguage;
        this.max = mMax;
        this.comp = mComp;

    }
    public int getCourseid() {
        return courseid;
    }

    public void setCourseid(int courseid) {
        this.courseid = courseid;
    }

    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }
    public String getCoursedesc() {
        return coursedesc;
    }

    public void setCoursedesc(String coursedesc) {
        this.coursedesc = coursedesc;
    }

    public String getInstructor() {
        return instructor;
    }

    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    public String getAudio() {
        return audio;
    }

    public void setAudio(String audio) {
        this.audio = audio;
    }

    public String getTotalmodules() {
        return totalmodules;
    }

    public void setTotalmodules(String totalmodules) {
        this.totalmodules = totalmodules;
    }

    public String getCurrentmodule() {
        return currentmodule;
    }

    public void setCurrentmodule(String currentmodule) {
        this.currentmodule = currentmodule;
    }

    public String getStartdate() {
        return startdate;
    }

    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getFee() {
        return fee;
    }

    public void setFee(String fee) {
        this.fee = fee;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getComp() {
        return comp;
    }

    public void setComp(String comp) {
        this.comp = comp;
    }



}
