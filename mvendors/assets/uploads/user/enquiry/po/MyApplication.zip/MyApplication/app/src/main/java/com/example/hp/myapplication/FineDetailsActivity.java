package com.example.hp.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class FineDetailsActivity extends AppCompatActivity {

    EditText edtOverSpeed,edtRice,edtSignal,edtnolicense,edtTotal;
    String billdetails="";
    Button btnUpdateDetails;
    String id="";
    String name="";
    String no="";
    String address="";
    String contact="";
    String fine="";
    String pn="";
    String total="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fine_details);
        edtOverSpeed=findViewById(R.id.txtOverSpeed);
        edtRice=findViewById(R.id.txtRash);
        edtSignal=findViewById(R.id.txtSignal);
        edtnolicense=findViewById(R.id.textVNoValue);
        edtTotal=findViewById(R.id.txtTotal);
        billdetails="Over Speed -"+edtOverSpeed.getText().toString()+",Rash Driving -"+edtRice.getText().toString()+",No Licence-"+edtnolicense.getText().toString()+",Signal Break-"+edtSignal.getText().toString();

        btnUpdateDetails = findViewById(R.id.btnstore);
        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        name = intent.getStringExtra("name");
        no=intent.getStringExtra("no");
        address=intent.getStringExtra("add");
        contact=intent.getStringExtra("cont");
        fine=intent.getStringExtra("fine");
        pn=intent.getStringExtra("pn");




        btnUpdateDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(FineDetailsActivity.this, UpdatePaymentDetails.class);
                intent.putExtra("names",name);
                intent.putExtra("nos",no);
                intent.putExtra("adds",address);
                intent.putExtra("conts",contact);
                intent.putExtra("fines",edtTotal.getText().toString());
                intent.putExtra("pns",pn);
                intent.putExtra("ids",id);
                intent.putExtra("bills",billdetails);
                startActivity(intent);
            }
        });

    }
}
