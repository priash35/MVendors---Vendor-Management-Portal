package com.example.hp.myapplication;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SearchRecordActivity extends AppCompatActivity {

    Button btnSearchRecords;
    EditText vehicle_no;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_record);
        vehicle_no=(EditText) findViewById(R.id.editVehicleNo);
        btnSearchRecords=(Button) findViewById(R.id.btnSearchRecords);
        db=openOrCreateDatabase("traffic", Context.MODE_PRIVATE, null);
        btnSearchRecords.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(vehicle_no.getText().toString().trim().length()==0)
                {
                    Toast.makeText(SearchRecordActivity.this,"Please Enter Vehicle Number..." ,Toast.LENGTH_SHORT ).show();
                    return;
                }
                else {
                    Intent i = new Intent(SearchRecordActivity.this, DetailsActivity.class);
                    i.putExtra("vehicle_no", vehicle_no.getText().toString());
                    startActivity(i);
                }
            }
        });
    }
}
