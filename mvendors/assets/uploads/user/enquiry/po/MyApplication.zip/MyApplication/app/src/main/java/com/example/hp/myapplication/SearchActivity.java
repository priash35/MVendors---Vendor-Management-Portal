package com.example.hp.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class SearchActivity extends AppCompatActivity {


    SQLiteDatabase db;
    TextView txtName,txtNo,txtAdd,txtContact,txtFine,txtPN;
    EditText edtTxt;
    Button button;
    LinearLayout linearLayout;
    Button btnFineDetiale,btnPaymentDetail;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lay_search);
        linearLayout=findViewById(R.id.lineardata);
        edtTxt=findViewById(R.id.edtSearch);
        button=findViewById(R.id.btnSearch);
        btnFineDetiale=findViewById(R.id.fineDetails);
        btnPaymentDetail=findViewById(R.id.paymentDetails);
        txtName=findViewById(R.id.name);
        txtNo=findViewById(R.id.vehicalno);
        txtAdd=findViewById(R.id.address);
        txtContact=findViewById(R.id.contact);
        txtFine=findViewById(R.id.fine);
        txtPN=findViewById(R.id.paidornot);




        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseHelper helper = new DatabaseHelper(SearchActivity.this);
                db = helper.getWritableDatabase();

                String sql = "SELECT * FROM " + "vehicle_table" + " WHERE " + "vehicle_no" + " LIKE '%" + edtTxt.getText().toString() + "%'";
                Cursor cursor = db.rawQuery(sql, null);

                if(cursor.getCount() > 0){
                    // means search has returned data

                    if (cursor.moveToFirst()) {
                        do {
                            linearLayout.setVisibility(View.VISIBLE);
                            final String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_3));
                            final String no=cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_2));
                            final String address=cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_4));
                            final String contact=cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_5));
                            final String fine=cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_6));
                            final String pn=cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_7));
                            final String id=cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_1));
                            // String word = cursor.getString(cursor.getColumnIndex(DbConstants.WORD));
                            //  String meaning = cursor.getString(cursor.getColumnIndex(DbConstants.MEANING));
                            // String category = cursor.getString(cursor.getColumnIndex(DbConstants.CATEGORY));

                            txtName.setText(name);
                            txtNo.setText(no);
                            txtAdd.setText(address);
                            txtContact.setText(contact);
                            txtFine.setText(fine);
                            txtPN.setText(pn);

                            btnPaymentDetail.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent=new Intent(SearchActivity.this,FineDetailsActivity.class);
                                    intent.putExtra("name",name);
                                    intent.putExtra("no",no);
                                    intent.putExtra("add",address);
                                    intent.putExtra("cont",contact);
                                    intent.putExtra("fine",fine);
                                    intent.putExtra("pn",pn);
                                    intent.putExtra("id",id);
                                    startActivity(intent);
                                    finish();


                                }
                            });
                            // display your search result here in RecyclerView or in any manner
                        } while (cursor.moveToNext());
                    }

                } else {
                    linearLayout.setVisibility(View.GONE);
                    Toast.makeText(SearchActivity.this, "No data was found in the system!", Toast.LENGTH_LONG).show();
                }
                cursor.close();
            }
        });




    }
}
