package com.example.hp.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DetailsFine extends AppCompatActivity {
    EditText name,no,address,fine,contat;
    DatabaseHelper helpher;
    List<DatabaseModel> dbList;
    int position;
    Button mBtnupdate;
    RadioGroup payment_mode;
    RadioButton paid, not_paid, radioButton;
    String mode;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState );
        setContentView(R.layout.lay_details);
        name=findViewById(R.id.textDriverNameValue);
        contat=findViewById(R.id.textMobileNumberValue);
        no=findViewById(R.id.textVNoValue);
        address=findViewById(R.id.addresssss);
        fine=findViewById(R.id.textFineValue);
        mBtnupdate=findViewById(R.id.btnUpdate);
        paid = (RadioButton)findViewById(R.id.paid);
        not_paid = (RadioButton)findViewById(R.id.not_paid);
        RadioGroup rg = (RadioGroup) findViewById(R.id.payment_mode);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch(checkedId){
                    case R.id.paid:
                        mode="Paid";
                        // do operations specific to this selection
                        break;
                    case R.id.not_paid:
                        mode="Not Paid";
                        // do operations specific to this selection
                        break;

                }
            }
        });



        final Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        // 5. get status value from bundle
        position = bundle.getInt("position");
        helpher = new DatabaseHelper(this);
        dbList= new ArrayList<DatabaseModel>();
        dbList = helpher.getDataFromDB();


        if(dbList.size()>0){
            String names= dbList.get(position).getDriver_name();
            String nooo=dbList.get(position).getVehicle_no();
            String mobile=dbList.get(position).getContact();
            String addressss=dbList.get(position).getAddress();
            String fineqqq=dbList.get(position).getFine();
            name.setText(names);
            no.setText(nooo);
            contat.setText(mobile);
            address.setText(addressss);
            fine.setText(fineqqq);

        }

        Toast.makeText(DetailsFine.this, dbList.toString(), Toast.LENGTH_LONG);
        mBtnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isUpdate = helpher.updateData(dbList.get(position).getID(),no.getText().toString(),name.getText().toString(),address.getText().toString(),contat.getText().toString(),fine.getText().toString(),mode.toString(),""
                        );
                if(isUpdate == true) {
                    Toast.makeText(DetailsFine.this, "Data Update", Toast.LENGTH_LONG).show();
                    Intent intent1 = new Intent(DetailsFine.this, SelectChoiceActivity.class);
                    startActivity(intent1);
                    finish();
                }
                else
                    Toast.makeText(DetailsFine.this,"Data not Updated",Toast.LENGTH_LONG).show();
            }
        });
    }
}
