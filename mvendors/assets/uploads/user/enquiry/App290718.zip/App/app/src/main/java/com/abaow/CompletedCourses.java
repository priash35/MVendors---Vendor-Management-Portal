package com.abaow;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.abaow.Adapters.CompletedCourseAdapter;
import com.abaow.LocalDB.MerchantNotificationService;
import com.abaow.Pojo.Course;
import com.abaow.utils.Drawer;
import com.abaow.utils.RestInterfac;
import com.abaow.utils.StaticDataMember;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class CompletedCourses extends AppCompatActivity implements View.OnClickListener {

    private CardView llcurrentcourse;
    private LinearLayout llothercourse;
    private static final int READ_INTERNET_PERMISSIONS_REQUEST = 333;
    private TextView tvNotificationCount;
    SharedPreferences sharedpreferences;
    private RecyclerView.Adapter    customadapter,customadapterother;
    private RecyclerView mRecyclerView,mRecyclerView1;
    private String  coursejson = "",name = "Test";
    private JSONArray coursejsonObj,othercourse;
    private Course course = null;
    private ArrayList<Course> listArray = new ArrayList<>();
    private ArrayList<Course> listArray1 = new ArrayList<>();
    private int userid;

    public static final String MyPREFERENCES = "mypref";

    private DrawerLayout mDrawerLayout;
    private ImageView imgDrawer;
    private Drawer dr;

    ProgressDialog mProgressDialog;
    int countNotification;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_completed_courses);
        /*try {
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                    connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
                //your retrofit call

            } else {

            }
        } catch (Exception e) {
            Log.e(this.getClass().getName(), "connectivity manager " + e.getMessage());
        }*/

        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
         countNotification= sharedpreferences.getInt("notificationCount", 0);
        userid = sharedpreferences.getInt("loggedin_user_id", 0);
        name= sharedpreferences.getString("login_name", "");
        setnotification();
        setHeader();


        loadcompletedcourses();


        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        dr = new Drawer(this);
        dr.initializeDrawers(mDrawerLayout,name);
        imgDrawer = (ImageView) findViewById(R.id.imgDrawer);
        imgDrawer.setOnClickListener(CompletedCourses.this);


    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imgDrawer:

                    mDrawerLayout.openDrawer(dr.mDrawerList);

                break;
        }
    }

    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateUI(intent);
        }
    };

    /**
     * Method is used to set notification count
     *
     * @param intent
     */
    private void updateUI(Intent intent) {
        String counter = intent.getStringExtra("counter");
        tvNotificationCount.setText(String.valueOf(counter));

    }
    @Override
    public void onResume() {
        super.onResume();
        MyApplication.activityResumed();
        registerReceiver(broadcastReceiver, new IntentFilter(MerchantNotificationService.BROADCAST_ACTION));

    }

    @Override
    public void onPause() {
        super.onPause();
        MyApplication.activityPaused();
       // unregisterReceiver(broadcastReceiver);

    }
    public void loadcompletedcourses() {
        getcompletedcourses();
    }

    public void showDialog(Context ctx, String title, CharSequence message) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx, R.style.MyDialogTheme);

        if (title != null) builder.setTitle(title);

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        builder.show();
    }
    public void setnotification() {
        ImageView ivNotification = (ImageView) findViewById(R.id.imgNotification);
        tvNotificationCount = (TextView) findViewById(R.id.tvNotificationCount);

        tvNotificationCount.setText(String.valueOf(countNotification));
        ivNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvNotificationCount.setText("0");
                Intent notificationIntent = new Intent(CompletedCourses.this, MerchantNotification.class);
                startActivity(notificationIntent);
                //CompletedCourses.this.finish();
            }
        });
    }
    protected void setHeader() {
        TextView header = (TextView) findViewById(R.id.header_text);
        header.setText("Completed Courses");
        ImageView imgLogo = (ImageView) findViewById(R.id.imglogo);
        imgLogo.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent homeintent = new Intent(CompletedCourses.this, MainActivity.class);
                startActivity(homeintent);
                CompletedCourses.this.finish();
            }
        });
    }
    public void getcompletedcourses() {
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage("Loading...");
        mProgressDialog.show();

        //new code added as my progress dialog was getting dismissed if user click on screen
        mProgressDialog.setCancelable(false);
        mProgressDialog.setCanceledOnTouchOutside(false);
        //Creating a RestAdapter
        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(StaticDataMember.url) //Setting the Root URL
                .build(); //Finally building the adapter
        //final RestAdapter adapter = httpsAdapter.createAdapter(this);

        //Creating object for our interface

        RestInterfac api = adapter.create(RestInterfac.class);

        //Defining the method insertuser of our interface
        api.getCompCourses(
                //Passing the values by getting it from editTexts
                userid,
                new retrofit.Callback<Response>() {
                    @Override
                    public void success(Response result, Response response) {
                        BufferedReader reader = null;
                        int success = 0;
                        String output = "";
                        JSONObject json = null;
                        Intent nxt;
                        try {

                            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));
                            //Reading the output in the string
                            output = reader.readLine();
                            JSONTokener tokener = new JSONTokener(output);
                            json = new JSONObject(tokener);
                            if (json != null) {

                                success = json.getInt("success");
                                coursejsonObj = json.getJSONArray("usercourse");
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //  {"Success":1,"loggedin_user_id":"5","loggedin_user_name":"vinit"}

                        // {"mobile":"9822949936","business_category":"0","success":1,"loggedin_user_id":"116","loggedin_user_name":"pal"}

                        if (success == 1) {
                            Log.v("json name", "username" + name);
                            SharedPreferences.Editor editor = sharedpreferences.edit();
                            editor.putString("usercourse", coursejsonObj.toString());
                            try {

                                for(int i=0;i<coursejsonObj.length();i++){
                                    JSONObject json_obj = coursejsonObj.getJSONObject(i);
                                    String desc = json_obj.getString("course_description");
                                    String name = json_obj.getString("course_name");
                                    String audio = json_obj.getString("intro_audio");
                                    String inst = json_obj.getString("instructor");
                                    String fee = json_obj.getString("fee");
                                    int id = json_obj.getInt("id");
                                    String max = json_obj.getString("max_modules");
                                    String image = json_obj.getString("course_image");
                                    listArray.add(new Course(id,name,desc,inst,audio,"","","","",image,fee,"",max,"0"));

                                }
                                // course.setCoursename();
                            }catch(JSONException j){
                                Log.e("Course JSON", j.toString());
                            }
                            if (!listArray.isEmpty()){
                                TextView nocourse = (TextView) findViewById(R.id.tvnocourse);
                                nocourse.setVisibility(View.GONE);
                                final LinearLayoutManager layoutManager= new LinearLayoutManager(CompletedCourses.this, LinearLayoutManager.VERTICAL, false);
                                mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view_comp);
                                mRecyclerView.setLayoutManager(layoutManager);
                                customadapter = new CompletedCourseAdapter(listArray, CompletedCourses.this);
                                mRecyclerView.setAdapter(customadapter);
                                customadapter.notifyDataSetChanged();}
                            else{
                                TextView nocourse = (TextView) findViewById(R.id.tvnocourse);
                                nocourse.setVisibility(View.VISIBLE);
                            }



                        } else {
                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(CompletedCourses.this, "Invalid Credentials", "Please enter valid email or Password");

                        }
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();


                         /*else {

                            // Toast.makeText(login.this, "please enter valid username or password",Toast.LENGTH_LONG).show();
                            showDialog(LoginActivity.this, "Invalid Credentials", "please enter valid Email_Id and Password");
                        }*/

                    }

                    @Override
                    public void failure(RetrofitError error) {
                        //If any error occured displaying the error as toast
                        if (mProgressDialog.isShowing())
                            mProgressDialog.dismiss();
                        //Toast.makeText(login.this, error.toString(),Toast.LENGTH_LONG).show();
                        showDialog(CompletedCourses.this,"Network Error", "Problem connecting to internet. Please try again later");
                    }
                }
        );

    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        if (mProgressDialog.isShowing())
            mProgressDialog.dismiss();
            Intent homeintent = new Intent(CompletedCourses.this, MainActivity.class);
            startActivity(homeintent);
            CompletedCourses.this.finish();
        }


}
